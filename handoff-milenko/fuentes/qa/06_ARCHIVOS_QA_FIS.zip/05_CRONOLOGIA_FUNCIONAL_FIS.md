# CRONOLOGÍA FUNCIONAL FIS

| Fecha | Evento | Tema | Decisión/cambio | Impacto |
|---|---|---|---|---|
| 10-07-2026 | Primera reunión | Levantamiento Intervent | Se identifica Preclaim como primer proyecto: carpeta/documentos, cálculo, cartas, prescripción y trazabilidad. | Base del demo. |
| 21-07-2026 | Segunda reunión | Proceso actual y accesos | Se revisan Excel/plataforma, referencia, handler, expediente; API no existe y acceso es un stopper. | Se intenta conseguir cuenta de solo lectura. |
| Posterior al 21-07 y antes del 25-08 | Mensaje de Ljubinka | Cambio de entrada | Se abandona dependencia de acceso y se decide comenzar desde carpeta descargada. | Cambio de alcance vigente. |
| 22-08-2026 | Solicitud registrada | Migración | Cliente pide migración automática desde planillas actuales sin ingreso manual. | La propuesta y el contrato precisan posteriormente el alcance. |
| 24-08-2026 | Propuesta 167 | MVP y roadmap | Define Fase 1, evolución, 100 UF y soporte. | Base comercial del primer proyecto. |
| 25-08-2026 | Correo de aprobación | Aprobación | FIS aprueba expresamente la propuesta 167 y solicita coordinar el avance. | El demo pasa a desarrollo. |
| Posterior al 25-08-2026 | Reunión de coordinación | Inicio de desarrollo | Backend/base de datos; primera versión en 1-2 semanas; histórico superior a 4.000 registros. | Hito de prueba del proyecto 167. |
| 27-08-2026 | Contrato v6.0 fechado | Baseline contractual | Incluye cartas, extracción asistida, importación histórica acotada, roles, seguridad y exclusiones. | El cuerpo y Anexo A prevalecen sobre la propuesta. |
| 07-09 y 10-09-2026 | Firma del contrato | Perfeccionamiento | Ambas partes suscriben el contrato; la última fecha visible es 10-09-2026. | Baseline jurídico acreditado. |
| 09–10 de septiembre de 2026 | Confirmación de Ljubinka | Cartas finales | AoR, Harvest, LoA y claim notice incluidas; SUBRO fuera. | Resuelve alcance de cartas. |
| 16-09-2026 | Documento funcional | Consolidación para revisión | Se genera descripción amplia con validaciones pendientes. | Objeto de esta auditoría. |
| 17-09-2026 | Auditoría actualizada | QA y trazabilidad | Se contrastan reuniones, propuesta aprobada, contrato firmado y DF, solo para el proyecto 167. | Se elimina el antiguo bloqueo de firma y se recalculan brechas. |

## Registro de decisiones

| ID | Fecha | Tema | Decisión | Participantes | Fuente | Impacto funcional | REQ afectados |
|---|---|---|---|---|---|---|---|
| DEC-001 | 10-07-2026 | Prioridad | El primer proyecto será Intervent Preclaim; cualquier otra iniciativa queda fuera de esta auditoría. | Ljubinka, Julio, Rodrigo | F01; F06; F07 | Foco exclusivo en el proyecto 167. | REQ-001 a REQ-129 |
| DEC-002 | Posterior al 21-07 y antes del 25-08-2026 | Fuente de entrada | Avanzar desde una carpeta ya descargada porque no habrá acceso directo a la plataforma del cliente. | Ljubinka | F03 | Elimina API/robot de Fase 1. | REQ-001, REQ-002, REQ-004 |
| DEC-003 | 10-07-2026; ratificada en contrato | Revisión humana | El sistema asiste; el Handler confirma datos, causa, mérito y cálculo. | Ljubinka / partes | F01; F07 | No existen decisiones automáticas definitivas. | REQ-032, REQ-047 |
| DEC-004 | 25-08-2026 | Aprobación comercial | FIS aprobó expresamente la propuesta 167. | Ljubinka | F04; F06 | El MVP pasa a proyecto contratado. | REQ-124 a REQ-129 |
| DEC-005 | Posterior al 25-08-2026 | Desarrollo | Consolidar backend/base de datos y entregar una primera versión utilizable en aproximadamente 1-2 semanas. | Julio / Ljubinka | F05; F11 | Hito de prueba, no término del proyecto. | REQ-124, REQ-126 |
| DEC-006 | Posterior al 25-08-2026 | Histórico | Más de 4.000 registros estaban precargados; el contrato consolida ~4.240 registros/39 hojas. | Julio / partes | F05; F07 | Carga inicial incluida. | REQ-100 |
| DEC-007 | 07-09 y 10-09-2026 | Baseline jurídico | El contrato v6.0 fue firmado por ambas partes; su cuerpo y Anexo A prevalecen sobre la propuesta 167. | NPR SpA / FIS Chile SpA | F07 §1.4 y página de firmas | Resuelve la prelación de fuentes y el alcance aprobado. | Todos |
| DEC-008 | Contrato fechado 27-08-2026 | Traspaso | FIS/Lawgistic son estados de cierre local; no existe integración ni gestión posterior. | Partes | F07 | Frontera final de Fase 1. | REQ-082 a REQ-084 |
| DEC-009 | 09-10 de septiembre de 2026 | Cartas | Se incluyen AoR, Harvest, LoA y claim notice; SUBRO queda fuera. | Ljubinka / partes | F07; F10 | Conjunto definitivo de cartas. | REQ-069 a REQ-075 |
| DEC-010 | Contrato fechado 27-08-2026 | Extracción | BL, facturas y liquidaciones se extraen de forma asistida para el cálculo y requieren confirmación humana. | Partes | F07 | Incluido aunque la propuesta lo ubicaba parcialmente como evolución. | REQ-027 a REQ-032 |
| DEC-011 | Contrato fechado 27-08-2026 | Excel | Carga inicial e importación de nuevos Excel históricos con la misma estructura están incluidas; homologación, duplicados, rollback y activos masivos están excluidos. | Partes | F07 | Resuelve la solicitud de migración dentro del proyecto 167. | REQ-100 a REQ-108 |
| DEC-012 | Contrato fechado 27-08-2026 | Precio y soporte | 100 UF + IVA, 2 meses de soporte y 3 UF + IVA mensuales desde el tercer mes mientras siga vigente. | Partes | F07 | Condición vinculante del proyecto. | REQ-128 |
| DEC-013 | 21-07 y contrato fechado 27-08-2026 | Exclusividad | La solución específica y el know-how FIS no se replicarán a competidores durante la vigencia y 24 meses después del término. | Ljubinka / partes | F02; F07 §12 | Protege el diferenciador del proyecto 167. | REQ-129 |

## Cambios de alcance

| ID | Definición inicial | Cambio solicitado/acordado | Fecha | Quién | Motivo | Impacto | REQ | Estado final |
|---|---|---|---|---|---|---|---|---|
| SCOPE-001 | Integración directa con plataforma como aspiración | Procesar desde carpeta ya descargada | Antes del 25-08-2026 | Ljubinka | Acceso/API no autorizado | Elimina descarga automática de Fase 1 | REQ-001, REQ-004 | Vigente: carpeta local |
| SCOPE-002 | Demo funcional | Consolidación productiva con backend, datos y login | 25-08 a septiembre de 2026 | FIS/NPR | Propuesta 167 aprobada y contrato firmado | Convierte el prototipo en producto | REQ-115, REQ-124 | Incluido |
| SCOPE-003 | Cartas formales ubicadas como evolución en la propuesta | Cuatro cartas estándar entran al alcance contractual | Contrato fechado 27-08; confirmado 09-10 de septiembre | Partes / Ljubinka | Aclaración contractual | Añade generación automatizada acotada | REQ-068 a REQ-074 | Incluidas |
| SCOPE-004 | Extracción avanzada ubicada como evolución en la propuesta | Extracción asistida de BL, facturas y liquidaciones entra al contrato | Contrato fechado 27-08-2026 | Partes | Necesaria para cálculo | Reduce ingreso manual con validación | REQ-027 a REQ-032 | Incluida |
| SCOPE-005 | SUBRO figuraba entre documentos posibles | SUBRO queda expresamente fuera | Contrato y confirmación 09-10 de septiembre | Partes / Ljubinka | Cierre de alcance | Reduce templates a cuatro | REQ-075 | Excluida |
| SCOPE-006 | Histórico precargado y migración amplia solicitada | Carga inicial ~4.240/39 e importación de nuevos Excel de igual estructura; automatización avanzada y activos masivos fuera | 22-08 a contrato fechado 27-08-2026 | Cliente / partes | Delimitación final firmada | Define importación recurrente acotada | REQ-100 a REQ-108 | Resuelto por contrato |
| SCOPE-007 | Posible continuidad posterior a FIS/Lawgistic | Fase 1 termina en un cambio de estado local | Contrato fechado 27-08-2026 | Partes | Control de alcance | Excluye integración y gestión posterior | REQ-084 | Vigente |
