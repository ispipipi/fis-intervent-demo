# MATRIZ MAESTRA DE TRAZABILIDAD FIS

**Alcance:** exclusivamente el proyecto Intervent Preclaim aprobado en la propuesta 167 y delimitado por el contrato v6.0 firmado.

## Núcleo Intervent Preclaim

| REQ | Fuente cliente | Fecha | Tema | DF | Cobertura | Observación |
|---|---|---|---|---|---|---|
| REQ-001 | F03; F07 §1.1 | Posterior al 21-07 y antes del 25-08; 27-08-2026 | Ingreso | DF-023; DF-036 | COMPLETO | El documento modela carga de carpeta y deja integraciones fuera. |
| REQ-002 | F01 19:10; F03; F07 Anexo A | 10-07; fecha no consignada; 27-08-2026 | Ingreso | DF-023; DF-036 | COMPLETO | Cubierto en flujo y criterios de carga. |
| REQ-003 | F07 Anexo A | 27-08-2026 | Ingreso | DF-005; DF-035; DF-036 | COMPLETO | Cubierto. |
| REQ-004 | F02 18:29-30:38; F03; F07 §3.1 | 21-07; posterior al 21-07; 27-08-2026 | Límite de integración | DF-017; DF-056 | COMPLETO | La exclusión está descrita, aunque la pregunta de fuente productiva reaparece innecesariamente. |
| REQ-005 | F01 19:10; F03; F07 Anexo A | 10-07; posterior al 21-07; 27-08-2026 | Documentos | DF-006; DF-026; DF-037 | COMPLETO | Cubierto. |
| REQ-006 | F01 5:17; F03; F07 Anexo A | 10-07; posterior al 21-07; 27-08-2026 | Documentos | DF-006; DF-026; DF-037 | COMPLETO | Cubierto. |
| REQ-007 | F07 Anexo A | 27-08-2026 | Documentos | DF-003; DF-025; DF-037 | COMPLETO | Cubierto. |
| REQ-008 | F07 Anexo A | 27-08-2026 | Documentos | DF-006; DF-036 | COMPLETO | Cubierto. |
| REQ-009 | F07 Anexo A | 27-08-2026 | Documentos | DF-036 | COMPLETO | Cubierto. |
| REQ-010 | F08 §8.3 | 16-09-2026 | Documentos | DF-025; DF-036 | NO DETERMINABLE | No aparece en reuniones ni contrato revisados. |
| REQ-011 | F08 §8.4; F06 §4.3 | 16-09; 24-08-2026 | Documentos | DF-026; DF-037 | PARCIAL | La propuesta y DF lo describen, pero el contrato no fija escala ni umbral. |
| REQ-012 | F07 Anexo A | 27-08-2026 | Documentos | DF-026; DF-037; DF-054 | COMPLETO | Cubierto. |
| REQ-013 | F01 6:14-7:34; F02 7:25-11:14 | 10-07; 21-07-2026 | Referencia | DF-024; DF-035 | PARCIAL | El DF dice que debe respetar la convención, pero no la especifica. |
| REQ-014 | F07 Anexo A; F08 §8.2 | 27-08; 16-09-2026 | Referencia | DF-024; DF-035 | COMPLETO | Cubierto. |
| REQ-015 | F07 Anexo A; F08 §8.2 | 27-08; 16-09-2026 | Referencia | DF-005; DF-035 | COMPLETO | Cubierto. |
| REQ-016 | F02 8:54-11:14 | 21-07-2026 | Referencia | — | AUSENTE | No aparece en el DF ni en el contrato. |
| REQ-017 | F02 14:22-15:35 | 21-07-2026 | Asignación | — | AUSENTE | No aparece en la propuesta aprobada ni en el Anexo A firmado; no es incumplimiento del proyecto 167 y requiere Solicitud de Cambio. |
| REQ-018 | F02 15:35-16:31; F07 §1.1 y Anexo A | 21-07; 27-08-2026 | Expediente | DF-003; DF-007 | COMPLETO | Cubierto. |
| REQ-019 | F01 19:10; F03; F07 Anexo A | 10-07; fecha no consignada; 27-08-2026 | Inventario | DF-028; DF-038 | COMPLETO | Cubierto. |
| REQ-020 | F01 12:25; F03; F07 Anexo A | 10-07; fecha no consignada; 27-08-2026 | Inventario | DF-028; DF-038 | COMPLETO | Cubierto. |
| REQ-021 | F08 §8.5 | 16-09-2026 | Inventario | DF-038 | PARCIAL | Contrato confirma disponibles/faltantes y solicitud; no define observado/reemplazado. |
| REQ-022 | F01 12:25-13:58; F07 §7 | 10-07; 27-08-2026 | Inventario | DF-028; DF-038; DF-056 | PARCIAL | Existe función, pero el checklist oficial no está definido. |
| REQ-023 | F08 §8.5 | 16-09-2026 | Inventario | DF-038 | PARCIAL | La necesidad es coherente, pero no consta como regla acordada en contrato o reuniones. |
| REQ-024 | F07 Anexo A | 27-08-2026 | Inventario | DF-007; DF-038 | COMPLETO | Cubierto. |
| REQ-025 | F07 Anexo A | 27-08-2026 | Inventario | DF-028; DF-038 | COMPLETO | Cubierto. |
| REQ-026 | F07 §3.1 | 27-08-2026 | Comunicaciones | DF-021; DF-038 | COMPLETO | Cubierto. |
| REQ-027 | F01 36:07; F07 Anexo A; F10 | 10-07; 27-08; 09–10 de septiembre de 2026 | Extracción | DF-008; DF-027; DF-039 | COMPLETO | Cubierto. |
| REQ-028 | F07 Anexo A; F10 | 27-08; 09–10 de septiembre de 2026 | Extracción | DF-008; DF-027; DF-039 | COMPLETO | Cubierto. |
| REQ-029 | F07 Anexo A; F10 | 27-08; 09–10 de septiembre de 2026 | Extracción | DF-008; DF-027; DF-039 | COMPLETO | Cubierto. |
| REQ-030 | F07 Anexo A | 27-08-2026 | Extracción | DF-008; DF-027; DF-039 | PARCIAL | El DF enumera ejemplos, pero no cierra el corpus productivo ni prioridades. |
| REQ-031 | F06 §4.6; F08 §8.6 | 24-08; 16-09-2026 | Extracción | DF-027; DF-039 | COMPLETO | Cubierto. |
| REQ-032 | F07 Anexo A | 27-08-2026 | Extracción | DF-027; DF-039; DF-054 | COMPLETO | Cubierto. |
| REQ-033 | F01 2:50-5:17; F08 §8.6 | 10-07; 16-09-2026 | Datos | DF-039 | COMPLETO | Cubierto. |
| REQ-034 | F01 6:14; F08 §8.6 | 10-07; 16-09-2026 | Datos | DF-039 | COMPLETO | Cubierto. |
| REQ-035 | F02 6:20-12:47; F08 §8.6 | 21-07; 16-09-2026 | Datos | DF-039 | COMPLETO | Cubierto. |
| REQ-036 | F01 15:22-19:03; F08 §8.6 | 10-07; 16-09-2026 | Datos | DF-039 | COMPLETO | Cubierto. |
| REQ-037 | F02 11:14-13:35; F08 §8.6 | 21-07; 16-09-2026 | Datos | DF-039 | COMPLETO | Cubierto. |
| REQ-038 | F08 §8.6 | 16-09-2026 | Datos | DF-039 | NO DETERMINABLE | No se encontró confirmación externa al DF. |
| REQ-039 | F02 24:18-24:44; F06 §4.6 | 21-07; 24-08-2026 | Datos | DF-039 | COMPLETO | Cubierto. |
| REQ-040 | F02 11:14-13:35; F08 §8.2 | 21-07; 16-09-2026 | Fechas | DF-035; DF-039; DF-056 | COMPLETO | Cubierto como distinción; escenarios exactos siguen abiertos. |
| REQ-041 | F02 5:26-6:20; F06 §4.12; F08 §11 | 21-07; 24-08; 16-09-2026 | Búsqueda | DF-047 | PARCIAL | DF lo define claramente para histórico; falta explicitar mismo alcance en casos activos. |
| REQ-042 | F02 6:20-7:25; F03; F07 Anexo A | 21-07; fecha no consignada; 27-08-2026 | Análisis | DF-029; DF-040 | COMPLETO | Cubierto. |
| REQ-043 | F03; F07 Anexo A | Fecha no consignada; 27-08-2026 | Análisis | DF-029; DF-040 | COMPLETO | Cubierto. |
| REQ-044 | F01 11:03-12:25; F03; F07 Anexo A | 10-07; fecha no consignada; 27-08-2026 | Análisis | DF-029; DF-040 | COMPLETO | Cubierto. |
| REQ-045 | F07 Anexo A | 27-08-2026 | Análisis | DF-029; DF-040 | COMPLETO | Cubierto. |
| REQ-046 | F01 10:18-12:25; F07 Anexo A | 10-07; 27-08-2026 | Análisis | DF-029; DF-040 | COMPLETO | Cubierto. |
| REQ-047 | F01 10:34-12:25; F07 Anexo A | 10-07; 27-08-2026 | Análisis | DF-009; DF-029; DF-040; DF-054 | COMPLETO | Cubierto de forma consistente. |
| REQ-048 | F01 12:25 | 10-07-2026 | Análisis | DF-040 | PARCIAL | La revisión humana evita el bloqueo, pero la excepción comercial no está documentada expresamente. |
| REQ-049 | F01 13:58-14:33; F03; F07 Anexo A | 10-07; fecha no consignada; 27-08-2026 | Cálculo | DF-030; DF-041 | COMPLETO | Cubierto. |
| REQ-050 | F01 15:22-19:03 | 10-07-2026 | Cálculo | DF-041; DF-042 | PARCIAL | El DF menciona producto, unidades y ajustes, pero omite los cuatro criterios completos. |
| REQ-051 | F01 15:22-19:03 | 10-07-2026 | Cálculo | DF-041 | DISTINTO | El DF define valor neto esperado versus neto obtenido, lo que contradice la explicación de la reunión. |
| REQ-052 | F01 15:22-19:03 | 10-07-2026 | Cálculo | DF-041 | COMPLETO | Cubierto en términos generales. |
| REQ-053 | F01 15:22-19:03 | 10-07-2026 | Cálculo | DF-041 | DISTINTO | El DF usa resultado neto de la liquidación afectada. |
| REQ-054 | F01 15:22-19:03; F06 §4.8 | 10-07; 24-08-2026 | Cálculo | DF-041 | PARCIAL | El DF admite venta o liquidación y costos aplicables, sin fijar claramente venta bruta. |
| REQ-055 | F01 15:22-19:03; F07 Anexo A | 10-07; 27-08-2026 | Cálculo | DF-041 | COMPLETO | Cubierto. |
| REQ-056 | F01 15:22-19:03; F07 Anexo A | 10-07; 27-08-2026 | Cálculo | DF-041; DF-042 | PARCIAL | Función cubierta, pero signo y límite siguen abiertos. |
| REQ-057 | F07 Anexo A | 27-08-2026 | Cálculo | DF-041 | COMPLETO | Cubierto. |
| REQ-058 | F01 13:58-14:33; F07 Anexo A | 10-07; 27-08-2026 | Cálculo | DF-030; DF-041 | COMPLETO | Cubierto. |
| REQ-059 | F01 13:58-14:33 | 10-07-2026 | Cálculo | DF-041; DF-042 | PARCIAL | DF exige selección/justificación, pero no refleja el criterio comercial de mayor beneficio. |
| REQ-060 | F07 Anexo A | 27-08-2026 | Cálculo | DF-030; DF-041 | COMPLETO | Cubierto. |
| REQ-061 | F07 Anexo A | 27-08-2026 | Moneda | DF-043 | COMPLETO | Cubierto. |
| REQ-062 | F07 Anexo A | 27-08-2026 | Moneda | DF-043 | COMPLETO | Cubierto. |
| REQ-063 | F08 §9.2 | 16-09-2026 | Moneda | DF-043 | PARCIAL | El comportamiento está bien formulado, pero fuente y regla no están acordadas. |
| REQ-064 | F08 §9.1; F07 §7 | 16-09; 27-08-2026 | Cálculo | DF-042; DF-056 | PARCIAL | El DF identifica el vacío, pero no lo resuelve. |
| REQ-065 | F07 Anexo A; F08 §9 | 27-08; 16-09-2026 | Cálculo | DF-041; DF-054 | COMPLETO | Cubierto. |
| REQ-066 | F07 Anexo A; F08 §14 | 27-08; 16-09-2026 | Cálculo | DF-041; DF-053 | COMPLETO | Cubierto. |
| REQ-067 | F07 Anexo A | 27-08-2026 | Cálculo | DF-003; DF-033; DF-053 | COMPLETO | Cubierto. |
| REQ-068 | F01 36:07-36:44; F07 Anexo A | 10-07; 27-08-2026 | Cartas | DF-010; DF-031; DF-044 | COMPLETO | Cubierto. |
| REQ-069 | F07 Anexo A; F10 | 27-08; 09–10 de septiembre de 2026 | Cartas | DF-010; DF-044 | COMPLETO | Cubierto. |
| REQ-070 | F07 Anexo A; F10 | 27-08; 09–10 de septiembre de 2026 | Cartas | DF-010; DF-044 | COMPLETO | Cubierto. |
| REQ-071 | F07 Anexo A; F10 | 27-08; 09–10 de septiembre de 2026 | Cartas | DF-010; DF-044 | COMPLETO | Cubierto. |
| REQ-072 | F07 Anexo A; F10 | 27-08; 09–10 de septiembre de 2026 | Cartas | DF-010; DF-044 | COMPLETO | Cubierto. |
| REQ-073 | F07 Anexo A | 27-08-2026 | Cartas | DF-031; DF-044; DF-045 | COMPLETO | Cubierto. |
| REQ-074 | F08 §10.1 | 16-09-2026 | Cartas | DF-045 | PARCIAL | Es diseño útil, pero contrato no define todas estas operaciones. |
| REQ-075 | F07 §3.1; F10 | 27-08; 09–10 de septiembre de 2026 | Cartas | DF-020; DF-044 | COMPLETO | Cubierto. |
| REQ-076 | F07 §3.1 | 27-08-2026 | Cartas | DF-020; DF-044 | COMPLETO | Cubierto. |
| REQ-077 | F07 §3.1 | 27-08-2026 | Cartas | DF-020; DF-044; DF-045 | COMPLETO | Cubierto. |
| REQ-078 | F07 §7; F08 §10 | 27-08; 16-09-2026 | Cartas | DF-044; DF-056 | PARCIAL | El DF declara el pendiente, pero aún no hay definición. |
| REQ-079 | F07 Anexo A; F08 §§10 y 19 | 27-08; 16-09-2026 | Cartas | DF-044; DF-057 | NO DETERMINABLE | No existe equivalencia explícita en las fuentes. |
| REQ-080 | F07 Anexo A | 27-08-2026 | Estados | DF-033 | COMPLETO | Cubierto. |
| REQ-081 | F08 §§7 y 14 | 16-09-2026 | Estados | DF-033; DF-053 | PARCIAL | DF describe condiciones generales, pero no una máquina de estados cerrada. |
| REQ-082 | F01 14:33; F07 Anexo A | 10-07; 27-08-2026 | Traspaso | DF-032; DF-053 | COMPLETO | Cubierto. |
| REQ-083 | F01 14:33; F07 Anexo A | 10-07; 27-08-2026 | Traspaso | DF-032; DF-053 | COMPLETO | Cubierto. |
| REQ-084 | F07 Anexo A | 27-08-2026 | Traspaso | DF-015; DF-017; DF-053 | COMPLETO | Cubierto. |
| REQ-085 | F08 §14 y pregunta 13 | 16-09-2026 | Traspaso | DF-053; DF-056 | PARCIAL | La propuesta del DF no está confirmada por el cliente. |
| REQ-086 | F07 Anexo A | 27-08-2026 | Traspaso | DF-034; DF-053 | COMPLETO | Cubierto. |
| REQ-087 | F08 §14 | 16-09-2026 | Traspaso | DF-053; DF-054 | PARCIAL | Consistente con auditoría, pero no se explicita en contrato. |
| REQ-088 | F07 Anexo A | 27-08-2026 | Auditoría | DF-054 | COMPLETO | Cubierto. |
| REQ-089 | F01 40:03-41:59 | 10-07-2026 | Auditoría | DF-049; DF-054 | PARCIAL | Hay auditoría general, pero no regla anti-backdating ni definición de movimiento. |
| REQ-090 | F01 37:55-39:26; F02 11:14-13:35; F07 Anexo A | 10-07; 21-07; 27-08-2026 | Prescripción | DF-012; DF-039 | PARCIAL | DF menciona jurisdicción y regla, pero no fija los plazos explicados. |
| REQ-091 | F01 37:55; F02 11:14-13:35 | 10-07; 21-07-2026 | Prescripción | DF-039; DF-056 | PARCIAL | DF distingue ETA/real, pero todavía pregunta qué fecha activa la regla en cada escenario. |
| REQ-092 | F01 37:55-39:26; F07 Anexo A | 10-07; 27-08-2026 | Prescripción | DF-012; DF-049; DF-051 | COMPLETO | Cubierto. |
| REQ-093 | F01 40:03-42:31; F07 Anexo A | 10-07; 27-08-2026 | Seguimiento | DF-049; DF-051 | COMPLETO | Función cubierta; regla exacta pendiente. |
| REQ-094 | F06 §8.3; F07 Anexo A; F08 §12 | 24-08; 27-08; 16-09-2026 | Seguimiento | DF-049; DF-056 | NO DETERMINABLE | El DF propone 15 días, pero no hay confirmación del cliente. |
| REQ-095 | F01 39:26; F08 §12 | 10-07; 16-09-2026 | Seguimiento | DF-049; DF-056 | NO DETERMINABLE | Idea del proveedor, no acuerdo final demostrado. |
| REQ-096 | F01 37:10-42:31; F07 Anexo A | 10-07; 27-08-2026 | Dashboard | DF-013; DF-051 | COMPLETO | Cubierto. |
| REQ-097 | F07 Anexo A; F06 §4.11 | 27-08; 24-08-2026 | Dashboard | DF-013; DF-051 | PARCIAL | Función cubierta; periodo y uso no definidos. |
| REQ-098 | F07 Anexo A | 27-08-2026 | Reportes | DF-032; DF-057 | COMPLETO | Cubierto. |
| REQ-099 | F07 Anexo A | 27-08-2026 | Reportes | DF-031; DF-044; DF-057 | PARCIAL | Función aparece, pero existe ambigüedad de duplicación con claim notice. |
| REQ-100 | F05 2:00; F07 Anexo A | Posterior al 25-08; 27-08-2026 | Histórico | DF-014; DF-046 | COMPLETO | Cubierto. |
| REQ-101 | F07 Anexo A | 27-08-2026 | Histórico | DF-014; DF-047 | COMPLETO | Cubierto. |
| REQ-102 | F06 §4.12; F08 §11 | 24-08; 16-09-2026 | Histórico | DF-047 | COMPLETO | Cubierto. |
| REQ-103 | F06 §4.12; F08 §11 | 24-08; 16-09-2026 | Histórico | DF-046; DF-047 | PARCIAL | DF menciona archivo/origen, pero no asegura hoja/fila como la propuesta. |
| REQ-104 | F07 Anexo A | 27-08-2026 | Histórico | DF-046; DF-048 | COMPLETO | Cubierto en términos generales. |
| REQ-105 | F09; F06 §§4.12 y 7.1; F07 Anexo A | 22-08; 24-08; contrato fechado 27-08-2026 | Migración | DF-046; DF-048 | COMPLETO | El alcance vigente ya no es ambiguo: rige la delimitación del cuerpo contractual y Anexo A. |
| REQ-106 | F08 §11 | 16-09-2026 | Histórico | DF-048 | DISTINTO | El contrato excluye homologación, validación asistida y reversión; solo permite incorporar sobre la misma estructura. |
| REQ-107 | F08 §11 | 16-09-2026 | Histórico | DF-048 | DISTINTO | El contrato excluye expresamente detección de duplicados en la importación de nuevos Excel. |
| REQ-108 | F07 §3.1 | 27-08-2026 | Histórico | DF-017; DF-048 | PARCIAL | El DF menciona integración/exclusiones, pero no destaca con suficiente precisión esta diferencia. |
| REQ-109 | F08 §11.1 | 16-09-2026 | Histórico | DF-047 | PARCIAL | Lista útil, pero no fue confirmada como obligatoria por FIS. |
| REQ-110 | F06 §8.4; F07 §3.1; F08 §11 | 24-08; 27-08; 16-09-2026 | Exportación | DF-018; DF-048 | PARCIAL | El DF puede inducir a pensar que la exportación estará incluida. |
| REQ-111 | F07 Anexo A | 27-08-2026 | Roles | DF-004; DF-034 | COMPLETO | Cubierto. |
| REQ-112 | F07 Anexo A | 27-08-2026 | Roles | DF-004; DF-034; DF-053 | COMPLETO | Cubierto. |
| REQ-113 | F07 Anexo A | 27-08-2026 | Roles | DF-004; DF-034 | COMPLETO | Cubierto. |
| REQ-114 | F07 §3.1; F08 §13 | 27-08; 16-09-2026 | Roles | DF-019; DF-052 | COMPLETO | La frontera está bien declarada; el detalle del JSI carece de fuente identificada. |
| REQ-115 | F07 Anexo A | 27-08-2026 | Seguridad | DF-034; DF-054 | COMPLETO | Cubierto. |
| REQ-116 | F07 Anexo A | 27-08-2026 | Seguridad | DF-034; DF-054 | COMPLETO | Cubierto funcionalmente; falta diseño técnico verificable. |
| REQ-117 | F07 §3.1 | 27-08-2026 | Seguridad | DF-017; DF-054 | PARCIAL | El DF habla de expedientes autorizados, lo que podría superar la exclusión si no se acota. |
| REQ-118 | F07 §10 | 27-08-2026 | Seguridad | DF-054 | COMPLETO | Cubierto. |
| REQ-119 | F07 §10 | 27-08-2026 | Seguridad | DF-054 | PARCIAL | DF dice uso para el propósito, pero omite expresamente el no entrenamiento de modelos generales. |
| REQ-120 | F07 §10 | 27-08-2026 | Seguridad | DF-054 | COMPLETO | Cubierto. |
| REQ-121 | F08 §15 | 16-09-2026 | Seguridad | DF-054 | NO DETERMINABLE | No consta en el contrato; es control necesario que debe adoptarse. |
| REQ-122 | F07 Anexo A | 27-08-2026 | Manual | DF-016; DF-055 | COMPLETO | Cubierto. |

## Gobierno y condiciones del proyecto

| REQ | Fuente | Fecha | Tema | DF | Cobertura | Observación |
|---|---|---|---|---|---|---|
| REQ-123 | F05 1:05-3:00 | Posterior al 25-08-2026 | Incidencias | — | AUSENTE | No forma parte del alcance funcional firmado; debe tratarse como canal de pruebas o formalizarse mediante Solicitud de Cambio. |
| REQ-124 | F05 1:05; F07 Anexo A | Posterior al 25-08; 27-08-2026 | Arquitectura | DF-054 | PARCIAL | DF reconoce almacenamiento/autenticación, pero no define criterios técnicos verificables. |
| REQ-125 | F07 §4.1 | 27-08-2026 | Gestión | — | AUSENTE | No corresponde al núcleo funcional, pero debe quedar trazado. |
| REQ-126 | F05 1:05-2:21; F11 | Posterior al 25-08; registro 15-09-2026 | Plazo | — | AUSENTE | No está en DF ni se identifica fecha de inicio exacta. |
| REQ-127 | F07 §5.5 | 27-08-2026 | Aceptación | DF-057 | PARCIAL | DF define criterios, no el procedimiento y plazos completos. |
| REQ-128 | F07 §§5 y 8 | 27-08-2026 | Soporte | — | AUSENTE | Fuera del propósito funcional, pero relevante para cierre. |
| REQ-129 | F02 31:19-36:45; F07 §§11-12 | 21-07; 27-08-2026 | Propiedad | — | AUSENTE | No corresponde al DF funcional; debe controlarse contractualmente. |

## Nota de interpretación

Los requerimientos conversados pero no incorporados a la propuesta aprobada o al Anexo A firmado se mantienen trazados como antecedentes, pero no constituyen incumplimiento del proyecto 167. Toda incorporación exige Solicitud de Cambio conforme a F07 §4.2.
