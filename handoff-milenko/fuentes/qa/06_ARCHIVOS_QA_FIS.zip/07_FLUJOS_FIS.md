# FLUJOS FIS

## FLUJO-001 — Preclaim punta a punta

- **Actor inicial:** Handler
- **Pasos:**
  1. Cargar carpeta ya descargada
  2. Confirmar referencia y duplicidad
  3. Procesar/clasificar/renombrar documentos
  4. Revisar datos extraídos
  5. Confirmar disponibles y faltantes
  6. Revisar causa y mérito
  7. Comparar y justificar cálculo
  8. Generar cartas/reporte
  9. Traspasar a FIS o Lawgistic
- **Condiciones:** Decisiones automáticas requieren confirmación; cálculo completo antes de cierre según checklist aún por validar.
- **Excepciones:** Faltantes, datos incompletos, baja confianza, cálculo no posible, reversión gerencial.
- **Resultado final:** Expediente trazable cerrado localmente.
- **Fuentes:** F01-F03; F07
- **Cobertura DF:** PARCIAL: flujo cubierto; referencia, checklist, fórmulas y guardas están abiertos.

## FLUJO-002 — Procesamiento documental

- **Actor inicial:** Sistema + Handler
- **Pasos:**
  1. Recibir lote
  2. Preservar original
  3. Aplicar OCR si corresponde
  4. Clasificar
  5. Proponer nombre
  6. Corregir manualmente
  7. Actualizar inventario
- **Condiciones:** Formatos base PDF/XLSX/XLS/CSV.
- **Excepciones:** Archivo incompatible o baja confianza.
- **Resultado final:** Inventario clasificado y trazable.
- **Fuentes:** F03; F07; F08
- **Cobertura DF:** COMPLETO salvo regla de error por archivo.

## FLUJO-003 — Cálculo de pérdida

- **Actor inicial:** Handler
- **Pasos:**
  1. Confirmar datos
  2. Ejecutar tres métodos aplicables
  3. Comparar resultados
  4. Seleccionar método
  5. Justificar
  6. Guardar snapshot
  7. Bloquear al traspasar
- **Condiciones:** USD/CLP; fuentes y documentos confirmados.
- **Excepciones:** Falta comparable, reporte, FX o documento crítico.
- **Resultado final:** Pérdida preliminar validada.
- **Fuentes:** F01; F07
- **Cobertura DF:** PARCIAL/CONTRADICTORIO por bruto versus neto y fórmulas abiertas.

## FLUJO-004 — Generación de cartas

- **Actor inicial:** Handler
- **Pasos:**
  1. Elegir AoR/Harvest/LoA/claim notice
  2. Completar con datos confirmados
  3. Validar campos vacíos
  4. Vista previa
  5. Aprobar
  6. Descargar
- **Condiciones:** Plantilla oficial y versión activa.
- **Excepciones:** SUBRO/destrucción fuera; texto legal o firma no definidos.
- **Resultado final:** Carta base revisada.
- **Fuentes:** F01; F07; F10
- **Cobertura DF:** PARCIAL hasta validar plantillas oficiales.

## FLUJO-005 — Carga histórica

- **Actor inicial:** Usuario autorizado
- **Pasos:**
  1. Carga inicial 4.240/39
  2. Conservar origen
  3. Separar de activos
  4. Buscar
  5. Importar nuevos Excel de misma estructura
- **Condiciones:** Estructura idéntica a carga inicial.
- **Excepciones:** Sin homologación, duplicados, rollback ni activos masivos.
- **Resultado final:** Memoria consultable.
- **Fuentes:** F05; F07; F09
- **Cobertura DF:** DISTINTO: DF agrega actualización/duplicados no contratados.

## FLUJO-006 — Traspaso y reversión

- **Actor inicial:** Handler / Gerente
- **Pasos:**
  1. Revisar expediente
  2. Elegir FIS o Lawgistic
  3. Generar reporte
  4. Cambiar estado
  5. Bloquear cálculo
  6. Revertir con motivo si Gerente lo autoriza
- **Condiciones:** Checklist previo por validar.
- **Excepciones:** No integración externa ni gestión posterior.
- **Resultado final:** Cierre local auditable.
- **Fuentes:** F07; F08
- **Cobertura DF:** PARCIAL por guardas no confirmadas.

# Estados y transiciones

| Estado origen | Acción | Estado destino | Quién | Fuente/observación |
|---|---|---|---|---|
| Datos incompletos | Completar mínimos y confirmar referencia | Preclaim | Handler | F08 §7; guardas exactas pendientes |
| Preclaim | Confirmar faltantes relevantes | Documentación pendiente | Handler | F07/F08 |
| Documentación pendiente | Agregar/confirmar documentos | Preclaim | Handler | F08; transición propuesta |
| Preclaim | Seleccionar y justificar método | Cálculo completo | Handler | F07/F08 |
| Cálculo completo | Traspasar a extrajudicial | Traspasado a FIS | Handler | F07 |
| Cálculo completo | Traspasar a judicial | Traspasado a Lawgistic | Handler | F07 |
| Traspasado a FIS | Revertir con motivo | Estado previo por definir | Gerente | F07; destino exacto no definido |
| Traspasado a Lawgistic | Revertir con motivo | Estado previo por definir | Gerente | F07; destino exacto no definido |

**Alerta:** el catálogo de estados es contractual, pero el destino de una reversión y varias guardas siguen sin definición.
