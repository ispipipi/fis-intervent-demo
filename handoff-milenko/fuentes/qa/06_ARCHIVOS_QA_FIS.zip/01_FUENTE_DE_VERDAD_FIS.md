# FUENTE DE VERDAD FUNCIONAL FIS

## 1. Alcance de esta fuente de verdad

Esta especificación consolida exclusivamente la evidencia del primer proyecto aprobado: **Intervent Preclaim**, correspondiente a la propuesta 167 y al contrato v6.0 firmado. Distingue entre:

- **Baseline Fase 1:** solución contratada para el proceso Preclaim.
- **Evoluciones:** capacidades mencionadas en la propuesta o el DF que requieren una Solicitud de Cambio.
- **Dependencias de FIS:** reglas, plantillas y archivos que el Cliente debe entregar o validar.

La fuente principal es F07, contrato firmado por ambas partes. Conforme a su cláusula 1.4, prevalecen primero el cuerpo del contrato, luego el Anexo A y finalmente la propuesta 167 (F06). La propuesta fue aprobada por F04, pero no puede ampliar el contrato cuando existe contradicción.

## 2. Objetivo vigente

Centralizar en un expediente digital la carpeta documental de cada caso Preclaim, clasificar y renombrar documentos, extraer datos, identificar faltantes, asistir causa/mérito, comparar tres cálculos de pérdida, generar cuatro cartas base y cerrar localmente el caso hacia FIS o Lawgistic, siempre con revisión humana y trazabilidad.

**Confianza: ALTA.** Fuentes: F01-F03 y F07.

## 3. Límite de entrada

1. FIS obtiene la documentación desde la plataforma de su cliente.
2. En Fase 1, la solución recibe una **carpeta ya descargada**.
3. No se incluye API, robot, credenciales, descarga desde la plataforma, lectura de correo ni escritura en sistemas externos.
4. Una integración futura requiere interfaz, seguridad, credenciales y Change Request.

**Definición vigente:** la pregunta sobre si la fuente será API/correo/plataforma ya está resuelta para Fase 1: es la carpeta descargada. Fuente: F03 y F07. **Confianza: ALTA.**

## 4. Flujo funcional consolidado

1. **Ingreso:** alta manual o carga de carpeta completa.
2. **Identificación:** confirmar referencia, fecha base y duplicidad.
3. **Procesamiento:** preservar originales, aplicar OCR y clasificar.
4. **Normalización:** proponer tipo y nombre; Handler corrige.
5. **Extracción:** proponer datos desde BL, facturas, liquidaciones y documentos definidos.
6. **Inventario:** mostrar presentes, faltantes y cobertura; preparar solicitud.
7. **Análisis:** proponer resumen, tipo, causa, sustento y mérito.
8. **Cálculo:** ejecutar tres métodos, comparar, seleccionar y justificar.
9. **Cartas:** generar AoR, Harvest, LoA o claim notice y aprobar.
10. **Cierre:** generar informe y traspasar localmente a FIS o Lawgistic.
11. **Reversión:** solo Gerente, con motivo y trazabilidad.

## 5. Referencia interna

La referencia debe seguir la convención explicada por FIS, que incluye al menos etapa Preclaim, identificador FIS, sigla del transportista/oponente, año de asignación, periodo de prescripción y correlativo interno. Debe poder corregirse con auditoría y advertirse duplicidad.

**Pendiente bloqueante:** convertir la explicación verbal en fórmula canónica, definir separadores, fuente del correlativo y efecto de cambiar fecha real de descarga. Fuentes: F01 6:14-7:34 y F02 7:25-11:14. **Confianza actual: MEDIA.**

## 6. Documentos y expediente

- Carpeta completa y archivos individuales.
- Formatos contractuales: PDF, XLSX, XLS y CSV.
- OCR en documentos escaneados.
- Clasificación automática, nombre normalizado, original preservado y corrección manual.
- Expediente único con ficha, documentos, faltantes, causa, cálculo, estado, handler, prescripción e historial.
- Checklist por tipo de caso y porcentaje de cobertura.
- Texto/listado de faltantes descargable o copiable; sin envío automático.

**Pendientes:** corpus productivo cerrado; checklist oficial por tipo; estados documentales adicionales; tratamiento de no aplicables; umbrales de precisión. Fuentes: F03, F07 y F08. **Confianza: ALTA en función; MEDIA en reglas.**

## 7. Datos y extracción

La extracción asistida incluye BL, facturas y liquidaciones y debe entregar los campos necesarios para ficha y cálculo. Cada dato debe mostrar su documento de origen y quedar pendiente de confirmación, edición o descarte por el Handler.

Datos prioritarios: referencia, asegurado/cliente, oponente, nave, viaje, contenedor, carga, producto/variedad/calibre, cantidad/unidad, puertos, embarque, ETA, descarga real, claim number, inspector, jurisdicción, prescripción, montos y monedas.

**Regla:** ningún dato extraído se vuelve definitivo sin confirmación humana. Fuente: F07 Anexo A. **Confianza: ALTA.**

## 8. Causa y mérito

El sistema puede proponer resumen, tipo de caso, causa potencial, sustento y mérito preliminar. El Handler conserva la decisión final. Una recomendación baja no debe impedir que FIS continúe por razones comerciales justificadas.

Fuente: F01 10:18-12:25 y F07. **Confianza: ALTA**, aunque la excepción comercial debe formalizarse.

## 9. Cálculo de pérdida

### 9.1 Método 1 — embarque comparable/SMV

Debe usar un embarque gemelo con misma variedad, calibre, destino y fecha similar. FIS explicó comparación sobre base bruta; el DF actual usa neto y debe corregirse o validarse.

### 9.2 Método 2 — reporte de mercado

Se utiliza cuando no hay comparable adecuado. Debe registrar reporte, fecha, plaza, unidad y moneda. FIS también explicó una base bruta.

### 9.3 Método 3 — factura versus venta

Debe comparar factura de exportación con venta bruta en destino, conforme a fórmula aprobada.

### 9.4 Casos especiales

Venta a firme, nota de crédito e ítems adicionales con respaldo. Los tres resultados se muestran; el Handler selecciona uno y justifica. USD y CLP forman parte de Fase 1. El cálculo conserva entradas, fuentes, fecha, moneda, resultado y versión; se bloquea tras el traspaso.

**Pendiente bloqueante:** fichas matemáticas completas con bruto/neto, costos, unidades, límites, redondeos, FX y ejemplos aprobados. Fuentes: F01, F07 y F08. **Confianza: BAJA en fórmula; ALTA en estructura.**

## 10. Cartas

Templates incluidos:

- AoR.
- Harvest.
- LoA.
- Claim notice.

SUBRO y certificados de destrucción están excluidos. La carta debe usar datos confirmados, pasar por aprobación del Handler y conservar versión. No se incluye editor avanzado por cliente/naviera/jurisdicción.

**Pendientes:** plantillas oficiales, textos, campos, formato, firma y equivalencia entre claim notice y “carta de notificación a la naviera”. Fuentes: F07 y F10. **Confianza: ALTA en alcance; MEDIA en contenido.**

## 11. Estados y traspaso

Estados mínimos: Datos incompletos, Preclaim, Documentación pendiente, Cálculo completo, Traspasado a FIS y Traspasado a Lawgistic.

El traspaso es cierre local de Preclaim, no integración. Después se bloquea cálculo. El Gerente puede revertir con motivo obligatorio. Deben preservarse expediente e historial.

**Pendiente:** máquina de estados y checklist bloqueante por destino. Fuente: F07/F08. **Confianza: ALTA en catálogo; MEDIA en transiciones.**

## 12. Prescripción y seguimiento

FIS explicó para transporte marítimo una regla general de un año y dos años para Chile/Perú, calculados desde descarga real, asociada a La Haya/Hamburgo. El sistema debe mostrar fecha límite, días, vencimiento y riesgo.

Debe alertar inactividad basada en eventos reales. No está confirmado que el umbral sea 15 días, si son hábiles/corridos, qué estados se excluyen ni destinatarios.

**Pendiente bloqueante:** matriz legal-operativa aprobada y definición de movimiento. Fuentes: F01, F02 y F07. **Confianza: MEDIA.**

## 13. Dashboard y reportes

Dashboard de cartera, benchmark por handler, informe de revisión, texto/listado de faltantes y carta de notificación. Periodos, filtros finales, audiencia del benchmark y nomenclatura de carta requieren confirmación.

Fuente: F07/F08. **Confianza: ALTA en existencia; MEDIA en detalle.**

## 14. Histórico y migración

- Carga inicial aproximada: 4.240 registros/39 hojas.
- Consulta y separación de activos.
- Importación de nuevos Excel al histórico solo con la misma estructura.
- Sin homologación automática, validación asistida, detección de duplicados, rollback ni importación masiva de activos.

El DF actual excede este límite al definir actualización y duplicados. La solicitud previa de “migración automática de las planillas actuales” quedó acotada por la propuesta aprobada y, de forma definitiva, por el contrato firmado: carga inicial del histórico e importación posterior de Excel con igual estructura.

Fuentes: F05-F07 y F09. **Confianza: ALTA.** La contradicción vigente no es cliente versus contrato, sino DF versus contrato.

## 15. Roles y seguridad

- **Handler:** operación del caso.
- **Gerente:** cartera, benchmark y reversión motivada.
- **CEO/Dirección:** solo lectura.
- **Inspector:** evolución fuera de Fase 1.

Producción requiere login, control básico por rol, auditoría, respaldos y devolución/eliminación de datos. Los datos no pueden usarse para otros fines ni entrenar modelos generales.

Fuente: F07. **Confianza: ALTA.**

## 16. Solicitudes relacionadas no incorporadas al baseline firmado

- Asignación automática cliente-handler: conversada, pero no incorporada al Anexo A; requiere Solicitud de Cambio.
- Fuente/gestión del correlativo interno.
- Menú de incidencias/bugs/sugerencias: compromiso para el ciclo de pruebas, no alcance funcional firmado.
- Procedimiento comercial de aceptación, soporte y exclusividad (no funcional, pero trazado en F07).

## 17. Criterio de cierre

Esta fuente de verdad puede congelarse solo después de resolver OPEN-001 a OPEN-011 y corregir QA-FUNC-001 a QA-FUNC-011. Hasta entonces, el estado es **BORRADOR AUDITADO — CONTRATO ACREDITADO, DEFINICIÓN FUNCIONAL NO APROBADA**.
