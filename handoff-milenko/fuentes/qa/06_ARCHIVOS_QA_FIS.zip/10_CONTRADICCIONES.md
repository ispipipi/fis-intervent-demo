# CONTRADICCIONES Y CAMBIOS FIS

## Contradicciones

| ID | Tema | Fuente A | Interpretación A | Fuente B | Interpretación B | Fecha A | Fecha B | ¿Resolución posterior? | Conclusión actual | Estado |
|---|---|---|---|---|---|---|---|---|---|---|
| CON-001 | Base de cálculo métodos 1/2 | F01 15:22-19:03 | FIS explica base bruta para comparable/reporte | F08 §9 | El DF utiliza valores netos | 10-07-2026 | 16-09-2026 | No | La fórmula debe corregirse o validarse por escrito. | ABIERTA |
| CON-002 | Migración de planillas | F09 | Migración automática sin ingreso manual | F07 Anexo A/§3.1 | Carga inicial y nuevos Excel históricos de igual estructura; automatización avanzada y activos masivos fuera | 22-08-2026 | Contrato firmado en septiembre de 2026 | Sí | La firma del contrato acota y resuelve el alcance aprobado. | RESUELTA |
| CON-003 | Reimportación | F08 §11 | Actualizar/sin cambios y advertir duplicados | F07 Anexo A/§3.1 | Sin homologación, validación asistida, duplicados ni rollback | 16-09-2026 | Contrato firmado en septiembre de 2026 | No | El DF excede el contrato firmado. | ABIERTA |
| CON-004 | Volumen histórico | F08 §11 | Presenta 4.240 versus ~1.000 como discrepancia | F06 §8.1 y F07 | 4.240 corresponde al histórico; ~1.000 a casos activos futuros excluidos | 16-09-2026 | 24-08 / contrato firmado | Sí | Son universos distintos; el DF debe corregirse. | RESUELTA |
| CON-005 | Umbral de inactividad | F08 §12 | >15 días | F07 Anexo A | Período a definir por FIS | 16-09-2026 | Contrato firmado | No | 15 días no es baseline confirmado. | ABIERTA |
| CON-006 | Fuente productiva | F03 | Carpeta ya descargada | F08 pregunta 14 | Pregunta nuevamente por plataforma/API/correo/carpeta | Antes del 25-08-2026 | 16-09-2026 | Sí | Para Fase 1 la fuente es la carpeta; API y correo son evolución. | RESUELTA |
| CON-007 | Claim notice | F10/F07 | Claim notice es una de cuatro cartas | F07/F08 | También aparece carta de notificación a la naviera | Septiembre de 2026 | Contrato/DF | No | Debe confirmarse si son el mismo entregable. | ABIERTA |
| CON-008 | SUBRO | F06 §8.2 | La propuesta la mostraba como evolución | F07/F10 | Contrato y cliente la excluyen | 24-08-2026 | Septiembre de 2026 | Sí | Prevalece la exclusión del contrato firmado y la confirmación posterior. | RESUELTA |
| CON-009 | Primera versión | F05 | Próxima semana | F05/F11 | Semana siguiente o subsiguiente; 1-2 semanas | Posterior al 25-08-2026 | 15-09-2026 | Sí | Es una versión utilizable, no la entrega final. | RESUELTA |

## Cambios de alcance

| ID | Definición inicial | Cambio | Fecha | Solicitante | Motivo | Impacto | REQ afectados | Estado final |
|---|---|---|---|---|---|---|---|---|
| SCOPE-001 | Integración directa con plataforma como aspiración | Procesar desde carpeta ya descargada | Antes del 25-08-2026 | Ljubinka | Acceso/API no autorizado | Elimina descarga automática de Fase 1 | REQ-001, REQ-004 | Vigente: carpeta local |
| SCOPE-002 | Demo funcional | Consolidación productiva con backend, datos y login | 25-08 a septiembre de 2026 | FIS/NPR | Propuesta 167 aprobada y contrato firmado | Convierte el prototipo en producto | REQ-115, REQ-124 | Incluido |
| SCOPE-003 | Cartas formales ubicadas como evolución en la propuesta | Cuatro cartas estándar entran al alcance contractual | Contrato fechado 27-08; confirmado 09-10 de septiembre | Partes / Ljubinka | Aclaración contractual | Añade generación automatizada acotada | REQ-068 a REQ-074 | Incluidas |
| SCOPE-004 | Extracción avanzada ubicada como evolución en la propuesta | Extracción asistida de BL, facturas y liquidaciones entra al contrato | Contrato fechado 27-08-2026 | Partes | Necesaria para cálculo | Reduce ingreso manual con validación | REQ-027 a REQ-032 | Incluida |
| SCOPE-005 | SUBRO figuraba entre documentos posibles | SUBRO queda expresamente fuera | Contrato y confirmación 09-10 de septiembre | Partes / Ljubinka | Cierre de alcance | Reduce templates a cuatro | REQ-075 | Excluida |
| SCOPE-006 | Histórico precargado y migración amplia solicitada | Carga inicial ~4.240/39 e importación de nuevos Excel de igual estructura; automatización avanzada y activos masivos fuera | 22-08 a contrato fechado 27-08-2026 | Cliente / partes | Delimitación final firmada | Define importación recurrente acotada | REQ-100 a REQ-108 | Resuelto por contrato |
| SCOPE-007 | Posible continuidad posterior a FIS/Lawgistic | Fase 1 termina en un cambio de estado local | Contrato fechado 27-08-2026 | Partes | Control de alcance | Excluye integración y gestión posterior | REQ-084 | Vigente |

## Criterio cronológico aplicado

La propuesta 167 fue aprobada, pero el contrato firmado tiene prelación. Por ello F07 resuelve el alcance de migración, extracción y cartas; F10 confirma AoR/SUBRO. Siguen abiertas las fórmulas, reglas de prescripción, plantillas, inactividad y guardas de traspaso.
