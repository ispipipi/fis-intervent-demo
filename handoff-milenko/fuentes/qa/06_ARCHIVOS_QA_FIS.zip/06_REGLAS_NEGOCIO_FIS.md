# REGLAS DE NEGOCIO FIS

| ID | Regla | Fuente | REQ relacionados | ¿Está en DF? | Estado |
|---|---|---|---|---|---|
| RB-001 | La Fase 1 comienza con una carpeta documental ya descargada; no con acceso directo a la plataforma externa. | F03; F07 §3.1 | REQ-001, REQ-004 | Sí | VIGENTE |
| RB-002 | La carpeta completa debe poder cargarse de una vez. | F03; F07 Anexo A | REQ-002 | Sí | VIGENTE |
| RB-003 | Toda extracción, causa, mérito y cálculo automático queda sujeto a confirmación humana. | F01; F07 Anexo A | REQ-032, REQ-047 | Sí | VIGENTE |
| RB-004 | Una referencia duplicada genera advertencia; no fusión o eliminación automática. | F07 Anexo A; F08 §8.2 | REQ-015 | Sí | VIGENTE |
| RB-005 | La referencia debe seguir la convención FIS; su fórmula exacta está pendiente de formalización. | F01; F02 | REQ-013, REQ-016 | Parcial | PENDIENTE |
| RB-006 | La asignación de handler depende de la cartera de clientes; falta decidir si se incluye en Fase 1. | F02 14:22 | REQ-017 | No | REQUIERE VALIDACIÓN |
| RB-007 | Los faltantes se determinan contra un checklist aplicable al tipo de caso. | F01; F07 | REQ-020, REQ-022 | Parcial | PENDIENTE DE CHECKLIST |
| RB-008 | El usuario puede confirmar o corregir datos automáticos antes de que sean definitivos. | F07 Anexo A | REQ-012, REQ-032 | Sí | VIGENTE |
| RB-009 | Una evaluación baja de mérito no debe bloquear un caso si el handler decide continuarlo por razones comerciales. | F01 12:25 | REQ-048 | Parcial | VIGENTE NO FORMALIZADA |
| RB-010 | El método comparable exige embarque gemelo con variedad, calibre, destino y fecha similar. | F01 15:22 | REQ-050 | Parcial | VIGENTE |
| RB-011 | Los tres métodos se calculan/comparan y el handler selecciona uno con justificación. | F01; F07 | REQ-049, REQ-058, REQ-060 | Sí | VIGENTE |
| RB-012 | Los métodos de comparable y reporte no deben usar base neta sin aprobación, porque FIS explicó base bruta. | F01 15:22-19:03 | REQ-051, REQ-053 | No, el DF dice neto | CONTRADICCIÓN ABIERTA |
| RB-013 | El método 3 compara factura de exportación con venta bruta en destino. | F01; F06 | REQ-054 | Parcial | VIGENTE |
| RB-014 | Venta a firme, nota de crédito e ítems adicionales se aplican solo cuando corresponda y con respaldo. | F01; F07 | REQ-055 a REQ-057 | Sí/Parcial | VIGENTE; DETALLE PENDIENTE |
| RB-015 | USD y CLP son monedas de Fase 1; otras monedas requieren cambio de alcance. | F07 | REQ-061 a REQ-063 | Sí | VIGENTE |
| RB-016 | Las únicas cartas base incluidas son AoR, Harvest, LoA y claim notice. | F07; F10 | REQ-069 a REQ-072 | Sí | VIGENTE |
| RB-017 | SUBRO y certificados de destrucción no se generan en Fase 1. | F07; F10 | REQ-075, REQ-076 | Sí | VIGENTE |
| RB-018 | Una carta no se usa/emite hasta aprobación del handler. | F07 Anexo A | REQ-073 | Sí | VIGENTE |
| RB-019 | La solicitud documental se prepara, pero no se envía automáticamente por correo. | F07 §3.1 | REQ-025, REQ-026 | Sí | VIGENTE |
| RB-020 | El traspaso a FIS/Lawgistic es un cambio de estado local que cierra Preclaim. | F07 Anexo A | REQ-082 a REQ-084 | Sí | VIGENTE |
| RB-021 | Después del traspaso el cálculo queda bloqueado; el Gerente puede revertir solo con motivo. | F07 Anexo A | REQ-067, REQ-086 | Sí | VIGENTE |
| RB-022 | Para marítimo, la explicación operativa usa un año general y dos años para Chile/Perú desde descarga; debe validarse formalmente. | F01; F02 | REQ-090, REQ-091 | Parcial | PENDIENTE DE MATRIZ |
| RB-023 | Una alerta de inactividad debe basarse en un evento real registrado por el sistema. | F01 40:03-41:59 | REQ-089, REQ-093 | Parcial | PENDIENTE |
| RB-024 | El umbral de inactividad y sus destinatarios deben ser definidos por FIS; 15 días no está confirmado. | F07; F08 | REQ-094, REQ-095 | Parcial | PENDIENTE |
| RB-025 | El histórico inicial es ~4.240/39 y debe mantenerse separado de activos. | F05; F07 | REQ-100, REQ-102 | Sí | VIGENTE |
| RB-026 | Nuevos Excel históricos solo se importan sobre la misma estructura; no hay homologación, duplicados, rollback ni activos masivos. | F07 | REQ-104, REQ-106 a REQ-108 | No: DF se excede | CONTRADICCIÓN ABIERTA |
| RB-027 | Handler opera; Gerente supervisa/revierte; CEO/Dirección solo consulta. | F07 | REQ-111 a REQ-113 | Sí | VIGENTE |
| RB-028 | Los datos del caso solo se usan para el servicio y no para entrenar modelos generales. | F07 §10 | REQ-119 | Parcial | VIGENTE |
| RB-029 | Toda funcionalidad fuera del cuerpo contractual y Anexo A requiere una Solicitud de Cambio aprobada; el contrato firmado prevalece sobre la propuesta 167. | F07 §§1.4 y 4.2 | Todos | Sí | VIGENTE |

## Observación crítica

Las reglas RB-012, RB-022, RB-024 y RB-026 no pueden considerarse listas para desarrollo/aceptación. Deben cerrarse antes de congelar el baseline.
