# CATÁLOGO DE REQUERIMIENTOS FIS

Cada requerimiento es atómico y mantiene evidencia, interpretación, estado y cobertura. El catálogo está limitado al proyecto aprobado de la propuesta 167; no contiene requisitos de otros proyectos.

# Núcleo Intervent Preclaim

## Ingreso

### REQ-001

- **Descripción:** Procesar el caso desde una carpeta documental ya descargada de la plataforma del cliente.
- **Tipo:** Proceso
- **Fuente:** F03; F07 §1.1
- **Fecha:** Posterior al 21-07 y antes del 25-08; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** El acceso directo a la plataforma no fue autorizado.
- **Interpretación funcional:** La entrada productiva vigente de Fase 1 es una carpeta local entregada por FIS.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-023; DF-036
- **Cobertura:** COMPLETO
- **Observación:** El documento modela carga de carpeta y deja integraciones fuera.
- **Confianza:** ALTA

### REQ-002

- **Descripción:** Permitir cargar una carpeta documental completa sin subir archivos uno a uno.
- **Tipo:** Funcional
- **Fuente:** F01 19:10; F03; F07 Anexo A
- **Fecha:** 10-07; fecha no consignada; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** El trabajo manual actual descarga y procesa documentos individualmente.
- **Interpretación funcional:** La plataforma debe aceptar una carpeta completa.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-023; DF-036
- **Cobertura:** COMPLETO
- **Observación:** Cubierto en flujo y criterios de carga.
- **Confianza:** ALTA

### REQ-003

- **Descripción:** Permitir crear un caso manualmente y cargar archivos individuales cuando corresponda.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** El contrato admite alta manual además de la carpeta masiva.
- **Interpretación funcional:** Debe existir alta manual con datos mínimos.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente
- **DF relacionado:** DF-005; DF-035; DF-036
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

## Límite de integración

### REQ-004

- **Descripción:** No depender de API, robot, credenciales ni lectura directa de la plataforma externa en la Fase 1.
- **Tipo:** Integración
- **Fuente:** F02 18:29-30:38; F03; F07 §3.1
- **Fecha:** 21-07; posterior al 21-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** No se obtuvo acceso y la plataforma futura debía resolver la descarga.
- **Interpretación funcional:** La solución comienza después de la descarga; una integración futura exige cambio de alcance.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-017; DF-056
- **Cobertura:** COMPLETO
- **Observación:** La exclusión está descrita, aunque la pregunta de fuente productiva reaparece innecesariamente.
- **Confianza:** ALTA

## Documentos

### REQ-005

- **Descripción:** Clasificar automáticamente los documentos del expediente.
- **Tipo:** Funcional
- **Fuente:** F01 19:10; F03; F07 Anexo A
- **Fecha:** 10-07; posterior al 21-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** El equipo hoy identifica manualmente cada archivo.
- **Interpretación funcional:** El sistema propone categoría documental.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-006; DF-026; DF-037
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-006

- **Descripción:** Renombrar automáticamente cada documento conforme a referencia y tipo.
- **Tipo:** Funcional
- **Fuente:** F01 5:17; F03; F07 Anexo A
- **Fecha:** 10-07; posterior al 21-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Actualmente se cambia manualmente el nombre.
- **Interpretación funcional:** Debe generarse un nombre normalizado.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-006; DF-026; DF-037
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-007

- **Descripción:** Conservar el archivo y nombre original al normalizar el expediente.
- **Tipo:** Datos
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** El renombrado no debe destruir la evidencia original.
- **Interpretación funcional:** Mantener vínculo entre original y nombre normalizado.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-003; DF-025; DF-037
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-008

- **Descripción:** Aplicar reconocimiento de texto a documentos escaneados.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** La clasificación incluye OCR.
- **Interpretación funcional:** El PDF escaneado se procesa o queda para revisión.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-006; DF-036
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-009

- **Descripción:** Procesar como base PDF, XLSX, XLS y CSV.
- **Tipo:** Datos
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Formatos contractuales definidos.
- **Interpretación funcional:** La plataforma debe aceptar esos cuatro formatos.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-036
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-010

- **Descripción:** Evitar que un archivo incompatible bloquee el procesamiento del resto del lote.
- **Tipo:** Excepción
- **Fuente:** F08 §8.3
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** Regla incorporada en la definición funcional sin evidencia previa identificada.
- **Interpretación funcional:** Es una decisión de diseño razonable, pero requiere validación contractual.
- **Prioridad aparente:** Media
- **Estado temporal:** Requiere validación
- **DF relacionado:** DF-025; DF-036
- **Cobertura:** NO DETERMINABLE
- **Observación:** No aparece en reuniones ni contrato revisados.
- **Confianza:** BAJA

### REQ-011

- **Descripción:** Mostrar nivel de confianza de la clasificación automática.
- **Tipo:** UX
- **Fuente:** F08 §8.4; F06 §4.3
- **Fecha:** 16-09; 24-08-2026
- **Emisor:** Documento funcional / propuesta
- **Contexto original resumido:** El sistema debe transparentar incertidumbre.
- **Interpretación funcional:** Mostrar confianza y permitir revisión.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente con detalle por validar
- **DF relacionado:** DF-026; DF-037
- **Cobertura:** PARCIAL
- **Observación:** La propuesta y DF lo describen, pero el contrato no fija escala ni umbral.
- **Confianza:** MEDIA

### REQ-012

- **Descripción:** Permitir al handler corregir manualmente clasificación y nombre.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Toda propuesta automática queda sujeta a revisión.
- **Interpretación funcional:** Corrección manual con trazabilidad.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-026; DF-037; DF-054
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

## Referencia

### REQ-013

- **Descripción:** Generar o sugerir la referencia interna conforme a la convención de FIS.
- **Tipo:** Regla de negocio
- **Fuente:** F01 6:14-7:34; F02 7:25-11:14
- **Fecha:** 10-07; 21-07-2026
- **Emisor:** Ljubinka
- **Contexto original resumido:** La referencia codifica etapa, FIS, oponente, año, prescripción y correlativo.
- **Interpretación funcional:** El sistema debe construir la referencia con la convención vigente.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-024; DF-035
- **Cobertura:** PARCIAL
- **Observación:** El DF dice que debe respetar la convención, pero no la especifica.
- **Confianza:** ALTA

### REQ-014

- **Descripción:** Permitir corregir la referencia antes de continuar y auditar el cambio.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A; F08 §8.2
- **Fecha:** 27-08; 16-09-2026
- **Emisor:** Contrato / documento funcional
- **Contexto original resumido:** Errores de referencia pueden ocultar casos próximos a prescribir.
- **Interpretación funcional:** Editar con valor anterior, nuevo, usuario y fecha.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-024; DF-035
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-015

- **Descripción:** Advertir referencias duplicadas sin fusionar ni borrar casos automáticamente.
- **Tipo:** Validación
- **Fuente:** F07 Anexo A; F08 §8.2
- **Fecha:** 27-08; 16-09-2026
- **Emisor:** Contrato / documento funcional
- **Contexto original resumido:** Evitar duplicidad y pérdida de información.
- **Interpretación funcional:** Advertencia, resolución humana.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-005; DF-035
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-016

- **Descripción:** Gestionar el correlativo interno sin depender del número publicado manualmente en Teams.
- **Tipo:** Proceso
- **Fuente:** F02 8:54-11:14
- **Fecha:** 21-07-2026
- **Emisor:** Ljubinka
- **Contexto original resumido:** El correlativo se obtenía de un grupo de Teams.
- **Interpretación funcional:** El sistema debería controlar el siguiente correlativo o definir su fuente.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente no formalizado
- **DF relacionado:** —
- **Cobertura:** AUSENTE
- **Observación:** No aparece en el DF ni en el contrato.
- **Confianza:** MEDIA

## Asignación

### REQ-017

- **Descripción:** Asignar automáticamente el handler según la cartera de clientes mantenida por FIS.
- **Tipo:** Regla de negocio
- **Fuente:** F02 14:22-15:35
- **Fecha:** 21-07-2026
- **Emisor:** Ljubinka y Julio
- **Contexto original resumido:** Cada handler tiene clientes asignados y se autoasigna hoy.
- **Interpretación funcional:** Crear mantenedor cliente-handler y asignación automática.
- **Prioridad aparente:** Alta
- **Estado temporal:** Solicitud previa no incorporada al baseline firmado
- **DF relacionado:** —
- **Cobertura:** AUSENTE
- **Observación:** No aparece en la propuesta aprobada ni en el Anexo A firmado; no es incumplimiento del proyecto 167 y requiere Solicitud de Cambio.
- **Confianza:** ALTA

## Expediente

### REQ-018

- **Descripción:** Mantener un expediente digital único por caso.
- **Tipo:** Funcional
- **Fuente:** F02 15:35-16:31; F07 §1.1 y Anexo A
- **Fecha:** 21-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Evitar carpetas y planillas dispersas.
- **Interpretación funcional:** Centralizar datos, documentos, análisis y cálculo.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-003; DF-007
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

## Inventario

### REQ-019

- **Descripción:** Mostrar los documentos disponibles.
- **Tipo:** Funcional
- **Fuente:** F01 19:10; F03; F07 Anexo A
- **Fecha:** 10-07; fecha no consignada; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** El sistema debe inventariar lo recibido.
- **Interpretación funcional:** Lista visible de documentos presentes.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-028; DF-038
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-020

- **Descripción:** Identificar los documentos faltantes.
- **Tipo:** Funcional
- **Fuente:** F01 12:25; F03; F07 Anexo A
- **Fecha:** 10-07; fecha no consignada; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Los faltantes determinan si se puede calcular o recuperar.
- **Interpretación funcional:** Comparar presentes contra checklist.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-028; DF-038
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-021

- **Descripción:** Distinguir documentos solicitados, observados o reemplazados.
- **Tipo:** Datos
- **Fuente:** F08 §8.5
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** Estados documentales ampliados.
- **Interpretación funcional:** Cada documento o faltante debe tener estado.
- **Prioridad aparente:** Media
- **Estado temporal:** Requiere validación de detalle
- **DF relacionado:** DF-038
- **Cobertura:** PARCIAL
- **Observación:** Contrato confirma disponibles/faltantes y solicitud; no define observado/reemplazado.
- **Confianza:** MEDIA

### REQ-022

- **Descripción:** Usar un checklist configurable por tipo de caso.
- **Tipo:** Regla de negocio
- **Fuente:** F01 12:25-13:58; F07 §7
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** La documentación necesaria depende del daño y contraparte.
- **Interpretación funcional:** FIS debe entregar y validar checklists.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente; contenido pendiente
- **DF relacionado:** DF-028; DF-038; DF-056
- **Cobertura:** PARCIAL
- **Observación:** Existe función, pero el checklist oficial no está definido.
- **Confianza:** ALTA

### REQ-023

- **Descripción:** Permitir marcar un documento como no aplicable o desmarcar un faltante.
- **Tipo:** Excepción
- **Fuente:** F08 §8.5
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** No todos los documentos aplican a todos los casos.
- **Interpretación funcional:** El handler puede excluir justificadamente un faltante.
- **Prioridad aparente:** Media
- **Estado temporal:** Requiere validación
- **DF relacionado:** DF-038
- **Cobertura:** PARCIAL
- **Observación:** La necesidad es coherente, pero no consta como regla acordada en contrato o reuniones.
- **Confianza:** MEDIA

### REQ-024

- **Descripción:** Mostrar porcentaje de cobertura documental.
- **Tipo:** Reporte
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Indicador de avance documental.
- **Interpretación funcional:** Calcular cobertura sobre checklist aplicable.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente
- **DF relacionado:** DF-007; DF-038
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-025

- **Descripción:** Generar automáticamente el listado y texto para solicitar faltantes.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Reducir redacción manual.
- **Interpretación funcional:** Texto copiable o descargable, sin envío automático.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-028; DF-038
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

## Comunicaciones

### REQ-026

- **Descripción:** No enviar automáticamente por correo las solicitudes documentales en Fase 1.
- **Tipo:** Integración
- **Fuente:** F07 §3.1
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** El envío automático quedó excluido.
- **Interpretación funcional:** El usuario descarga o copia y envía por fuera.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-021; DF-038
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

## Extracción

### REQ-027

- **Descripción:** Extraer datos desde BL para alimentar ficha, análisis y cálculo.
- **Tipo:** Funcional
- **Fuente:** F01 36:07; F07 Anexo A; F10
- **Fecha:** 10-07; 27-08; 09–10 de septiembre de 2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** BL contiene datos usados en cartas y cálculo.
- **Interpretación funcional:** Extracción asistida, no decisión autónoma.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-008; DF-027; DF-039
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-028

- **Descripción:** Extraer datos y valores desde facturas.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A; F10
- **Fecha:** 27-08; 09–10 de septiembre de 2026
- **Emisor:** Contrato / confirmación de alcance
- **Contexto original resumido:** Necesario para métodos de pérdida.
- **Interpretación funcional:** Extracción asistida con confirmación.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-008; DF-027; DF-039
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-029

- **Descripción:** Extraer datos y valores desde liquidaciones.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A; F10
- **Fecha:** 27-08; 09–10 de septiembre de 2026
- **Emisor:** Contrato / confirmación de alcance
- **Contexto original resumido:** Necesario para métodos comparativos.
- **Interpretación funcional:** Extracción asistida con confirmación.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-008; DF-027; DF-039
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-030

- **Descripción:** Extraer información de los demás tipos documentales previamente definidos y validados.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** El alcance no cubre formatos o tipos ilimitados.
- **Interpretación funcional:** Corpus documental cerrado para Fase 1.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente; corpus pendiente
- **DF relacionado:** DF-008; DF-027; DF-039
- **Cobertura:** PARCIAL
- **Observación:** El DF enumera ejemplos, pero no cierra el corpus productivo ni prioridades.
- **Confianza:** ALTA

### REQ-031

- **Descripción:** Mostrar el documento de origen de cada dato extraído.
- **Tipo:** Trazabilidad
- **Fuente:** F06 §4.6; F08 §8.6
- **Fecha:** 24-08; 16-09-2026
- **Emisor:** Propuesta / documento funcional
- **Contexto original resumido:** La recomendación debe ser explicable.
- **Interpretación funcional:** Cada campo debe mantener su fuente.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-027; DF-039
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** MEDIA

### REQ-032

- **Descripción:** Permitir que el handler confirme, edite o descarte cada dato propuesto.
- **Tipo:** Permiso
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** La automatización no reemplaza decisión humana.
- **Interpretación funcional:** Dato definitivo solo tras confirmación.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-027; DF-039; DF-054
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

## Datos

### REQ-033

- **Descripción:** Registrar y validar asegurado o cliente sin confundirlo con exportador o comprador.
- **Tipo:** Datos
- **Fuente:** F01 2:50-5:17; F08 §8.6
- **Fecha:** 10-07; 16-09-2026
- **Emisor:** Ljubinka / documento funcional
- **Contexto original resumido:** Hay múltiples actores del siniestro.
- **Interpretación funcional:** Campo con revisión de razón social y rol.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-039
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** MEDIA

### REQ-034

- **Descripción:** Registrar transportista u oponente objeto del recupero.
- **Tipo:** Datos
- **Fuente:** F01 6:14; F08 §8.6
- **Fecha:** 10-07; 16-09-2026
- **Emisor:** Ljubinka / documento funcional
- **Contexto original resumido:** Forma parte de referencia y reclamo.
- **Interpretación funcional:** Campo confirmado por handler.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-039
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-035

- **Descripción:** Registrar nave, viaje y contenedor, validando que correspondan al mismo embarque.
- **Tipo:** Validación
- **Fuente:** F02 6:20-12:47; F08 §8.6
- **Fecha:** 21-07; 16-09-2026
- **Emisor:** Ljubinka / documento funcional
- **Contexto original resumido:** Información copiada manualmente desde plataforma y documentos.
- **Interpretación funcional:** Datos relacionados y trazables.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-039
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-036

- **Descripción:** Registrar producto, variedad, cantidad y unidad de carga.
- **Tipo:** Datos
- **Fuente:** F01 15:22-19:03; F08 §8.6
- **Fecha:** 10-07; 16-09-2026
- **Emisor:** Ljubinka / documento funcional
- **Contexto original resumido:** Los atributos determinan comparabilidad.
- **Interpretación funcional:** Datos estructurados para cálculo.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-039
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** MEDIA

### REQ-037

- **Descripción:** Registrar puertos y fechas de embarque y descarga.
- **Tipo:** Datos
- **Fuente:** F02 11:14-13:35; F08 §8.6
- **Fecha:** 21-07; 16-09-2026
- **Emisor:** Ljubinka / documento funcional
- **Contexto original resumido:** La descarga activa prescripción.
- **Interpretación funcional:** Campos con fuente y fecha real/estimada.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-039
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-038

- **Descripción:** Permitir que el CS Claim Number esté ausente hasta que exista.
- **Tipo:** Excepción
- **Fuente:** F08 §8.6
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** Dato no siempre disponible al inicio.
- **Interpretación funcional:** Campo opcional sin impedir creación.
- **Prioridad aparente:** Media
- **Estado temporal:** Requiere validación
- **DF relacionado:** DF-039
- **Cobertura:** NO DETERMINABLE
- **Observación:** No se encontró confirmación externa al DF.
- **Confianza:** BAJA

### REQ-039

- **Descripción:** Registrar inspector o surveyor asociado al caso.
- **Tipo:** Datos
- **Fuente:** F02 24:18-24:44; F06 §4.6
- **Fecha:** 21-07; 24-08-2026
- **Emisor:** Ljubinka / propuesta
- **Contexto original resumido:** El correo no siempre contiene inspector; otros documentos sí.
- **Interpretación funcional:** Campo extraíble y corregible.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente
- **DF relacionado:** DF-039
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** MEDIA

## Fechas

### REQ-040

- **Descripción:** Distinguir ETA de fecha real de descarga y permitir corrección trazable.
- **Tipo:** Regla de negocio
- **Fuente:** F02 11:14-13:35; F08 §8.2
- **Fecha:** 21-07; 16-09-2026
- **Emisor:** Ljubinka / documento funcional
- **Contexto original resumido:** La prescripción corre desde descarga real.
- **Interpretación funcional:** No usar ETA como fecha definitiva sin confirmación.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-035; DF-039; DF-056
- **Cobertura:** COMPLETO
- **Observación:** Cubierto como distinción; escenarios exactos siguen abiertos.
- **Confianza:** ALTA

## Búsqueda

### REQ-041

- **Descripción:** Buscar casos por referencia y datos operativos relevantes.
- **Tipo:** UX
- **Fuente:** F02 5:26-6:20; F06 §4.12; F08 §11
- **Fecha:** 21-07; 24-08; 16-09-2026
- **Emisor:** Ljubinka / propuesta / DF
- **Contexto original resumido:** La operación actual usa búsqueda y filtros.
- **Interpretación funcional:** Búsqueda por referencia, cliente, nave, contenedor, handler y estado según disponibilidad.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente
- **DF relacionado:** DF-047
- **Cobertura:** PARCIAL
- **Observación:** DF lo define claramente para histórico; falta explicitar mismo alcance en casos activos.
- **Confianza:** MEDIA

## Análisis

### REQ-042

- **Descripción:** Generar un resumen breve y editable del caso.
- **Tipo:** Funcional
- **Fuente:** F02 6:20-7:25; F03; F07 Anexo A
- **Fecha:** 21-07; fecha no consignada; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Hoy se redacta manualmente.
- **Interpretación funcional:** Resumen asistido confirmado por handler.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-029; DF-040
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-043

- **Descripción:** Proponer el tipo de caso según documentos disponibles.
- **Tipo:** Funcional
- **Fuente:** F03; F07 Anexo A
- **Fecha:** Fecha no consignada; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** La carpeta debe indicar qué tipo de caso es.
- **Interpretación funcional:** Clasificación editable.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-029; DF-040
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-044

- **Descripción:** Proponer una causa potencial de daño o siniestro.
- **Tipo:** Funcional
- **Fuente:** F01 11:03-12:25; F03; F07 Anexo A
- **Fecha:** 10-07; fecha no consignada; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Datos de inspector y termógrafos pueden sustentar la causa.
- **Interpretación funcional:** Hipótesis, no conclusión jurídica definitiva.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-029; DF-040
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-045

- **Descripción:** Mostrar documentos y datos que sustentan la causa propuesta.
- **Tipo:** Trazabilidad
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** La causa debe ser explicable.
- **Interpretación funcional:** Vincular evidencia.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-029; DF-040
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-046

- **Descripción:** Entregar una recomendación preliminar de mérito.
- **Tipo:** Funcional
- **Fuente:** F01 10:18-12:25; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Se puede asistir el análisis sin decidir.
- **Interpretación funcional:** Recomendación editable con explicación.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-029; DF-040
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-047

- **Descripción:** Reservar al handler la decisión final sobre mérito, causa y continuidad.
- **Tipo:** Permiso
- **Fuente:** F01 10:34-12:25; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Existen matices comerciales no automatizables.
- **Interpretación funcional:** La plataforma nunca decide definitivamente.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-009; DF-029; DF-040; DF-054
- **Cobertura:** COMPLETO
- **Observación:** Cubierto de forma consistente.
- **Confianza:** ALTA

### REQ-048

- **Descripción:** Permitir continuar casos con mérito jurídico débil por razones comerciales justificadas.
- **Tipo:** Excepción
- **Fuente:** F01 12:25
- **Fecha:** 10-07-2026
- **Emisor:** Ljubinka
- **Contexto original resumido:** Un transportista amigable puede permitir acuerdo.
- **Interpretación funcional:** El sistema no debe bloquear por una evaluación automática baja.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-040
- **Cobertura:** PARCIAL
- **Observación:** La revisión humana evita el bloqueo, pero la excepción comercial no está documentada expresamente.
- **Confianza:** ALTA

## Cálculo

### REQ-049

- **Descripción:** Calcular y mostrar comparativamente tres escenarios de pérdida.
- **Tipo:** Funcional
- **Fuente:** F01 13:58-14:33; F03; F07 Anexo A
- **Fecha:** 10-07; fecha no consignada; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** El equipo calcula tres formas y selecciona una.
- **Interpretación funcional:** Los tres resultados deben verse juntos.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-030; DF-041
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-050

- **Descripción:** Método 1: comparar con un embarque gemelo de misma variedad, calibre, destino y fecha similar.
- **Tipo:** Regla de negocio
- **Fuente:** F01 15:22-19:03
- **Fecha:** 10-07-2026
- **Emisor:** Ljubinka
- **Contexto original resumido:** Criterios explícitos de comparabilidad.
- **Interpretación funcional:** La comparabilidad debe validarse antes de usar el método.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-041; DF-042
- **Cobertura:** PARCIAL
- **Observación:** El DF menciona producto, unidades y ajustes, pero omite los cuatro criterios completos.
- **Confianza:** ALTA

### REQ-051

- **Descripción:** En métodos de comparable/SMV, usar la base bruta acordada y no cambiarla a neta sin validación.
- **Tipo:** Regla de negocio
- **Fuente:** F01 15:22-19:03
- **Fecha:** 10-07-2026
- **Emisor:** Ljubinka
- **Contexto original resumido:** Indicó que en comparable o reporte de mercado consideran el bruto de la liquidación.
- **Interpretación funcional:** La fórmula exacta debe preservar esa base o validarse con FIS.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente; fórmula por cerrar
- **DF relacionado:** DF-041
- **Cobertura:** DISTINTO
- **Observación:** El DF define valor neto esperado versus neto obtenido, lo que contradice la explicación de la reunión.
- **Confianza:** ALTA

### REQ-052

- **Descripción:** Método 2: comparar contra un reporte de mercado aplicable a fecha y plaza.
- **Tipo:** Regla de negocio
- **Fuente:** F01 15:22-19:03
- **Fecha:** 10-07-2026
- **Emisor:** Ljubinka
- **Contexto original resumido:** Se usa cuando no hay liquidación comparable.
- **Interpretación funcional:** Seleccionar reporte, fecha, plaza, unidad y moneda.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-041
- **Cobertura:** COMPLETO
- **Observación:** Cubierto en términos generales.
- **Confianza:** ALTA

### REQ-053

- **Descripción:** En método de reporte de mercado, mantener la base bruta explicada por FIS.
- **Tipo:** Regla de negocio
- **Fuente:** F01 15:22-19:03
- **Fecha:** 10-07-2026
- **Emisor:** Ljubinka
- **Contexto original resumido:** La reunión agrupa comparable y reporte como cálculos sobre bruto.
- **Interpretación funcional:** No asumir base neta.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente; fórmula por cerrar
- **DF relacionado:** DF-041
- **Cobertura:** DISTINTO
- **Observación:** El DF usa resultado neto de la liquidación afectada.
- **Confianza:** ALTA

### REQ-054

- **Descripción:** Método 3: comparar valor de factura de exportación con venta bruta en destino.
- **Tipo:** Regla de negocio
- **Fuente:** F01 15:22-19:03; F06 §4.8
- **Fecha:** 10-07; 24-08-2026
- **Emisor:** Ljubinka / propuesta
- **Contexto original resumido:** Tercer método usado si los anteriores no muestran pérdida o no aplican.
- **Interpretación funcional:** La base de venta debe quedar definida como bruta, salvo acuerdo posterior.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-041
- **Cobertura:** PARCIAL
- **Observación:** El DF admite venta o liquidación y costos aplicables, sin fijar claramente venta bruta.
- **Confianza:** ALTA

### REQ-055

- **Descripción:** Contemplar ventas a firme con precio fijo.
- **Tipo:** Regla de negocio
- **Fuente:** F01 15:22-19:03; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** En ciertos mercados existe precio fijo.
- **Interpretación funcional:** Aplicar flujo específico.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-041
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-056

- **Descripción:** Contemplar notas de crédito en el cálculo cuando corresponda.
- **Tipo:** Regla de negocio
- **Fuente:** F01 15:22-19:03; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Venta a firme puede respaldarse con nota de crédito.
- **Interpretación funcional:** Registrar monto, signo, motivo y regla.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente; regla exacta pendiente
- **DF relacionado:** DF-041; DF-042
- **Cobertura:** PARCIAL
- **Observación:** Función cubierta, pero signo y límite siguen abiertos.
- **Confianza:** ALTA

### REQ-057

- **Descripción:** Permitir rubros adicionales autorizados con respaldo y justificación.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** El contrato los incluye.
- **Interpretación funcional:** Cada ítem debe registrar concepto, monto, moneda y documento.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente
- **DF relacionado:** DF-041
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-058

- **Descripción:** Permitir comparar los resultados y seleccionar el método aplicable.
- **Tipo:** Funcional
- **Fuente:** F01 13:58-14:33; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** La selección es humana.
- **Interpretación funcional:** Vista comparativa y selección explícita.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-030; DF-041
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-059

- **Descripción:** Permitir seleccionar el cálculo más favorable para el recupero, sujeto a criterio del handler.
- **Tipo:** Regla de negocio
- **Fuente:** F01 13:58-14:33
- **Fecha:** 10-07-2026
- **Emisor:** Ljubinka
- **Contexto original resumido:** FIS calcula tres formas y se queda con la que más conviene.
- **Interpretación funcional:** La plataforma no debe imponer un orden sin validación.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-041; DF-042
- **Cobertura:** PARCIAL
- **Observación:** DF exige selección/justificación, pero no refleja el criterio comercial de mayor beneficio.
- **Confianza:** ALTA

### REQ-060

- **Descripción:** Exigir justificación del método seleccionado.
- **Tipo:** Validación
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Evitar selección opaca.
- **Interpretación funcional:** No cerrar cálculo sin justificación.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-030; DF-041
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

## Moneda

### REQ-061

- **Descripción:** Soportar cálculos en USD.
- **Tipo:** Datos
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Moneda contractual.
- **Interpretación funcional:** Registrar moneda en entradas y resultado.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-043
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-062

- **Descripción:** Soportar cálculos en CLP.
- **Tipo:** Datos
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Moneda contractual.
- **Interpretación funcional:** Registrar moneda en entradas y resultado.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-043
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-063

- **Descripción:** Cuando se comparen monedas distintas, exigir fecha y tipo de cambio o impedir el cálculo.
- **Tipo:** Validación
- **Fuente:** F08 §9.2
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** Necesidad lógica incorporada al DF.
- **Interpretación funcional:** Definir fuente, fecha, redondeo y permisos.
- **Prioridad aparente:** Alta
- **Estado temporal:** Requiere validación
- **DF relacionado:** DF-043
- **Cobertura:** PARCIAL
- **Observación:** El comportamiento está bien formulado, pero fuente y regla no están acordadas.
- **Confianza:** MEDIA

## Cálculo

### REQ-064

- **Descripción:** Definir fórmulas, costos, ajustes, unidades, tolerancias, límites y redondeos exactos.
- **Tipo:** Regla de negocio
- **Fuente:** F08 §9.1; F07 §7
- **Fecha:** 16-09; 27-08-2026
- **Emisor:** Documento funcional / contrato
- **Contexto original resumido:** La implementación no puede cerrarse con descripciones genéricas.
- **Interpretación funcional:** FIS debe aprobar especificación matemática por método.
- **Prioridad aparente:** Alta
- **Estado temporal:** Pendiente
- **DF relacionado:** DF-042; DF-056
- **Cobertura:** PARCIAL
- **Observación:** El DF identifica el vacío, pero no lo resuelve.
- **Confianza:** ALTA

### REQ-065

- **Descripción:** Conservar entradas, fuentes, moneda, fecha y resultado de cada cálculo.
- **Tipo:** Trazabilidad
- **Fuente:** F07 Anexo A; F08 §9
- **Fecha:** 27-08; 16-09-2026
- **Emisor:** Contrato / DF
- **Contexto original resumido:** El cálculo debe ser reproducible.
- **Interpretación funcional:** Snapshot auditable por versión.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-041; DF-054
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-066

- **Descripción:** Permitir editar y recalcular antes del traspaso.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A; F08 §14
- **Fecha:** 27-08; 16-09-2026
- **Emisor:** Contrato / DF
- **Contexto original resumido:** La revisión ocurre en Preclaim.
- **Interpretación funcional:** Editable por handler autorizado.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-041; DF-053
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-067

- **Descripción:** Bloquear la edición del cálculo después del traspaso.
- **Tipo:** Validación
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** El traspaso cierra Preclaim.
- **Interpretación funcional:** Solo una reversión autorizada reabre.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-003; DF-033; DF-053
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

## Cartas

### REQ-068

- **Descripción:** Generar cartas estándar usando datos confirmados del expediente y del BL cuando corresponda.
- **Tipo:** Funcional
- **Fuente:** F01 36:07-36:44; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Cartas de clientes directos se completaban manualmente.
- **Interpretación funcional:** Parametrización desde ficha y documentos.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-010; DF-031; DF-044
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-069

- **Descripción:** Generar AoR.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A; F10
- **Fecha:** 27-08; 09–10 de septiembre de 2026
- **Emisor:** Contrato / Ljubinka
- **Contexto original resumido:** Confirmación posterior explícita.
- **Interpretación funcional:** Template base incluido.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-010; DF-044
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-070

- **Descripción:** Generar Harvest.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A; F10
- **Fecha:** 27-08; 09–10 de septiembre de 2026
- **Emisor:** Contrato / Ljubinka
- **Contexto original resumido:** Confirmación explícita.
- **Interpretación funcional:** Template base incluido.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-010; DF-044
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-071

- **Descripción:** Generar LoA.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A; F10
- **Fecha:** 27-08; 09–10 de septiembre de 2026
- **Emisor:** Contrato / Ljubinka
- **Contexto original resumido:** Confirmación explícita.
- **Interpretación funcional:** Template base incluido.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-010; DF-044
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-072

- **Descripción:** Generar claim notice.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A; F10
- **Fecha:** 27-08; 09–10 de septiembre de 2026
- **Emisor:** Contrato / Ljubinka
- **Contexto original resumido:** Confirmación explícita.
- **Interpretación funcional:** Template base incluido.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-010; DF-044
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-073

- **Descripción:** Exigir revisión y aprobación del handler antes de utilizar o emitir una carta.
- **Tipo:** Permiso
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Evitar emisión automática con datos no confirmados.
- **Interpretación funcional:** Paso obligatorio antes de descarga final.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-031; DF-044; DF-045
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-074

- **Descripción:** Mantener versión, vigencia y estado activo de templates base.
- **Tipo:** Trazabilidad
- **Fuente:** F08 §10.1
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** Control de cambios de plantillas.
- **Interpretación funcional:** Mantenedor acotado, no editor libre.
- **Prioridad aparente:** Media
- **Estado temporal:** Requiere validación de detalle
- **DF relacionado:** DF-045
- **Cobertura:** PARCIAL
- **Observación:** Es diseño útil, pero contrato no define todas estas operaciones.
- **Confianza:** MEDIA

### REQ-075

- **Descripción:** Excluir la generación automática de SUBRO de la Fase 1.
- **Tipo:** Excepción
- **Fuente:** F07 §3.1; F10
- **Fecha:** 27-08; 09–10 de septiembre de 2026
- **Emisor:** Contrato / Ljubinka
- **Contexto original resumido:** La confirmación final la dejó fuera.
- **Interpretación funcional:** No tratarla como quinto template incluido.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-020; DF-044
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-076

- **Descripción:** Excluir certificados de destrucción de la Fase 1.
- **Tipo:** Excepción
- **Fuente:** F07 §3.1
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Documento no contratado.
- **Interpretación funcional:** Requiere cambio de alcance.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-020; DF-044
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-077

- **Descripción:** Excluir un editor avanzado de plantillas por cliente, naviera o jurisdicción.
- **Tipo:** Excepción
- **Fuente:** F07 §3.1
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Solo templates base parametrizados.
- **Interpretación funcional:** Cambios avanzados se cotizan aparte.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente
- **DF relacionado:** DF-020; DF-044; DF-045
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-078

- **Descripción:** Validar formatos oficiales, texto legal, campos obligatorios y reglas de firma de cada carta.
- **Tipo:** Datos
- **Fuente:** F07 §7; F08 §10
- **Fecha:** 27-08; 16-09-2026
- **Emisor:** Contrato / DF
- **Contexto original resumido:** FIS debe entregar o validar plantillas.
- **Interpretación funcional:** No cerrar QA de cartas sin estos insumos.
- **Prioridad aparente:** Alta
- **Estado temporal:** Pendiente
- **DF relacionado:** DF-044; DF-056
- **Cobertura:** PARCIAL
- **Observación:** El DF declara el pendiente, pero aún no hay definición.
- **Confianza:** ALTA

### REQ-079

- **Descripción:** Definir si “carta de notificación a la naviera” es el claim notice o un documento distinto.
- **Tipo:** Pregunta / nomenclatura
- **Fuente:** F07 Anexo A; F08 §§10 y 19
- **Fecha:** 27-08; 16-09-2026
- **Emisor:** Contrato / DF
- **Contexto original resumido:** Ambos nombres aparecen como salidas.
- **Interpretación funcional:** Evitar duplicar o omitir un entregable.
- **Prioridad aparente:** Alta
- **Estado temporal:** Dudoso
- **DF relacionado:** DF-044; DF-057
- **Cobertura:** NO DETERMINABLE
- **Observación:** No existe equivalencia explícita en las fuentes.
- **Confianza:** MEDIA

## Estados

### REQ-080

- **Descripción:** Usar los estados datos incompletos, preclaim, documentación pendiente, cálculo completo, traspasado a FIS y traspasado a Lawgistic.
- **Tipo:** Datos
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Catálogo contractual.
- **Interpretación funcional:** Estados productivos mínimos.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-033
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-081

- **Descripción:** Definir guardas y transiciones permitidas entre los estados.
- **Tipo:** Regla de negocio
- **Fuente:** F08 §§7 y 14
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** El catálogo por sí solo no evita saltos inválidos.
- **Interpretación funcional:** Especificar acción, actor y condición por transición.
- **Prioridad aparente:** Alta
- **Estado temporal:** Pendiente
- **DF relacionado:** DF-033; DF-053
- **Cobertura:** PARCIAL
- **Observación:** DF describe condiciones generales, pero no una máquina de estados cerrada.
- **Confianza:** ALTA

## Traspaso

### REQ-082

- **Descripción:** Permitir cerrar Preclaim con destino FIS para recupero extrajudicial.
- **Tipo:** Proceso
- **Fuente:** F01 14:33; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Destino operativo.
- **Interpretación funcional:** Cambio de estado local.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-032; DF-053
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-083

- **Descripción:** Permitir cerrar Preclaim con destino Lawgistic para recupero judicial.
- **Tipo:** Proceso
- **Fuente:** F01 14:33; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Destino operativo.
- **Interpretación funcional:** Cambio de estado local.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-032; DF-053
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-084

- **Descripción:** Tratar el traspaso como cierre local sin integración ni gestión posterior.
- **Tipo:** Integración
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Las integraciones y etapas posteriores al traspaso quedan fuera del primer proyecto aprobado.
- **Interpretación funcional:** No enviar datos a sistemas externos en Fase 1.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-015; DF-017; DF-053
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-085

- **Descripción:** Definir el checklist mínimo que habilita el traspaso.
- **Tipo:** Validación
- **Fuente:** F08 §14 y pregunta 13
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** Se mencionan ficha revisada, faltantes confirmados, método y reporte.
- **Interpretación funcional:** Convertirlo en regla bloqueante aprobada por FIS.
- **Prioridad aparente:** Alta
- **Estado temporal:** Pendiente
- **DF relacionado:** DF-053; DF-056
- **Cobertura:** PARCIAL
- **Observación:** La propuesta del DF no está confirmada por el cliente.
- **Confianza:** ALTA

### REQ-086

- **Descripción:** Permitir al Gerente revertir un traspaso solo con motivo obligatorio.
- **Tipo:** Permiso
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Control de excepciones.
- **Interpretación funcional:** Registrar usuario, fecha y motivo.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-034; DF-053
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-087

- **Descripción:** No borrar documentos, observaciones ni versiones al traspasar o revertir.
- **Tipo:** Trazabilidad
- **Fuente:** F08 §14
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** Preservación del expediente.
- **Interpretación funcional:** Reversión no destructiva.
- **Prioridad aparente:** Alta
- **Estado temporal:** Requiere validación de detalle
- **DF relacionado:** DF-053; DF-054
- **Cobertura:** PARCIAL
- **Observación:** Consistente con auditoría, pero no se explicita en contrato.
- **Confianza:** MEDIA

## Auditoría

### REQ-088

- **Descripción:** Registrar usuario, fecha y hora de cambios de estado, documentos, cálculos, análisis y cartas.
- **Tipo:** Trazabilidad
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Historial auditable.
- **Interpretación funcional:** Eventos inmutables y consultables.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-054
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-089

- **Descripción:** Definir qué cuenta como movimiento real y evitar que un usuario antedate una gestión.
- **Tipo:** Validación
- **Fuente:** F01 40:03-41:59
- **Fecha:** 10-07-2026
- **Emisor:** Ljubinka / Julio
- **Contexto original resumido:** Existe riesgo de declarar manualmente una actualización inexistente.
- **Interpretación funcional:** Usar timestamp del sistema y fuente del evento.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente no formalizado
- **DF relacionado:** DF-049; DF-054
- **Cobertura:** PARCIAL
- **Observación:** Hay auditoría general, pero no regla anti-backdating ni definición de movimiento.
- **Confianza:** ALTA

## Prescripción

### REQ-090

- **Descripción:** Aplicar reglas de La Haya y Hamburgo, incluyendo un año para la mayoría y dos años para Chile/Perú marítimo según lo explicado.
- **Tipo:** Regla de negocio
- **Fuente:** F01 37:55-39:26; F02 11:14-13:35; F07 Anexo A
- **Fecha:** 10-07; 21-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** La referencia y alertas dependen de la fecha límite.
- **Interpretación funcional:** Configurar jurisdicción, plazo y fecha base.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente; parametrización pendiente
- **DF relacionado:** DF-012; DF-039
- **Cobertura:** PARCIAL
- **Observación:** DF menciona jurisdicción y regla, pero no fija los plazos explicados.
- **Confianza:** ALTA

### REQ-091

- **Descripción:** Usar la fecha real de descarga como fecha base cuando corresponda.
- **Tipo:** Regla de negocio
- **Fuente:** F01 37:55; F02 11:14-13:35
- **Fecha:** 10-07; 21-07-2026
- **Emisor:** Ljubinka
- **Contexto original resumido:** La custodia y el plazo comienzan desde descarga.
- **Interpretación funcional:** Mostrar fecha base y fuente.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-039; DF-056
- **Cobertura:** PARCIAL
- **Observación:** DF distingue ETA/real, pero todavía pregunta qué fecha activa la regla en cada escenario.
- **Confianza:** ALTA

### REQ-092

- **Descripción:** Mostrar fecha límite, días restantes, vencimiento y nivel de riesgo.
- **Tipo:** Reporte
- **Fuente:** F01 37:55-39:26; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Reemplazar semáforo manual.
- **Interpretación funcional:** Indicadores visibles en ficha y dashboard.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-012; DF-049; DF-051
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

## Seguimiento

### REQ-093

- **Descripción:** Identificar y alertar casos sin movimiento.
- **Tipo:** Reporte
- **Fuente:** F01 40:03-42:31; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Las revisiones manuales son quincenales y caso a caso.
- **Interpretación funcional:** Alerta basada en último evento válido.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-049; DF-051
- **Cobertura:** COMPLETO
- **Observación:** Función cubierta; regla exacta pendiente.
- **Confianza:** ALTA

### REQ-094

- **Descripción:** Definir si la inactividad se mide en más de 15 días hábiles o corridos y qué estados se excluyen.
- **Tipo:** Regla de negocio
- **Fuente:** F06 §8.3; F07 Anexo A; F08 §12
- **Fecha:** 24-08; 27-08; 16-09-2026
- **Emisor:** Propuesta / contrato / DF
- **Contexto original resumido:** 15 días aparece como evolución; contrato dice período definido por FIS.
- **Interpretación funcional:** No fijar el umbral sin aprobación explícita.
- **Prioridad aparente:** Alta
- **Estado temporal:** Pendiente
- **DF relacionado:** DF-049; DF-056
- **Cobertura:** NO DETERMINABLE
- **Observación:** El DF propone 15 días, pero no hay confirmación del cliente.
- **Confianza:** ALTA

### REQ-095

- **Descripción:** Definir destinatarios y canal de las alertas según rol.
- **Tipo:** Permiso
- **Fuente:** F01 39:26; F08 §12
- **Fecha:** 10-07; 16-09-2026
- **Emisor:** Julio / DF
- **Contexto original resumido:** Se propusieron alertas discriminadas por perfil.
- **Interpretación funcional:** FIS debe aprobar quién recibe qué alerta.
- **Prioridad aparente:** Media
- **Estado temporal:** Pendiente
- **DF relacionado:** DF-049; DF-056
- **Cobertura:** NO DETERMINABLE
- **Observación:** Idea del proveedor, no acuerdo final demostrado.
- **Confianza:** MEDIA

## Dashboard

### REQ-096

- **Descripción:** Mostrar cartera por estados, pendientes, pérdida, prescripción y handler.
- **Tipo:** Reporte
- **Fuente:** F01 37:10-42:31; F07 Anexo A
- **Fecha:** 10-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Necesidad de control y visibilidad gerencial.
- **Interpretación funcional:** Dashboard operativo filtrable.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-013; DF-051
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-097

- **Descripción:** Comparar handlers por carga, pendientes, alertas, cobertura, cálculo y tiempos.
- **Tipo:** Reporte
- **Fuente:** F07 Anexo A; F06 §4.11
- **Fecha:** 27-08; 24-08-2026
- **Emisor:** Contrato / propuesta
- **Contexto original resumido:** Vista benchmark incluida.
- **Interpretación funcional:** Definir periodo y audiencia.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente; métricas por validar
- **DF relacionado:** DF-013; DF-051
- **Cobertura:** PARCIAL
- **Observación:** Función cubierta; periodo y uso no definidos.
- **Confianza:** ALTA

## Reportes

### REQ-098

- **Descripción:** Generar un informe de revisión consolidado del caso.
- **Tipo:** Reporte
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Salida para el cierre Preclaim.
- **Interpretación funcional:** Resumen de documentos, causa, mérito y cálculo.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-032; DF-057
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-099

- **Descripción:** Generar una carta de notificación a la naviera descargable en formato texto.
- **Tipo:** Reporte
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Entregable contractual adicionalmente nombrado.
- **Interpretación funcional:** Debe aclararse su relación con claim notice.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente con nomenclatura pendiente
- **DF relacionado:** DF-031; DF-044; DF-057
- **Cobertura:** PARCIAL
- **Observación:** Función aparece, pero existe ambigüedad de duplicación con claim notice.
- **Confianza:** ALTA

## Histórico

### REQ-100

- **Descripción:** Cargar inicialmente aproximadamente 4.240 registros distribuidos en 39 hojas.
- **Tipo:** Datos
- **Fuente:** F05 2:00; F07 Anexo A
- **Fecha:** Posterior al 25-08; 27-08-2026
- **Emisor:** Julio / contrato
- **Contexto original resumido:** El demo ya contenía más de 4.000 casos.
- **Interpretación funcional:** Carga inicial incluida.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-014; DF-046
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-101

- **Descripción:** Permitir búsqueda sobre la memoria histórica.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** El histórico debe ser consultable.
- **Interpretación funcional:** Buscar por campos disponibles.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-014; DF-047
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-102

- **Descripción:** Mantener registros históricos separados de los casos activos y fuera de sus indicadores operativos.
- **Tipo:** Regla de negocio
- **Fuente:** F06 §4.12; F08 §11
- **Fecha:** 24-08; 16-09-2026
- **Emisor:** Propuesta / DF
- **Contexto original resumido:** No contaminar cartera activa.
- **Interpretación funcional:** Separación lógica y reportable.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-047
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** MEDIA

### REQ-103

- **Descripción:** Conservar archivo, hoja, fila y origen de los registros importados cuando estén disponibles.
- **Tipo:** Trazabilidad
- **Fuente:** F06 §4.12; F08 §11
- **Fecha:** 24-08; 16-09-2026
- **Emisor:** Propuesta / DF
- **Contexto original resumido:** Necesario para rastrear la fuente Excel.
- **Interpretación funcional:** Persistir metadatos de origen.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente
- **DF relacionado:** DF-046; DF-047
- **Cobertura:** PARCIAL
- **Observación:** DF menciona archivo/origen, pero no asegura hoja/fila como la propuesta.
- **Confianza:** MEDIA

### REQ-104

- **Descripción:** Permitir importar nuevos archivos Excel al histórico con la misma estructura de la carga inicial.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Importación recurrente incluida de forma acotada.
- **Interpretación funcional:** Agregar registros sobre la misma base.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-046; DF-048
- **Cobertura:** COMPLETO
- **Observación:** Cubierto en términos generales.
- **Confianza:** ALTA

## Migración

### REQ-105

- **Descripción:** Permitir migrar automáticamente datos de las planillas actuales sin ingreso manual.
- **Tipo:** Funcional
- **Fuente:** F09; F06 §§4.12 y 7.1; F07 Anexo A
- **Fecha:** 22-08; 24-08; contrato fechado 27-08-2026
- **Emisor:** Cliente FIS
- **Contexto original resumido:** La solicitud inicial fue precisada por la propuesta aprobada y finalmente por el contrato firmado.
- **Interpretación funcional:** Incluye carga inicial de ~4.240 registros/39 hojas e importación de nuevos Excel históricos con la misma estructura; excluye activos masivos y asistencia avanzada.
- **Prioridad aparente:** Alta
- **Estado temporal:** Modificado y resuelto por contrato firmado
- **DF relacionado:** DF-046; DF-048
- **Cobertura:** COMPLETO
- **Observación:** El alcance vigente ya no es ambiguo: rige la delimitación del cuerpo contractual y Anexo A.
- **Confianza:** ALTA

## Histórico

### REQ-106

- **Descripción:** Definir en una reimportación qué se incorpora, qué se actualiza y qué queda sin cambios.
- **Tipo:** Regla de negocio
- **Fuente:** F08 §11
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** El DF exige criterio de actualización.
- **Interpretación funcional:** Necesita reconciliación con exclusión contractual.
- **Prioridad aparente:** Alta
- **Estado temporal:** Dudoso
- **DF relacionado:** DF-048
- **Cobertura:** DISTINTO
- **Observación:** El contrato excluye homologación, validación asistida y reversión; solo permite incorporar sobre la misma estructura.
- **Confianza:** ALTA

### REQ-107

- **Descripción:** Detectar duplicados en importaciones recurrentes.
- **Tipo:** Validación
- **Fuente:** F08 §11
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** El DF extiende advertencia de duplicados al histórico.
- **Interpretación funcional:** Debe separarse carga inicial de nuevas importaciones.
- **Prioridad aparente:** Alta
- **Estado temporal:** Dudoso
- **DF relacionado:** DF-048
- **Cobertura:** DISTINTO
- **Observación:** El contrato excluye expresamente detección de duplicados en la importación de nuevos Excel.
- **Confianza:** ALTA

### REQ-108

- **Descripción:** Excluir la importación masiva de casos activos adicionales de la Fase 1.
- **Tipo:** Excepción
- **Fuente:** F07 §3.1
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** No confundirla con el histórico.
- **Interpretación funcional:** Requiere cambio de alcance.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-017; DF-048
- **Cobertura:** PARCIAL
- **Observación:** El DF menciona integración/exclusiones, pero no destaca con suficiente precisión esta diferencia.
- **Confianza:** ALTA

### REQ-109

- **Descripción:** Conservar campos históricos prioritarios cuando existan.
- **Tipo:** Datos
- **Fuente:** F08 §11.1
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** Referencia, contenedor, faltantes, pérdida, fechas, viaje, surveyor, oponente, nave, asegurado y claim number.
- **Interpretación funcional:** Mapear solo campos presentes y documentar nulos.
- **Prioridad aparente:** Media
- **Estado temporal:** Requiere validación
- **DF relacionado:** DF-047
- **Cobertura:** PARCIAL
- **Observación:** Lista útil, pero no fue confirmada como obligatoria por FIS.
- **Confianza:** MEDIA

## Exportación

### REQ-110

- **Descripción:** Definir si se exportará el histórico o sus resúmenes y en qué formato.
- **Tipo:** Reporte
- **Fuente:** F06 §8.4; F07 §3.1; F08 §11
- **Fecha:** 24-08; 27-08; 16-09-2026
- **Emisor:** Propuesta / contrato / DF
- **Contexto original resumido:** Exportaciones están fuera de Fase 1, aunque el DF las deja condicionadas.
- **Interpretación funcional:** No implementar como obligación sin Change Request.
- **Prioridad aparente:** Media
- **Estado temporal:** Evolución
- **DF relacionado:** DF-018; DF-048
- **Cobertura:** PARCIAL
- **Observación:** El DF puede inducir a pensar que la exportación estará incluida.
- **Confianza:** ALTA

## Roles

### REQ-111

- **Descripción:** El Handler puede crear y gestionar casos, revisar extracción, calcular, generar cartas y derivar.
- **Tipo:** Permiso
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Rol operativo.
- **Interpretación funcional:** Permisos de Fase 1.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-004; DF-034
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-112

- **Descripción:** El Gerente supervisa cartera/benchmark y revierte estados con motivo obligatorio.
- **Tipo:** Permiso
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Rol supervisor.
- **Interpretación funcional:** No debe borrar evidencia.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-004; DF-034; DF-053
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-113

- **Descripción:** CEO o Dirección accede a indicadores, reportes y expedientes en solo lectura.
- **Tipo:** Permiso
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Rol ejecutivo.
- **Interpretación funcional:** Sin edición operativa.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-004; DF-034
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-114

- **Descripción:** Mantener el perfil Inspector restringido fuera de Fase 1 salvo cambio de alcance.
- **Tipo:** Excepción
- **Fuente:** F07 §3.1; F08 §13
- **Fecha:** 27-08; 16-09-2026
- **Emisor:** Contrato / DF
- **Contexto original resumido:** Perfil y carta JSI aparecen como evolución.
- **Interpretación funcional:** No incluir en baseline sin aprobación.
- **Prioridad aparente:** Media
- **Estado temporal:** Evolución
- **DF relacionado:** DF-019; DF-052
- **Cobertura:** COMPLETO
- **Observación:** La frontera está bien declarada; el detalle del JSI carece de fuente identificada.
- **Confianza:** ALTA

## Seguridad

### REQ-115

- **Descripción:** Autenticar usuarios mediante inicio de sesión real en producción.
- **Tipo:** No funcional
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** El selector de rol del demo no basta.
- **Interpretación funcional:** Login productivo.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-034; DF-054
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-116

- **Descripción:** Aplicar control de acceso básico por rol.
- **Tipo:** Permiso
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Acciones según perfil.
- **Interpretación funcional:** Autorización de servidor, no solo visual.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-034; DF-054
- **Cobertura:** COMPLETO
- **Observación:** Cubierto funcionalmente; falta diseño técnico verificable.
- **Confianza:** ALTA

### REQ-117

- **Descripción:** Excluir permisos granulares avanzados sobre todo el histórico.
- **Tipo:** Excepción
- **Fuente:** F07 §3.1
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Autenticación básica sí; granularidad avanzada no.
- **Interpretación funcional:** Requiere nueva evaluación.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente
- **DF relacionado:** DF-017; DF-054
- **Cobertura:** PARCIAL
- **Observación:** El DF habla de expedientes autorizados, lo que podría superar la exclusión si no se acota.
- **Confianza:** ALTA

### REQ-118

- **Descripción:** Mantener respaldos periódicos y estrategia de recuperación.
- **Tipo:** No funcional
- **Fuente:** F07 §10
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Protección de datos operativos.
- **Interpretación funcional:** FIS debe poder revisar la estrategia.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-054
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-119

- **Descripción:** Usar datos solo para el servicio y no entrenar modelos generales.
- **Tipo:** No funcional
- **Fuente:** F07 §10
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Restricción de finalidad.
- **Interpretación funcional:** Prohibición explícita de uso propio o de terceros.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-054
- **Cobertura:** PARCIAL
- **Observación:** DF dice uso para el propósito, pero omite expresamente el no entrenamiento de modelos generales.
- **Confianza:** ALTA

### REQ-120

- **Descripción:** Devolver o eliminar la información al término según instrucción de FIS.
- **Tipo:** No funcional
- **Fuente:** F07 §10
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Cierre de tratamiento de datos.
- **Interpretación funcional:** Definir procedimiento y evidencia.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-054
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

### REQ-121

- **Descripción:** No incluir credenciales ni secretos en demo, repositorio, documentos de prueba o exportaciones.
- **Tipo:** No funcional
- **Fuente:** F08 §15
- **Fecha:** 16-09-2026
- **Emisor:** Documento funcional
- **Contexto original resumido:** Control preventivo.
- **Interpretación funcional:** Gestionar secretos fuera de artefactos.
- **Prioridad aparente:** Alta
- **Estado temporal:** Requiere validación técnica
- **DF relacionado:** DF-054
- **Cobertura:** NO DETERMINABLE
- **Observación:** No consta en el contrato; es control necesario que debe adoptarse.
- **Confianza:** MEDIA

## Manual

### REQ-122

- **Descripción:** Incluir manual de usuario integrado con roles, estados y flujo completo.
- **Tipo:** Funcional
- **Fuente:** F07 Anexo A
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Entregable contractual.
- **Interpretación funcional:** Accesible desde la plataforma.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente
- **DF relacionado:** DF-016; DF-055
- **Cobertura:** COMPLETO
- **Observación:** Cubierto.
- **Confianza:** ALTA

# Gobierno, aceptación y condiciones del proyecto 167

## Incidencias

### REQ-123

- **Descripción:** Incluir un menú para reportar incidencias, bugs y sugerencias con texto, voz o capturas.
- **Tipo:** Funcional
- **Fuente:** F05 1:05-3:00
- **Fecha:** Posterior al 25-08-2026
- **Emisor:** Julio
- **Contexto original resumido:** Compromiso comunicado al cliente para el ciclo de pruebas.
- **Interpretación funcional:** Debe decidirse si es funcionalidad entregable o canal temporal.
- **Prioridad aparente:** Media
- **Estado temporal:** Compromiso de apoyo al ciclo de pruebas; no contractualizado
- **DF relacionado:** —
- **Cobertura:** AUSENTE
- **Observación:** No forma parte del alcance funcional firmado; debe tratarse como canal de pruebas o formalizarse mediante Solicitud de Cambio.
- **Confianza:** ALTA

## Arquitectura

### REQ-124

- **Descripción:** Pasar el demo a desarrollo con backend, base de datos y almacenamiento productivo.
- **Tipo:** No funcional
- **Fuente:** F05 1:05; F07 Anexo A
- **Fecha:** Posterior al 25-08; 27-08-2026
- **Emisor:** Julio / contrato
- **Contexto original resumido:** El demo no era solución productiva.
- **Interpretación funcional:** Arquitectura productiva inicial.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente
- **DF relacionado:** DF-054
- **Cobertura:** PARCIAL
- **Observación:** DF reconoce almacenamiento/autenticación, pero no define criterios técnicos verificables.
- **Confianza:** ALTA

## Gestión

### REQ-125

- **Descripción:** Realizar reuniones semanales de 30 minutos, reporte semanal y demo por hito.
- **Tipo:** Proceso
- **Fuente:** F07 §4.1
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Cadencia contractual.
- **Interpretación funcional:** Gobernanza del proyecto.
- **Prioridad aparente:** Media
- **Estado temporal:** Vigente
- **DF relacionado:** —
- **Cobertura:** AUSENTE
- **Observación:** No corresponde al núcleo funcional, pero debe quedar trazado.
- **Confianza:** ALTA

## Plazo

### REQ-126

- **Descripción:** Entregar una primera versión utilizable en aproximadamente una a dos semanas desde la reunión de coordinación.
- **Tipo:** No funcional
- **Fuente:** F05 1:05-2:21; F11
- **Fecha:** Posterior al 25-08; registro 15-09-2026
- **Emisor:** Julio / contexto del proyecto
- **Contexto original resumido:** No equivale a proyecto terminado.
- **Interpretación funcional:** Hito de prueba temprana.
- **Prioridad aparente:** Alta
- **Estado temporal:** Compromiso comunicado
- **DF relacionado:** —
- **Cobertura:** AUSENTE
- **Observación:** No está en DF ni se identifica fecha de inicio exacta.
- **Confianza:** ALTA

## Aceptación

### REQ-127

- **Descripción:** Aplicar revisión de 15 días hábiles y luego 5 días sobre correcciones materiales.
- **Tipo:** Proceso
- **Fuente:** F07 §5.5
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Procedimiento de aceptación contractual.
- **Interpretación funcional:** No es función de usuario, pero gobierna QA.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente — contrato firmado
- **DF relacionado:** DF-057
- **Cobertura:** PARCIAL
- **Observación:** DF define criterios, no el procedimiento y plazos completos.
- **Confianza:** ALTA

## Soporte

### REQ-128

- **Descripción:** Incluir dos meses de soporte y luego soporte opcional de 3 UF más IVA al mes.
- **Tipo:** No funcional
- **Fuente:** F07 §§5 y 8
- **Fecha:** 27-08-2026
- **Emisor:** Partes contractuales
- **Contexto original resumido:** Condición comercial.
- **Interpretación funcional:** Correcciones y ajustes menores sin cambio de alcance.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente — contrato firmado
- **DF relacionado:** —
- **Cobertura:** AUSENTE
- **Observación:** Fuera del propósito funcional, pero relevante para cierre.
- **Confianza:** ALTA

## Propiedad

### REQ-129

- **Descripción:** Transferir propiedad del desarrollo específico a FIS tras pago total y respetar exclusividad/no replicación por 24 meses posteriores al término.
- **Tipo:** No funcional
- **Fuente:** F02 31:19-36:45; F07 §§11-12
- **Fecha:** 21-07; 27-08-2026
- **Emisor:** Ljubinka / contrato
- **Contexto original resumido:** Protección del diferenciador de negocio.
- **Interpretación funcional:** No afecta comportamiento de usuario, pero sí solución esperada.
- **Prioridad aparente:** Alta
- **Estado temporal:** Vigente — contrato firmado
- **DF relacionado:** —
- **Cobertura:** AUSENTE
- **Observación:** No corresponde al DF funcional; debe controlarse contractualmente.
- **Confianza:** ALTA
