# QA FUNCIONAL FIS — RESUMEN EJECUTIVO

## Conclusión

**La definición funcional cubre la mayor parte del proyecto aprobado 167, pero todavía no está lista para aprobación final.** El contrato v6.0 firmado acredita el baseline y resuelve la duda jurídica de la auditoría anterior. El documento representa correctamente la carga de carpetas, expediente, clasificación documental, extracción asistida, revisión humana, cuatro cartas, tres métodos de pérdida, roles, histórico y traspaso local.

Las brechas vigentes son: fórmula bruta versus neta; funciones de actualización y duplicados que el DF agrega a la importación histórica pese a estar excluidas; convención de referencia; reglas exactas de prescripción; plantillas oficiales de cartas; umbral de inactividad; y checklist de traspaso.

**Respuesta ejecutiva:** cobertura funcional alta, contrato y propuesta correctamente acreditados, pero **aprobación funcional no recomendada aún** hasta resolver los hallazgos P0/P1 y emitir una versión corregida del DF.

## Cifras de la auditoría

| Indicador | Resultado |
|---|---:|
| Fuentes inventariadas y revisadas | 11 |
| Requerimientos núcleo Preclaim | 122 |
| Requerimientos de gobierno/comerciales trazados | 7 |
| Total de requerimientos inventariados | 129 |
| DF descompuestos | 57 |
| Reglas de negocio | 29 |
| Flujos reconstruidos | 6 |
| Contradicciones registradas | 9 |
| Cambios de alcance | 7 |
| Preguntas abiertas | 11 |
| Casos de aceptación | 64 |

## Cobertura del núcleo Preclaim

| Cobertura | Cantidad |
|---|---:|
| ✅ COMPLETO | 80 |
| 🟡 PARCIAL | 30 |
| 🔴 AUSENTE | 2 |
| 🔵 DISTINTO | 4 |
| ⚪ NO DETERMINABLE | 6 |
| **Total** | **122** |

Esta métrica evalúa exclusivamente Intervent Preclaim y su gobierno contractual. Todas las solicitudes y fuentes ajenas al primer proyecto aprobado fueron excluidas.

## Hallazgos críticos

| ID | Severidad | Tema | Diferencia | Impacto | Recomendación |
|---|---|---|---|---|---|
| QA-FUNC-001 | P0 — BLOQUEANTE | Fórmula de pérdida | Cambio material de fórmula. | Resultados monetarios incorrectos y aceptación imposible. | Cerrar fichas matemáticas y ejemplos firmados antes del UAT. |
| QA-FUNC-002 | P1 — CRÍTICO | Importación recurrente | El DF promete más que el alcance contratado. | Controversia de aceptación y comportamiento de datos incorrecto. | Eliminar esas promesas del DF o formalizar una Solicitud de Cambio. |
| QA-FUNC-003 | P1 — CRÍTICO | Referencia interna | No existe fórmula canónica cerrada. | Duplicados, búsquedas y prescripción pueden fallar. | Documentar tokens, separadores, fuente del correlativo y reglas de corrección. |
| QA-FUNC-004 | P1 — CRÍTICO | Prescripción | Dependencia crítica todavía abierta. | Riesgo de pérdida del derecho a recupero. | FIS debe aprobar una matriz jurisdicción-modo-fecha base-plazo-excepciones. |
| QA-FUNC-005 | P1 — CRÍTICO | Cartas oficiales | Contenido de aceptación no cerrado. | Documentos incorrectos o duplicación de entregables. | Recibir/versionar plantillas y resolver claim notice versus notificación a naviera. |

## Lectura inversa del documento funcional

| Estado DF → cliente/contrato | Cantidad |
|---|---:|
| RESPALDADO | 35 |
| PARCIALMENTE RESPALDADO | 19 |
| SIN EVIDENCIA | 1 |
| CONTRADICTORIO | 2 |

## Riesgos o alertas

1. **P0 — riesgo monetario.** El DF usa valores netos en métodos 1/2, mientras FIS explicó una base bruta.
2. **P1 — riesgo de alcance/datos.** El DF promete actualización y detección de duplicados que el contrato firmado excluye para nuevos Excel históricos.
3. **P1 — referencia.** Falta la fórmula canónica y la fuente del correlativo.
4. **P1 — prescripción.** No existe matriz aprobada de jurisdicción, fecha base, plazo y excepciones.
5. **P1 — cartas.** Las cuatro cartas están contratadas, pero faltan plantillas, campos, formato y firma aprobados.

## Oportunidades detectadas

- Alinear el DF con la prelación contractual: cuerpo del contrato, Anexo A y luego propuesta 167.
- Tratar la asignación automática cliente-handler y cualquier otra solicitud no incorporada al Anexo A como Solicitud de Cambio, no como defecto del proyecto 167.
- Usar los casos de aceptación de esta carpeta como base del UAT y del procedimiento de aceptación contractual.

## Recomendación concreta

1. Corregir de inmediato el DF en cálculo e importación histórica para que no contradiga el contrato firmado.
2. Realizar una sesión de cierre enfocada en OPEN-001 a OPEN-008.
3. Obtener de FIS plantillas, reglas de prescripción, checklist y archivo histórico definitivo, conforme a sus obligaciones contractuales.
4. Congelar una versión aprobada y vincular cada prueba UAT a los AC de este análisis.

## Inventario de fuentes

| ID fuente | Tipo | Fecha | Participantes/Emisor | Asunto | Relevancia |
|---|---|---|---|---|---|
| F01 | TRANSCRIPCIÓN | 10-07-2026 | Ljubinka Basic, Julio, Rodrigo Sauvalle | Levantamiento inicial FIS/Intervent | Se utilizan únicamente los pasajes de Preclaim: proceso, cálculo, documentos, cartas, prescripción y alertas. |
| F02 | TRANSCRIPCIÓN | 21-07-2026 | Ljubinka Basic, Julio Espinoza, Rodrigo Sauvalle | Demostración de plataforma y Excel Preclaim | Referencia, datos, expediente, acceso a plataforma, asignación de handler y exclusividad del proyecto 167. |
| F03 | MENSAJE DEL CLIENTE | Fecha no consignada; posterior al 21-07 y anterior al 25-08-2026 | Ljubinka Basic | Contexto para seguir avanzando | Decisión vigente de comenzar desde una carpeta ya descargada y no depender de API/credenciales. |
| F04 | CORREO | 25-08-2026 | Ljubinka Basic | Aprobación del proyecto y nuevas necesidades | Aprobación expresa de la propuesta 167. Las necesidades adicionales se excluyen de esta auditoría por corresponder a otros proyectos. |
| F05 | TRANSCRIPCIÓN | Posterior al 25-08-2026; la transcripción no consigna fecha | Ljubinka Basic, Julio, Rodrigo Sauvalle | Coordinación de desarrollo | Se usan solo los pasajes relativos a Intervent Preclaim: paso de demo a desarrollo, histórico cargado y plazo de primera versión. |
| F06 | PROPUESTA COMERCIAL APROBADA | 24-08-2026; aprobada por F04 el 25-08-2026 | NPR & Humadis para FIS Chile | 167. PPTO FIS_AGOSTO2026(1).pdf | Base comercial aprobada: Fase 1, MVP demostrado, inversión, soporte, roadmap y dependencias. Queda subordinada al contrato firmado. |
| F07 | CONTRATO FIRMADO | Fechado 27-08-2026; firmas visibles fechadas 07-09 y 10-09-2026 | NPR SpA y Fruit Insurance Services Chile SpA | Contrato_NPR_FISChile_v6.0 Firmado.pdf | Baseline contractual vigente. El cuerpo y Anexo A prevalecen sobre la propuesta 167 conforme a la cláusula 1.4. |
| F08 | DEFINICIÓN FUNCIONAL | 16-09-2026, según disponibilidad del archivo | Equipo de desarrollo / revisión para Sauvalle | 223085d7-0955-4ad3-aa07-b6fc9c253577.docx | Documento objetivo auditado: Intervent Preclaim — Documento Funcional de Revisión. |
| F09 | CONTEXTO DEL PROYECTO | 22-08-2026 | Cliente FIS, cita registrada por Rodrigo | Migración desde planillas | Solicitud de migrar automáticamente los datos de las planillas actuales a la plataforma, sin ingreso manual. |
| F10 | CONFIRMACIÓN DEL CLIENTE REGISTRADA EN EL PROYECTO | 09–10 de septiembre de 2026 | Ljubinka Basic | Cartas automáticas | Definición final registrada: AoR, Harvest, LoA y claim notice incluidas; SUBRO excluida. |
| F11 | CONTEXTO DEL PROYECTO | 15-09-2026 | Registro de conversación con Rodrigo | Plazo comunicado | Primera versión utilizable aproximadamente la semana siguiente, con margen entendido de hasta dos semanas; no era el proyecto terminado. |

## Limitaciones de evidencia

- No se encontraron correos de Gmail adicionales en la búsqueda contextual.
- Se revisó la copia firmada del contrato v6.0 y la propuesta 167 aprobada; no se recibieron templates oficiales de cartas.
- Las fechas de F03 y F05 no están impresas en los archivos; se conservaron como rangos/secuencia y no se inventó una fecha exacta.
- El detalle Inspector/JSI aparece en F08, pero no se recuperó su fuente primaria.
- Las fuentes relativas a otros proyectos fueron excluidas íntegramente del análisis funcional.
