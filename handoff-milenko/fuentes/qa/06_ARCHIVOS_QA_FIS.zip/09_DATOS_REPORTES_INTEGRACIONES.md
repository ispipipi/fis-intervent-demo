# DATOS, REPORTES E INTEGRACIONES FIS

## Catálogo de datos

| ID | Nombre | Origen | Dónde se utiliza | Quién completa | Quién modifica | Obligatorio | Reglas | Fuente |
|---|---|---|---|---|---|---|---|---|
| DATO-001 | Referencia interna | Convención FIS / datos del caso | Identificación, búsqueda, prescripción | Sistema + Handler | Handler con auditoría | Sí | Fórmula exacta pendiente | F01; F02 |
| DATO-002 | Asegurado/cliente | BL, aviso, factura, correo | Ficha y cartas | Sistema | Handler | Sí cuando exista | Distinguir roles | F01; F08 |
| DATO-003 | Oponente/transportista | BL/booking/notificación | Referencia y recupero | Sistema | Handler | Sí | Confirmar contraparte | F01; F08 |
| DATO-004 | Nave/viaje/contenedor | BL, booking, tracking | Ficha, búsqueda, agrupación futura | Sistema | Handler | Sí cuando aplique | Mismo embarque | F02; F08 |
| DATO-005 | Producto/variedad/calibre | BL, packing, factura, certificados | Comparabilidad | Sistema | Handler | Según método | Criterios embarque gemelo | F01 |
| DATO-006 | Cantidad/unidad | Packing, factura, liquidación | Cálculo | Sistema | Handler | Sí para cálculo | Conversiones pendientes | F08 |
| DATO-007 | Puerto/fecha de embarque | BL/booking | Ficha | Sistema | Handler | Según caso | Fuente visible | F02 |
| DATO-008 | ETA/fecha real descarga | Plataforma/documentos/tracking | Prescripción | Sistema | Handler | Sí para plazo | No confundir ETA con real | F02 |
| DATO-009 | Jurisdicción/convenio | Regla operativa | Prescripción | Usuario autorizado | Usuario autorizado | Sí | Matriz pendiente | F01; F02 |
| DATO-010 | Fecha de prescripción | Fecha base + regla | Alertas/referencia | Sistema | Handler autorizado | Sí | Plazos exactos | F01; F02; F07 |
| DATO-011 | CS Claim Number | Aviso/plataforma | Ficha/búsqueda | Sistema | Handler | No al inicio | Opcional pendiente de validación | F08 |
| DATO-012 | Inspector/surveyor | Reporte/QC/comunicación | Ficha | Sistema | Handler | No siempre | Asociación correcta | F02 |
| DATO-013 | Documentos y estado | Carpeta | Inventario | Sistema | Handler | Sí | Checklist por caso | F03; F07 |
| DATO-014 | Causa y mérito | Documentos + análisis | Decisión Preclaim | Sistema propone | Handler decide | Sí para cierre | No automático definitivo | F01; F07 |
| DATO-015 | Liquidación afectada/comparable | Liquidaciones | Métodos 1/2 | Sistema | Handler | Según método | Bruto/neto pendiente | F01 |
| DATO-016 | Reporte de mercado | USDA/otras fuentes | Método 2 | Usuario/sistema futuro | Handler | Según método | Fecha/plaza/unidad | F01 |
| DATO-017 | Factura/venta/nota crédito | Documentos comerciales | Método 3/venta firme | Sistema | Handler | Según caso | Signo y límites pendientes | F01; F07 |
| DATO-018 | Moneda y FX | Documento / ingreso manual | Cálculo | Sistema/usuario | Usuario autorizado | Sí si monedas difieren | Fuente/fecha/redondeo pendiente | F07; F08 |
| DATO-019 | Handler | Cartera/mantenedor | Asignación y reportes | Sistema/gerencia | Gerencia | Sí | Automatización ausente | F02 |
| DATO-020 | Origen histórico | Archivo/hoja/fila | Trazabilidad | Importador | No debería alterarse | Sí si disponible | Contrato no detalla hoja/fila | F06; F08 |

## Reportes

| ID | Nombre | Objetivo | Usuarios | Datos | Filtros | Exportación | Periodicidad | Fuente | Cobertura |
|---|---|---|---|---|---|---|---|---|---|
| REP-001 | Dashboard operativo | Control de cartera | Handler/Gerente/CEO según rol | Estados, pendientes, pérdida, prescripción, handler | Por responsable/estado | No en Fase 1 | En línea | F07 | COMPLETO |
| REP-002 | Benchmark por handler | Comparar carga y cuellos de botella | Gerente/CEO | Casos, pendientes, alertas, cobertura, cálculo, tiempos | Periodo y responsable | No definido | En línea | F07; F08 | PARCIAL |
| REP-003 | Informe de revisión | Cerrar Preclaim con evidencia | Handler/Gerente | Documentos, causa, mérito, cálculo | Caso | Texto descargable | Por cierre | F07 | COMPLETO |
| REP-004 | Carta de notificación | Formalizar aviso | Handler | Datos del caso | Caso | Texto descargable | Cuando corresponda | F07 | PARCIAL: relación con claim notice abierta |
| REP-005 | Listado/texto de faltantes | Solicitar documentación | Handler | Checklist y faltantes | Caso/tipo | Copiar/descargar; sin email | Según revisión | F07 | COMPLETO |
| REP-006 | Consulta histórica | Memoria y búsqueda | Usuarios autorizados | Campos importados | Referencia/cliente/nave/etc. | Exportación fuera/por validar | En línea | F07; F08 | COMPLETO/PARCIAL |

## Integraciones

| ID | Sistema | Objetivo | Información recibida | Información enviada | Frecuencia | Dependencias | Fuente | Cobertura |
|---|---|---|---|---|---|---|---|---|
| INT-001 | Plataforma aseguradora | Obtener casos/documentos | Ninguna en Fase 1 | Ninguna | No aplica | Acceso/API no disponibles | F02; F03; F07 | EXCLUIDA |
| INT-002 | Correo | Recibir notificaciones/enviar solicitudes | No integrado | No integrado | No aplica | Envío automático fuera | F01; F07 | EXCLUIDA |
| INT-003 | FIS/Lawgistic | Traspasar expediente | Cambio de estado local | Ninguna transmisión | Al cierre | Gestión posterior fuera | F07 | EXCLUIDA COMO INTEGRACIÓN |
| INT-004 | Fuente de tipo de cambio | Conversión automática | No definida | No definida | No aplica | Monedas externas fuera | F07; F08 | PENDIENTE/EVOLUCIÓN |

## Excepciones relevantes

| ID | Regla general | Excepción | Fuente | Impacto | ¿Documentada? |
|---|---|---|---|---|---|
| EXC-001 | La plataforma propone mérito | Handler puede continuar por razones comerciales | F01 | Evita bloqueo automático | Parcial |
| EXC-002 | Se requieren documentos según checklist | Un documento puede no aplicar | F08 | Evita solicitudes innecesarias | Pendiente de validación |
| EXC-003 | La prescripción general marítima es un año | Chile/Perú se explicaron con dos años | F01/F02 | Fecha límite | Parcial |
| EXC-004 | Cálculo con tres métodos | Venta a firme/nota de crédito usa tratamiento especial | F01/F07 | Monto reclamable | Parcial |
| EXC-005 | Cálculo bloqueado tras traspaso | Gerente puede revertir con motivo | F07 | Control de cambios | Sí |
| EXC-006 | Importación histórica disponible | Solo misma estructura; sin activos/duplicados/rollback | F07 | Límite de migración | Sí |
