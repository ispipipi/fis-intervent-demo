# PREGUNTAS ABIERTAS FIS

Solo se incluyen dudas que no pudieron resolverse revisando todas las fuentes disponibles.

| ID | Tema | Pregunta | Por qué existe | Fuentes relacionadas | Impacto |
|---|---|---|---|---|---|
| OPEN-001 | Cálculo | ¿Cuáles son las fórmulas exactas de los tres métodos, incluyendo base bruta/neta, costos, unidades, límites, redondeos y ejemplos aprobados? | El DF contradice la base bruta explicada para métodos 1/2. | F01; F07; F08 §9 | ALTO |
| OPEN-002 | Referencia | ¿Cuál es la fórmula oficial completa de la referencia, incluidos tokens, separadores, prescripción, correlativo y fuente del correlativo? | La regla fue explicada verbalmente, pero no consolidada. | F01; F02; F06 | ALTO |
| OPEN-003 | Prescripción | ¿Cuál es la matriz oficial de jurisdicción, modo de transporte, fecha base, plazo, extensiones y excepciones? | El contrato obliga a FIS a entregar las reglas vigentes y aún no están cerradas en el DF. | F01; F02; F07 | ALTO |
| OPEN-004 | Cartas | ¿Claim notice y carta de notificación a la naviera son el mismo documento? | Ambos nombres aparecen como salidas contractuales/funcionales. | F07; F08; F10 | ALTO |
| OPEN-005 | Cartas | ¿Cuáles son las plantillas oficiales, textos legales, campos obligatorios, formato y reglas de firma de AoR, Harvest, LoA y claim notice? | El contrato exige plantillas entregadas o validadas por FIS. | F07 §7 y Anexo A; F08 §10 | ALTO |
| OPEN-006 | Checklist documental | ¿Cuál es el checklist por tipo de caso y qué documentos pueden marcarse como no aplicables? | La función está contratada, pero su contenido no fue entregado. | F01; F07; F08 §8.5 | ALTO |
| OPEN-007 | Traspaso | ¿Qué condiciones exactas habilitan el cierre hacia FIS y cuáles hacia Lawgistic? | El DF propone condiciones, pero no consta aprobación de FIS. | F07; F08 §14 | ALTO |
| OPEN-008 | Inactividad | ¿Qué evento reinicia el contador, se usan días hábiles o corridos, cuál es el umbral y qué estados quedan excluidos? | El contrato deja el período a definición de FIS; 15 días no está confirmado. | F01; F07; F08 §12 | ALTO |
| OPEN-009 | Alertas | ¿Qué rol recibe cada alerta y por qué canal? | La discriminación por perfil y canal no está cerrada. | F01; F07; F08 §12 | MEDIO |
| OPEN-010 | Histórico | ¿Cuál es el archivo definitivo de las 39 hojas, su versión y los campos obligatorios? | El contrato fija volumen aproximado, pero FIS debe entregar la estructura real. | F07 §7; F08 §11 | MEDIO |
| OPEN-011 | Documentos | ¿Cuál es el corpus productivo cerrado y qué precisión mínima se aceptará para clasificación, OCR y extracción? | Los ejemplos no equivalen a lista ni umbral de aceptación aprobados. | F06; F07; F08 §§8.3-8.6 | MEDIO |

## Orden recomendado para resolver

1. OPEN-001 a OPEN-005: cerrar cálculo, referencia, prescripción y cartas.
2. OPEN-006 a OPEN-008: cerrar checklist, traspaso e inactividad.
3. OPEN-009 a OPEN-011: cerrar alertas, histórico y corpus documental para UAT.
