# DIFERENCIAS CLIENTE VS DOCUMENTO FUNCIONAL

## 1. Requerimientos ausentes

| REQ | Ámbito | Requerimiento | Fuente | Impacto/observación |
|---|---|---|---|---|
| REQ-016 | CORE | Gestionar el correlativo interno sin depender del número publicado manualmente en Teams. | F02 8:54-11:14 | No aparece en el DF ni en el contrato. |
| REQ-017 | CORE | Asignar automáticamente el handler según la cartera de clientes mantenida por FIS. | F02 14:22-15:35 | No aparece en la propuesta aprobada ni en el Anexo A firmado; no es incumplimiento del proyecto 167 y requiere Solicitud de Cambio. |
| REQ-123 | GOV | Incluir un menú para reportar incidencias, bugs y sugerencias con texto, voz o capturas. | F05 1:05-3:00 | No forma parte del alcance funcional firmado; debe tratarse como canal de pruebas o formalizarse mediante Solicitud de Cambio. |
| REQ-125 | GOV | Realizar reuniones semanales de 30 minutos, reporte semanal y demo por hito. | F07 §4.1 | No corresponde al núcleo funcional, pero debe quedar trazado. |
| REQ-126 | GOV | Entregar una primera versión utilizable en aproximadamente una a dos semanas desde la reunión de coordinación. | F05 1:05-2:21; F11 | No está en DF ni se identifica fecha de inicio exacta. |
| REQ-128 | GOV | Incluir dos meses de soporte y luego soporte opcional de 3 UF más IVA al mes. | F07 §§5 y 8 | Fuera del propósito funcional, pero relevante para cierre. |
| REQ-129 | GOV | Transferir propiedad del desarrollo específico a FIS tras pago total y respetar exclusividad/no replicación por 24 meses posteriores al término. | F02 31:19-36:45; F07 §§11-12 | No corresponde al DF funcional; debe controlarse contractualmente. |

## 2. Requerimientos parciales

| REQ | Requerimiento | DF | Diferencia |
|---|---|---|---|
| REQ-011 | Mostrar nivel de confianza de la clasificación automática. | DF-026; DF-037 | La propuesta y DF lo describen, pero el contrato no fija escala ni umbral. |
| REQ-013 | Generar o sugerir la referencia interna conforme a la convención de FIS. | DF-024; DF-035 | El DF dice que debe respetar la convención, pero no la especifica. |
| REQ-021 | Distinguir documentos solicitados, observados o reemplazados. | DF-038 | Contrato confirma disponibles/faltantes y solicitud; no define observado/reemplazado. |
| REQ-022 | Usar un checklist configurable por tipo de caso. | DF-028; DF-038; DF-056 | Existe función, pero el checklist oficial no está definido. |
| REQ-023 | Permitir marcar un documento como no aplicable o desmarcar un faltante. | DF-038 | La necesidad es coherente, pero no consta como regla acordada en contrato o reuniones. |
| REQ-030 | Extraer información de los demás tipos documentales previamente definidos y validados. | DF-008; DF-027; DF-039 | El DF enumera ejemplos, pero no cierra el corpus productivo ni prioridades. |
| REQ-041 | Buscar casos por referencia y datos operativos relevantes. | DF-047 | DF lo define claramente para histórico; falta explicitar mismo alcance en casos activos. |
| REQ-048 | Permitir continuar casos con mérito jurídico débil por razones comerciales justificadas. | DF-040 | La revisión humana evita el bloqueo, pero la excepción comercial no está documentada expresamente. |
| REQ-050 | Método 1: comparar con un embarque gemelo de misma variedad, calibre, destino y fecha similar. | DF-041; DF-042 | El DF menciona producto, unidades y ajustes, pero omite los cuatro criterios completos. |
| REQ-054 | Método 3: comparar valor de factura de exportación con venta bruta en destino. | DF-041 | El DF admite venta o liquidación y costos aplicables, sin fijar claramente venta bruta. |
| REQ-056 | Contemplar notas de crédito en el cálculo cuando corresponda. | DF-041; DF-042 | Función cubierta, pero signo y límite siguen abiertos. |
| REQ-059 | Permitir seleccionar el cálculo más favorable para el recupero, sujeto a criterio del handler. | DF-041; DF-042 | DF exige selección/justificación, pero no refleja el criterio comercial de mayor beneficio. |
| REQ-063 | Cuando se comparen monedas distintas, exigir fecha y tipo de cambio o impedir el cálculo. | DF-043 | El comportamiento está bien formulado, pero fuente y regla no están acordadas. |
| REQ-064 | Definir fórmulas, costos, ajustes, unidades, tolerancias, límites y redondeos exactos. | DF-042; DF-056 | El DF identifica el vacío, pero no lo resuelve. |
| REQ-074 | Mantener versión, vigencia y estado activo de templates base. | DF-045 | Es diseño útil, pero contrato no define todas estas operaciones. |
| REQ-078 | Validar formatos oficiales, texto legal, campos obligatorios y reglas de firma de cada carta. | DF-044; DF-056 | El DF declara el pendiente, pero aún no hay definición. |
| REQ-081 | Definir guardas y transiciones permitidas entre los estados. | DF-033; DF-053 | DF describe condiciones generales, pero no una máquina de estados cerrada. |
| REQ-085 | Definir el checklist mínimo que habilita el traspaso. | DF-053; DF-056 | La propuesta del DF no está confirmada por el cliente. |
| REQ-087 | No borrar documentos, observaciones ni versiones al traspasar o revertir. | DF-053; DF-054 | Consistente con auditoría, pero no se explicita en contrato. |
| REQ-089 | Definir qué cuenta como movimiento real y evitar que un usuario antedate una gestión. | DF-049; DF-054 | Hay auditoría general, pero no regla anti-backdating ni definición de movimiento. |
| REQ-090 | Aplicar reglas de La Haya y Hamburgo, incluyendo un año para la mayoría y dos años para Chile/Perú marítimo según lo explicado. | DF-012; DF-039 | DF menciona jurisdicción y regla, pero no fija los plazos explicados. |
| REQ-091 | Usar la fecha real de descarga como fecha base cuando corresponda. | DF-039; DF-056 | DF distingue ETA/real, pero todavía pregunta qué fecha activa la regla en cada escenario. |
| REQ-097 | Comparar handlers por carga, pendientes, alertas, cobertura, cálculo y tiempos. | DF-013; DF-051 | Función cubierta; periodo y uso no definidos. |
| REQ-099 | Generar una carta de notificación a la naviera descargable en formato texto. | DF-031; DF-044; DF-057 | Función aparece, pero existe ambigüedad de duplicación con claim notice. |
| REQ-103 | Conservar archivo, hoja, fila y origen de los registros importados cuando estén disponibles. | DF-046; DF-047 | DF menciona archivo/origen, pero no asegura hoja/fila como la propuesta. |
| REQ-108 | Excluir la importación masiva de casos activos adicionales de la Fase 1. | DF-017; DF-048 | El DF menciona integración/exclusiones, pero no destaca con suficiente precisión esta diferencia. |
| REQ-109 | Conservar campos históricos prioritarios cuando existan. | DF-047 | Lista útil, pero no fue confirmada como obligatoria por FIS. |
| REQ-110 | Definir si se exportará el histórico o sus resúmenes y en qué formato. | DF-018; DF-048 | El DF puede inducir a pensar que la exportación estará incluida. |
| REQ-117 | Excluir permisos granulares avanzados sobre todo el histórico. | DF-017; DF-054 | El DF habla de expedientes autorizados, lo que podría superar la exclusión si no se acota. |
| REQ-119 | Usar datos solo para el servicio y no entrenar modelos generales. | DF-054 | DF dice uso para el propósito, pero omite expresamente el no entrenamiento de modelos generales. |
| REQ-124 | Pasar el demo a desarrollo con backend, base de datos y almacenamiento productivo. | DF-054 | DF reconoce almacenamiento/autenticación, pero no define criterios técnicos verificables. |
| REQ-127 | Aplicar revisión de 15 días hábiles y luego 5 días sobre correcciones materiales. | DF-057 | DF define criterios, no el procedimiento y plazos completos. |

## 3. Definiciones distintas

| REQ | Requerimiento vigente | DF | Diferencia |
|---|---|---|---|
| REQ-051 | En métodos de comparable/SMV, usar la base bruta acordada y no cambiarla a neta sin validación. | DF-041 | El DF define valor neto esperado versus neto obtenido, lo que contradice la explicación de la reunión. |
| REQ-053 | En método de reporte de mercado, mantener la base bruta explicada por FIS. | DF-041 | El DF usa resultado neto de la liquidación afectada. |
| REQ-106 | Definir en una reimportación qué se incorpora, qué se actualiza y qué queda sin cambios. | DF-048 | El contrato excluye homologación, validación asistida y reversión; solo permite incorporar sobre la misma estructura. |
| REQ-107 | Detectar duplicados en importaciones recurrentes. | DF-048 | El contrato excluye expresamente detección de duplicados en la importación de nuevos Excel. |

## 4. Funcionalidades del DF sin respaldo suficiente

| DF | Funcionalidad | Evidencia | Estado | Observación |
|---|---|---|---|---|
| DF-011 | Tres métodos, USD/CLP, venta firme, nota de crédito e ítems adicionales. | F01; F07 Anexo A | PARCIALMENTE RESPALDADO | Alcance general correcto; fórmulas aún no. |
| DF-012 | Cálculo y alertas conforme a jurisdicciones y reglas aprobadas. | F01-F02; F07 Anexo A | PARCIALMENTE RESPALDADO | Faltan plazos y fecha base exacta. |
| DF-024 | Referencia, duplicidad y corrección. | F01-F02; F07 Anexo A | PARCIALMENTE RESPALDADO | No codifica convención exacta ni correlativo. |
| DF-025 | Progreso, originales y errores. | F07 Anexo A | PARCIALMENTE RESPALDADO | Aislamiento de errores no tiene fuente acordada. |
| DF-026 | Tipo, nombre, confianza y corrección. | F07 Anexo A | PARCIALMENTE RESPALDADO | Confianza no tiene umbral acordado. |
| DF-028 | Checklist, faltantes y solicitudes sugeridas. | F01; F07 Anexo A | PARCIALMENTE RESPALDADO | Checklist oficial y N/A pendientes. |
| DF-033 | Catálogo de seis estados y acciones generales. | F07 Anexo A | PARCIALMENTE RESPALDADO | Estados sí; transiciones completas no. |
| DF-035 | Corrección, duplicidad, ETA/real y trazabilidad. | F02; F07 Anexo A | PARCIALMENTE RESPALDADO | Referencia exacta pendiente. |
| DF-036 | Carpeta, formatos, OCR, trazabilidad y errores. | F07 Anexo A | PARCIALMENTE RESPALDADO | TXT/JSON/XML/MD y manejo de errores son demo/no validados. |
| DF-038 | Estados documentales, cobertura, checklist y solicitud. | F07 Anexo A | PARCIALMENTE RESPALDADO | Estados observado/reemplazado y N/A no contractuales. |
| DF-039 | Diccionario de campos y reglas de revisión. | F01-F02; F06 | PARCIALMENTE RESPALDADO | Prioridades y algunos campos opcionales no validados. |
| DF-041 | Cinco filas de cálculo y datos requeridos. | F01; F07 Anexo A | CONTRADICTORIO | El DF usa neto en métodos 1/2; FIS explicó base bruta. |
| DF-042 | Bases, costos, límites, unidades, nota de crédito, método y redondeo. | F08 | SIN EVIDENCIA | Es inventario de decisiones pendientes, no una regla ya acordada. |
| DF-043 | USD/CLP, monedas distintas y tipo de cambio. | F07 Anexo A | PARCIALMENTE RESPALDADO | USD/CLP sí; reglas FX no. |
| DF-045 | Versiones, vigencia, tokens, vista previa y auditoría. | F08 | PARCIALMENTE RESPALDADO | Detalle de mantenedor no está en contrato. |
| DF-048 | Reimportación, duplicados y exportación condicionada. | F07 Anexo A y §3.1 | CONTRADICTORIO | Reimportación con actualización/duplicados excede el contrato. |
| DF-049 | Alerta mayor a 15 días y validaciones pendientes. | F01; F06; F07 Anexo A | PARCIALMENTE RESPALDADO | La función sí; 15 días no confirmado. |
| DF-051 | Indicadores y comparaciones por handler. | F07 Anexo A | PARCIALMENTE RESPALDADO | Métricas, periodos y audiencia requieren confirmación. |
| DF-052 | Acceso acotado y carta de inspección conjunta. | F06 §5; F07 §3.1; F08 §13 | PARCIALMENTE RESPALDADO | Inspector está respaldado solo como evolución excluida; la carta JSI y sus campos no tienen fuente aprobada. |
| DF-053 | Requisitos, bloqueo, motivo y preservación. | F07 Anexo A | PARCIALMENTE RESPALDADO | Checklist previo y preservación detallada no aprobados. |
| DF-054 | Auditoría, accesos, respaldos, eliminación y secretos. | F07 §§9-10 y Anexo A | PARCIALMENTE RESPALDADO | Falta explicitar no entrenamiento y criterios técnicos. |
| DF-057 | Pruebas mínimas por flujo, documentos, datos, cálculo, cartas, memoria y traspaso. | F07 §5.5 y Anexo A | PARCIALMENTE RESPALDADO | Faltan procedimiento contractual y fórmulas cerradas. |

## 5. Contradicciones

| ID | Tema | Fuente A | Interpretación A | Fuente B | Interpretación B | Fecha A | Fecha B | Resolución posterior | Conclusión | Estado |
|---|---|---|---|---|---|---|---|---|---|---|
| CON-001 | Base de cálculo métodos 1/2 | F01 15:22-19:03 | FIS explica base bruta para comparable/reporte | F08 §9 | El DF utiliza valores netos | 10-07-2026 | 16-09-2026 | No | La fórmula debe corregirse o validarse por escrito. | ABIERTA |
| CON-002 | Migración de planillas | F09 | Migración automática sin ingreso manual | F07 Anexo A/§3.1 | Carga inicial y nuevos Excel históricos de igual estructura; automatización avanzada y activos masivos fuera | 22-08-2026 | Contrato firmado en septiembre de 2026 | Sí | La firma del contrato acota y resuelve el alcance aprobado. | RESUELTA |
| CON-003 | Reimportación | F08 §11 | Actualizar/sin cambios y advertir duplicados | F07 Anexo A/§3.1 | Sin homologación, validación asistida, duplicados ni rollback | 16-09-2026 | Contrato firmado en septiembre de 2026 | No | El DF excede el contrato firmado. | ABIERTA |
| CON-004 | Volumen histórico | F08 §11 | Presenta 4.240 versus ~1.000 como discrepancia | F06 §8.1 y F07 | 4.240 corresponde al histórico; ~1.000 a casos activos futuros excluidos | 16-09-2026 | 24-08 / contrato firmado | Sí | Son universos distintos; el DF debe corregirse. | RESUELTA |
| CON-005 | Umbral de inactividad | F08 §12 | >15 días | F07 Anexo A | Período a definir por FIS | 16-09-2026 | Contrato firmado | No | 15 días no es baseline confirmado. | ABIERTA |
| CON-006 | Fuente productiva | F03 | Carpeta ya descargada | F08 pregunta 14 | Pregunta nuevamente por plataforma/API/correo/carpeta | Antes del 25-08-2026 | 16-09-2026 | Sí | Para Fase 1 la fuente es la carpeta; API y correo son evolución. | RESUELTA |
| CON-007 | Claim notice | F10/F07 | Claim notice es una de cuatro cartas | F07/F08 | También aparece carta de notificación a la naviera | Septiembre de 2026 | Contrato/DF | No | Debe confirmarse si son el mismo entregable. | ABIERTA |
| CON-008 | SUBRO | F06 §8.2 | La propuesta la mostraba como evolución | F07/F10 | Contrato y cliente la excluyen | 24-08-2026 | Septiembre de 2026 | Sí | Prevalece la exclusión del contrato firmado y la confirmación posterior. | RESUELTA |
| CON-009 | Primera versión | F05 | Próxima semana | F05/F11 | Semana siguiente o subsiguiente; 1-2 semanas | Posterior al 25-08-2026 | 15-09-2026 | Sí | Es una versión utilizable, no la entrega final. | RESUELTA |

## 6. Preguntas abiertas

| ID | Tema | Pregunta | Por qué existe | Fuentes | Impacto |
|---|---|---|---|---|---|
| OPEN-001 | Cálculo | ¿Cuáles son las fórmulas exactas de los tres métodos, incluyendo base bruta/neta, costos, unidades, límites, redondeos y ejemplos aprobados? | El DF contradice la base bruta explicada para métodos 1/2. | F01; F07; F08 §9 | ALTO |
| OPEN-002 | Referencia | ¿Cuál es la fórmula oficial completa de la referencia, incluidos tokens, separadores, prescripción, correlativo y fuente del correlativo? | La regla fue explicada verbalmente, pero no consolidada. | F01; F02; F06 | ALTO |
| OPEN-003 | Prescripción | ¿Cuál es la matriz oficial de jurisdicción, modo de transporte, fecha base, plazo, extensiones y excepciones? | El contrato obliga a FIS a entregar las reglas vigentes y aún no están cerradas en el DF. | F01; F02; F07 | ALTO |
| OPEN-004 | Cartas | ¿Claim notice y carta de notificación a la naviera son el mismo documento? | Ambos nombres aparecen como salidas contractuales/funcionales. | F07; F08; F10 | ALTO |
| OPEN-005 | Cartas | ¿Cuáles son las plantillas oficiales, textos legales, campos obligatorios, formato y reglas de firma de AoR, Harvest, LoA y claim notice? | El contrato exige plantillas entregadas o validadas por FIS. | F07 §7 y Anexo A; F08 §10 | ALTO |
| OPEN-006 | Checklist documental | ¿Cuál es el checklist por tipo de caso y qué documentos pueden marcarse como no aplicables? | La función está contratada, pero su contenido no fue entregado. | F01; F07; F08 §8.5 | ALTO |
| OPEN-007 | Traspaso | ¿Qué condiciones exactas habilitan el cierre hacia FIS y cuáles hacia Lawgistic? | El DF propone condiciones, pero no consta aprobación de FIS. | F07; F08 §14 | ALTO |
| OPEN-008 | Inactividad | ¿Qué evento reinicia el contador, se usan días hábiles o corridos, cuál es el umbral y qué estados quedan excluidos? | El contrato deja el período a definición de FIS; 15 días no está confirmado. | F01; F07; F08 §12 | ALTO |
| OPEN-009 | Alertas | ¿Qué rol recibe cada alerta y por qué canal? | La discriminación por perfil y canal no está cerrada. | F01; F07; F08 §12 | MEDIO |
| OPEN-010 | Histórico | ¿Cuál es el archivo definitivo de las 39 hojas, su versión y los campos obligatorios? | El contrato fija volumen aproximado, pero FIS debe entregar la estructura real. | F07 §7; F08 §11 | MEDIO |
| OPEN-011 | Documentos | ¿Cuál es el corpus productivo cerrado y qué precisión mínima se aceptará para clasificación, OCR y extracción? | Los ejemplos no equivalen a lista ni umbral de aceptación aprobados. | F06; F07; F08 §§8.3-8.6 | MEDIO |

## 7. Hallazgos priorizados

### QA-FUNC-001

- **Severidad:** P0 — BLOQUEANTE
- **Tema:** Fórmula de pérdida
- **Requerimiento:** Los métodos 1 y 2 deben respetar la base aprobada por FIS.
- **Fuente:** F01 15:22-19:03; F08 §9
- **Definición cliente:** Base bruta explicada para comparable/reporte
- **Definición documento FIS:** El DF usa valores netos
- **Diferencia:** Cambio material de fórmula.
- **Impacto:** Resultados monetarios incorrectos y aceptación imposible.
- **Recomendación:** Cerrar fichas matemáticas y ejemplos firmados antes del UAT.
- **Estado:** ABIERTO

### QA-FUNC-002

- **Severidad:** P1 — CRÍTICO
- **Tema:** Importación recurrente
- **Requerimiento:** La importación debe respetar el límite del contrato firmado.
- **Fuente:** F07 Anexo A/§3.1; F08 §11
- **Definición cliente:** Incorporar nuevos Excel históricos de igual estructura sin homologación, duplicados ni rollback
- **Definición documento FIS:** El DF define actualización, sin cambios y advertencia de duplicados
- **Diferencia:** El DF promete más que el alcance contratado.
- **Impacto:** Controversia de aceptación y comportamiento de datos incorrecto.
- **Recomendación:** Eliminar esas promesas del DF o formalizar una Solicitud de Cambio.
- **Estado:** ABIERTO

### QA-FUNC-003

- **Severidad:** P1 — CRÍTICO
- **Tema:** Referencia interna
- **Requerimiento:** La identificación automática exige una convención implementable.
- **Fuente:** F01 6:14; F02 7:25-11:14; F06 §4.2
- **Definición cliente:** Convención verbal con etapa, FIS, oponente, año, prescripción y correlativo
- **Definición documento FIS:** El DF solo remite a una convención aprobada
- **Diferencia:** No existe fórmula canónica cerrada.
- **Impacto:** Duplicados, búsquedas y prescripción pueden fallar.
- **Recomendación:** Documentar tokens, separadores, fuente del correlativo y reglas de corrección.
- **Estado:** ABIERTO

### QA-FUNC-004

- **Severidad:** P1 — CRÍTICO
- **Tema:** Prescripción
- **Requerimiento:** La plataforma contratada debe calcular alertas bajo La Haya/Hamburgo.
- **Fuente:** F01; F02; F07 Anexo A y §7
- **Definición cliente:** FIS debe entregar reglas vigentes
- **Definición documento FIS:** El DF deja plazos, fecha base y excepciones por confirmar
- **Diferencia:** Dependencia crítica todavía abierta.
- **Impacto:** Riesgo de pérdida del derecho a recupero.
- **Recomendación:** FIS debe aprobar una matriz jurisdicción-modo-fecha base-plazo-excepciones.
- **Estado:** ABIERTO

### QA-FUNC-005

- **Severidad:** P1 — CRÍTICO
- **Tema:** Cartas oficiales
- **Requerimiento:** Las cuatro cartas contratadas dependen de plantillas entregadas o validadas por FIS.
- **Fuente:** F07 Anexo A y §7; F10
- **Definición cliente:** AoR, Harvest, LoA y claim notice
- **Definición documento FIS:** El DF no contiene textos/campos/firma aprobados y mantiene nomenclatura ambigua
- **Diferencia:** Contenido de aceptación no cerrado.
- **Impacto:** Documentos incorrectos o duplicación de entregables.
- **Recomendación:** Recibir/versionar plantillas y resolver claim notice versus notificación a naviera.
- **Estado:** ABIERTO

### QA-FUNC-006

- **Severidad:** P2 — ALTO
- **Tema:** Inactividad
- **Requerimiento:** La alerta debe usar un movimiento real y un umbral definido por FIS.
- **Fuente:** F01; F07; F08 §12
- **Definición cliente:** Período a definir por FIS
- **Definición documento FIS:** El DF propone más de 15 días sin cerrar calendario/eventos
- **Diferencia:** Regla operativa incompleta.
- **Impacto:** Alertas falsas o manipulables.
- **Recomendación:** Definir evento válido, días, estados excluidos y destinatarios.
- **Estado:** ABIERTO

### QA-FUNC-007

- **Severidad:** P2 — ALTO
- **Tema:** Traspaso
- **Requerimiento:** Deben definirse guardas de cierre hacia FIS y Lawgistic.
- **Fuente:** F07; F08 §14
- **Definición cliente:** Cierre local y bloqueo del cálculo
- **Definición documento FIS:** El DF propone condiciones no aprobadas
- **Diferencia:** No existe checklist de completitud vinculante.
- **Impacto:** Casos incompletos pueden avanzar o quedar bloqueados.
- **Recomendación:** Aprobar checklist por destino.
- **Estado:** ABIERTO

### QA-FUNC-008

- **Severidad:** P2 — ALTO
- **Tema:** Histórico 1.000 versus 4.240
- **Requerimiento:** El volumen contractual es ~4.240/39; ~1.000 corresponde a activos masivos futuros.
- **Fuente:** F06; F07; F08 §11
- **Definición cliente:** Universos distintos
- **Definición documento FIS:** El DF los presenta como una discrepancia
- **Diferencia:** Conflación conceptual.
- **Impacto:** Plan de carga equivocado.
- **Recomendación:** Corregir el DF y separar histórico de activos excluidos.
- **Estado:** ABIERTO

### QA-FUNC-009

- **Severidad:** P3 — MEDIO
- **Tema:** Inspector y JSI
- **Requerimiento:** Inspector está fuera del baseline firmado.
- **Fuente:** F06 §5; F07 §3.1; F08 §13
- **Definición cliente:** Perfil Inspector solo como evolución
- **Definición documento FIS:** El DF agrega flujo y carta JSI no aprobados
- **Diferencia:** Contaminación de alcance.
- **Impacto:** Puede convertirse en compromiso implícito.
- **Recomendación:** Mover todo el detalle a evolución/Change Request.
- **Estado:** ABIERTO

### QA-FUNC-010

- **Severidad:** P3 — MEDIO
- **Tema:** Fuente de entrada
- **Requerimiento:** Fase 1 recibe una carpeta descargada.
- **Fuente:** F03; F07
- **Definición cliente:** Decisión cerrada
- **Definición documento FIS:** El DF vuelve a preguntar la fuente productiva
- **Diferencia:** Pregunta obsoleta.
- **Impacto:** Reapertura innecesaria de alcance.
- **Recomendación:** Fijar carpeta como baseline y mover integraciones a evolución.
- **Estado:** ABIERTO

### QA-FUNC-011

- **Severidad:** P3 — MEDIO
- **Tema:** Errores de lote
- **Requerimiento:** Aislar un archivo incompatible es una decisión técnica útil pero no acordada.
- **Fuente:** Solo F08 §8.3
- **Definición cliente:** Sin fuente contractual
- **Definición documento FIS:** Se presenta como criterio de aceptación
- **Diferencia:** Diseño no trazado.
- **Impacto:** Discusión en UAT.
- **Recomendación:** Validarlo o etiquetarlo como decisión técnica interna.
- **Estado:** REQUIERE VALIDACIÓN

### QA-FUNC-012

- **Severidad:** P4 — BAJO
- **Tema:** Nomenclatura
- **Requerimiento:** Los nombres deben ser únicos y consistentes.
- **Fuente:** F01-F10
- **Definición cliente:** Lawgistic y claim notice como nombres de referencia
- **Definición documento FIS:** El DF usa variantes
- **Diferencia:** Inconsistencia editorial.
- **Impacto:** Errores de búsqueda o interpretación.
- **Recomendación:** Aprobar glosario único.
- **Estado:** ABIERTO
