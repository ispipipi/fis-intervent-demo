# QA DEL DOCUMENTO FUNCIONAL FIS

## Catálogo DF

| ID | Módulo | Descripción verificable |
|---|---|---|
| DF-001 | Propósito y alcance | Delimita la revisión a Intervent Preclaim y subordina cambios al contrato/Change Request. |
| DF-002 | Contexto operativo | Resume fuentes dispersas, revisión humana y objetivo de expediente trazable. |
| DF-003 | Resultados esperados | Expediente, inventario, ficha, cálculo, revisión y traspaso controlado. |
| DF-004 | Alcance — usuarios | Perfiles Handler, Gerente y CEO/Dirección. |
| DF-005 | Alcance — creación | Alta manual, carpeta masiva y duplicados. |
| DF-006 | Alcance — documentos | Clasificación, OCR, renombrado, original y corrección. |
| DF-007 | Alcance — expediente | Ficha única con datos, documentos, causa, cálculo, estado, handler y prescripción. |
| DF-008 | Alcance — extracción | Extracción asistida desde BL, facturas, liquidaciones y documentos definidos. |
| DF-009 | Alcance — causa y mérito | Recomendación preliminar sujeta a decisión humana. |
| DF-010 | Alcance — cartas | AoR, Harvest, LoA y Claim Notice. |
| DF-011 | Alcance — pérdida | Tres métodos, USD/CLP, venta firme, nota de crédito e ítems adicionales. |
| DF-012 | Alcance — prescripción | Cálculo y alertas conforme a jurisdicciones y reglas aprobadas. |
| DF-013 | Alcance — gestión | Dashboard, benchmark, historial y reporte. |
| DF-014 | Alcance — memoria | Carga histórica y consulta separada de casos activos. |
| DF-015 | Alcance — traspaso | Cierre local hacia FIS o Lawgistic sin integración posterior. |
| DF-016 | Alcance — manual | Manual integrado del flujo y funciones. |
| DF-017 | Exclusiones generales | Integraciones externas y gestión posterior, entre otras. |
| DF-018 | Exclusión/evolución de monedas | EUR y FX automático fuera del baseline. |
| DF-019 | Exclusión/evolución Inspector | Perfil restringido sujeto a extensión. |
| DF-020 | Exclusión de SUBRO y destrucción | No forman parte de cuatro templates base. |
| DF-021 | Exclusión de envío por correo | Solo preparación/descarga de solicitud documental. |
| DF-022 | Evolución de agrupación por nave | No se considera mínimo contractual. |
| DF-023 | Flujo — ingreso | Creación o carga de carpeta. |
| DF-024 | Flujo — identificación | Referencia, duplicidad y corrección. |
| DF-025 | Flujo — procesamiento | Progreso, originales y errores. |
| DF-026 | Flujo — clasificación | Tipo, nombre, confianza y corrección. |
| DF-027 | Flujo — extracción | Campos extraídos y confirmación. |
| DF-028 | Flujo — inventario | Checklist, faltantes y solicitudes sugeridas. |
| DF-029 | Flujo — análisis | Tipo, causa, sustento y mérito. |
| DF-030 | Flujo — cálculo | Comparación, selección y justificación. |
| DF-031 | Flujo — documentos | Generación y descarga de cartas. |
| DF-032 | Flujo — cierre | Reporte, destino y reversión. |
| DF-033 | Estados | Catálogo de seis estados y acciones generales. |
| DF-034 | Perfiles y permisos | Matriz Handler/Gerente/CEO/Inspector. |
| DF-035 | Caso y referencia | Corrección, duplicidad, ETA/real y trazabilidad. |
| DF-036 | Carga documental | Carpeta, formatos, OCR, trazabilidad y errores. |
| DF-037 | Clasificación y renombrado | Grupos documentales y corrección. |
| DF-038 | Expediente e inventario | Estados documentales, cobertura, checklist y solicitud. |
| DF-039 | Datos extraídos | Diccionario de campos y reglas de revisión. |
| DF-040 | Resumen, tipo, causa y mérito | Salidas editables y explicables. |
| DF-041 | Métodos de pérdida | Cinco filas de cálculo y datos requeridos. |
| DF-042 | Reglas de cálculo por confirmar | Bases, costos, límites, unidades, nota de crédito, método y redondeo. |
| DF-043 | Monedas y FX | USD/CLP, monedas distintas y tipo de cambio. |
| DF-044 | Templates base | Claim Notice, AoR, Harvest y LoA; exclusiones. |
| DF-045 | Mantenedor de templates | Versiones, vigencia, tokens, vista previa y auditoría. |
| DF-046 | Carga histórica | Carga inicial, volumen y origen. |
| DF-047 | Consulta y separación histórica | Búsqueda y aislamiento de cartera activa. |
| DF-048 | Importación/duplicados/exportación histórica | Reimportación, duplicados y exportación condicionada. |
| DF-049 | Inactividad | Alerta mayor a 15 días y validaciones pendientes. |
| DF-050 | Agrupación nave/viaje | Evolución para naves masivas. |
| DF-051 | Dashboard y benchmark | Indicadores y comparaciones por handler. |
| DF-052 | Inspector y JSI | Acceso acotado y carta de inspección conjunta. |
| DF-053 | Traspaso y reversión | Requisitos, bloqueo, motivo y preservación. |
| DF-054 | Trazabilidad, seguridad y datos | Auditoría, accesos, respaldos, eliminación y secretos. |
| DF-055 | Manual integrado | Contenido y acceso del manual. |
| DF-056 | Matriz/preguntas de validación | Catorce definiciones aún abiertas. |
| DF-057 | Criterios de aceptación | Pruebas mínimas por flujo, documentos, datos, cálculo, cartas, memoria y traspaso. |

## Cruce inverso DF → evidencia del cliente

| DF | Funcionalidad | Evidencia cliente | Estado | Observación |
|---|---|---|---|---|
| DF-001 | Delimita la revisión a Intervent Preclaim y subordina cambios al contrato/Change Request. | F07 §§1.4 y 4.2 | RESPALDADO | Correcto: el contrato v6.0 firmado fija el baseline y la gestión de cambios. |
| DF-002 | Resume fuentes dispersas, revisión humana y objetivo de expediente trazable. | F01-F03; F07 §1.1 | RESPALDADO | Síntesis fiel. |
| DF-003 | Expediente, inventario, ficha, cálculo, revisión y traspaso controlado. | F01-F03; F07 Anexo A | RESPALDADO | Alineado con el objetivo. |
| DF-004 | Perfiles Handler, Gerente y CEO/Dirección. | F07 Anexo A | RESPALDADO | Roles contractuales. |
| DF-005 | Alta manual, carpeta masiva y duplicados. | F07 Anexo A | RESPALDADO | Alta y duplicados incluidos. |
| DF-006 | Clasificación, OCR, renombrado, original y corrección. | F03; F07 Anexo A | RESPALDADO | Clasificación y renombrado incluidos. |
| DF-007 | Ficha única con datos, documentos, causa, cálculo, estado, handler y prescripción. | F02; F07 Anexo A | RESPALDADO | Expediente único. |
| DF-008 | Extracción asistida desde BL, facturas, liquidaciones y documentos definidos. | F07 Anexo A; F10 | RESPALDADO | Extracción asistida incluida. |
| DF-009 | Recomendación preliminar sujeta a decisión humana. | F01; F07 Anexo A | RESPALDADO | Revisión humana central. |
| DF-010 | AoR, Harvest, LoA y Claim Notice. | F07 Anexo A; F10 | RESPALDADO | Cuatro cartas finales correctas. |
| DF-011 | Tres métodos, USD/CLP, venta firme, nota de crédito e ítems adicionales. | F01; F07 Anexo A | PARCIALMENTE RESPALDADO | Alcance general correcto; fórmulas aún no. |
| DF-012 | Cálculo y alertas conforme a jurisdicciones y reglas aprobadas. | F01-F02; F07 Anexo A | PARCIALMENTE RESPALDADO | Faltan plazos y fecha base exacta. |
| DF-013 | Dashboard, benchmark, historial y reporte. | F01; F07 Anexo A | RESPALDADO | Dashboard y benchmark contratados. |
| DF-014 | Carga histórica y consulta separada de casos activos. | F05; F07 Anexo A | RESPALDADO | Carga y consulta histórica. |
| DF-015 | Cierre local hacia FIS o Lawgistic sin integración posterior. | F07 Anexo A | RESPALDADO | Cierre local correcto. |
| DF-016 | Manual integrado del flujo y funciones. | F07 Anexo A | RESPALDADO | Manual incluido. |
| DF-017 | Integraciones externas y gestión posterior, entre otras. | F07 §3.1 | RESPALDADO | Exclusiones alineadas. |
| DF-018 | EUR y FX automático fuera del baseline. | F06 §8.2; F07 §3.1 | RESPALDADO | EUR/FX externo fuera de Fase 1. |
| DF-019 | Perfil restringido sujeto a extensión. | F06 §5; F07 §3.1 | RESPALDADO | Inspector es evolución. |
| DF-020 | No forman parte de cuatro templates base. | F07 §3.1; F10 | RESPALDADO | SUBRO finalmente excluida. |
| DF-021 | Solo preparación/descarga de solicitud documental. | F07 §3.1 | RESPALDADO | Sin envío automático. |
| DF-022 | No se considera mínimo contractual. | F06 §8.3; F07 §3.1 | RESPALDADO | Agrupación queda fuera. |
| DF-023 | Creación o carga de carpeta. | F03; F07 Anexo A | RESPALDADO | Ingreso desde carpeta. |
| DF-024 | Referencia, duplicidad y corrección. | F01-F02; F07 Anexo A | PARCIALMENTE RESPALDADO | No codifica convención exacta ni correlativo. |
| DF-025 | Progreso, originales y errores. | F07 Anexo A | PARCIALMENTE RESPALDADO | Aislamiento de errores no tiene fuente acordada. |
| DF-026 | Tipo, nombre, confianza y corrección. | F07 Anexo A | PARCIALMENTE RESPALDADO | Confianza no tiene umbral acordado. |
| DF-027 | Campos extraídos y confirmación. | F07 Anexo A | RESPALDADO | Extracción con validación. |
| DF-028 | Checklist, faltantes y solicitudes sugeridas. | F01; F07 Anexo A | PARCIALMENTE RESPALDADO | Checklist oficial y N/A pendientes. |
| DF-029 | Tipo, causa, sustento y mérito. | F01; F07 Anexo A | RESPALDADO | Análisis asistido. |
| DF-030 | Comparación, selección y justificación. | F01; F07 Anexo A | RESPALDADO | Comparación y justificación. |
| DF-031 | Generación y descarga de cartas. | F01; F07 Anexo A | RESPALDADO | Cartas base. |
| DF-032 | Reporte, destino y reversión. | F07 Anexo A | RESPALDADO | Cierre/reversión. |
| DF-033 | Catálogo de seis estados y acciones generales. | F07 Anexo A | PARCIALMENTE RESPALDADO | Estados sí; transiciones completas no. |
| DF-034 | Matriz Handler/Gerente/CEO/Inspector. | F07 Anexo A | RESPALDADO | Inspector correctamente condicionado. |
| DF-035 | Corrección, duplicidad, ETA/real y trazabilidad. | F02; F07 Anexo A | PARCIALMENTE RESPALDADO | Referencia exacta pendiente. |
| DF-036 | Carpeta, formatos, OCR, trazabilidad y errores. | F07 Anexo A | PARCIALMENTE RESPALDADO | TXT/JSON/XML/MD y manejo de errores son demo/no validados. |
| DF-037 | Grupos documentales y corrección. | F07 Anexo A | RESPALDADO | Aclarar que SUBRO puede clasificarse aunque no se genere. |
| DF-038 | Estados documentales, cobertura, checklist y solicitud. | F07 Anexo A | PARCIALMENTE RESPALDADO | Estados observado/reemplazado y N/A no contractuales. |
| DF-039 | Diccionario de campos y reglas de revisión. | F01-F02; F06 | PARCIALMENTE RESPALDADO | Prioridades y algunos campos opcionales no validados. |
| DF-040 | Salidas editables y explicables. | F01; F07 Anexo A | RESPALDADO | Correcto. |
| DF-041 | Cinco filas de cálculo y datos requeridos. | F01; F07 Anexo A | CONTRADICTORIO | El DF usa neto en métodos 1/2; FIS explicó base bruta. |
| DF-042 | Bases, costos, límites, unidades, nota de crédito, método y redondeo. | F08 | SIN EVIDENCIA | Es inventario de decisiones pendientes, no una regla ya acordada. |
| DF-043 | USD/CLP, monedas distintas y tipo de cambio. | F07 Anexo A | PARCIALMENTE RESPALDADO | USD/CLP sí; reglas FX no. |
| DF-044 | Claim Notice, AoR, Harvest y LoA; exclusiones. | F07 Anexo A; F10 | RESPALDADO | Cuatro cartas y exclusiones correctas. |
| DF-045 | Versiones, vigencia, tokens, vista previa y auditoría. | F08 | PARCIALMENTE RESPALDADO | Detalle de mantenedor no está en contrato. |
| DF-046 | Carga inicial, volumen y origen. | F05; F07 Anexo A | RESPALDADO | 4.240/39 es baseline más reciente. |
| DF-047 | Búsqueda y aislamiento de cartera activa. | F06; F07 Anexo A | RESPALDADO | Consulta/separación respaldadas. |
| DF-048 | Reimportación, duplicados y exportación condicionada. | F07 Anexo A y §3.1 | CONTRADICTORIO | Reimportación con actualización/duplicados excede el contrato. |
| DF-049 | Alerta mayor a 15 días y validaciones pendientes. | F01; F06; F07 Anexo A | PARCIALMENTE RESPALDADO | La función sí; 15 días no confirmado. |
| DF-050 | Evolución para naves masivas. | F06 §8.3; F07 §3.1 | RESPALDADO | Correctamente como evolución. |
| DF-051 | Indicadores y comparaciones por handler. | F07 Anexo A | PARCIALMENTE RESPALDADO | Métricas, periodos y audiencia requieren confirmación. |
| DF-052 | Acceso acotado y carta de inspección conjunta. | F06 §5; F07 §3.1; F08 §13 | PARCIALMENTE RESPALDADO | Inspector está respaldado solo como evolución excluida; la carta JSI y sus campos no tienen fuente aprobada. |
| DF-053 | Requisitos, bloqueo, motivo y preservación. | F07 Anexo A | PARCIALMENTE RESPALDADO | Checklist previo y preservación detallada no aprobados. |
| DF-054 | Auditoría, accesos, respaldos, eliminación y secretos. | F07 §§9-10 y Anexo A | PARCIALMENTE RESPALDADO | Falta explicitar no entrenamiento y criterios técnicos. |
| DF-055 | Contenido y acceso del manual. | F07 Anexo A | RESPALDADO | Manual incluido. |
| DF-056 | Catorce definiciones aún abiertas. | F08 | RESPALDADO | Preguntas válidas, salvo fuente productiva ya resuelta para Fase 1. |
| DF-057 | Pruebas mínimas por flujo, documentos, datos, cálculo, cartas, memoria y traspaso. | F07 §5.5 y Anexo A | PARCIALMENTE RESPALDADO | Faltan procedimiento contractual y fórmulas cerradas. |

## Hallazgos QA

### QA-FUNC-001

- **Severidad:** P0 — BLOQUEANTE
- **Tema:** Fórmula de pérdida
- **Requerimiento:** Los métodos 1 y 2 deben respetar la base aprobada por FIS.
- **Fuente:** F01 15:22-19:03; F08 §9
- **Definición cliente:** Base bruta explicada para comparable/reporte
- **Definición documento FIS:** El DF usa valores netos
- **Diferencia:** Cambio material de fórmula.
- **Impacto:** Resultados monetarios incorrectos y aceptación imposible.
- **Recomendación:** Cerrar fichas matemáticas y ejemplos firmados antes del UAT.
- **Estado:** ABIERTO

### QA-FUNC-002

- **Severidad:** P1 — CRÍTICO
- **Tema:** Importación recurrente
- **Requerimiento:** La importación debe respetar el límite del contrato firmado.
- **Fuente:** F07 Anexo A/§3.1; F08 §11
- **Definición cliente:** Incorporar nuevos Excel históricos de igual estructura sin homologación, duplicados ni rollback
- **Definición documento FIS:** El DF define actualización, sin cambios y advertencia de duplicados
- **Diferencia:** El DF promete más que el alcance contratado.
- **Impacto:** Controversia de aceptación y comportamiento de datos incorrecto.
- **Recomendación:** Eliminar esas promesas del DF o formalizar una Solicitud de Cambio.
- **Estado:** ABIERTO

### QA-FUNC-003

- **Severidad:** P1 — CRÍTICO
- **Tema:** Referencia interna
- **Requerimiento:** La identificación automática exige una convención implementable.
- **Fuente:** F01 6:14; F02 7:25-11:14; F06 §4.2
- **Definición cliente:** Convención verbal con etapa, FIS, oponente, año, prescripción y correlativo
- **Definición documento FIS:** El DF solo remite a una convención aprobada
- **Diferencia:** No existe fórmula canónica cerrada.
- **Impacto:** Duplicados, búsquedas y prescripción pueden fallar.
- **Recomendación:** Documentar tokens, separadores, fuente del correlativo y reglas de corrección.
- **Estado:** ABIERTO

### QA-FUNC-004

- **Severidad:** P1 — CRÍTICO
- **Tema:** Prescripción
- **Requerimiento:** La plataforma contratada debe calcular alertas bajo La Haya/Hamburgo.
- **Fuente:** F01; F02; F07 Anexo A y §7
- **Definición cliente:** FIS debe entregar reglas vigentes
- **Definición documento FIS:** El DF deja plazos, fecha base y excepciones por confirmar
- **Diferencia:** Dependencia crítica todavía abierta.
- **Impacto:** Riesgo de pérdida del derecho a recupero.
- **Recomendación:** FIS debe aprobar una matriz jurisdicción-modo-fecha base-plazo-excepciones.
- **Estado:** ABIERTO

### QA-FUNC-005

- **Severidad:** P1 — CRÍTICO
- **Tema:** Cartas oficiales
- **Requerimiento:** Las cuatro cartas contratadas dependen de plantillas entregadas o validadas por FIS.
- **Fuente:** F07 Anexo A y §7; F10
- **Definición cliente:** AoR, Harvest, LoA y claim notice
- **Definición documento FIS:** El DF no contiene textos/campos/firma aprobados y mantiene nomenclatura ambigua
- **Diferencia:** Contenido de aceptación no cerrado.
- **Impacto:** Documentos incorrectos o duplicación de entregables.
- **Recomendación:** Recibir/versionar plantillas y resolver claim notice versus notificación a naviera.
- **Estado:** ABIERTO

### QA-FUNC-006

- **Severidad:** P2 — ALTO
- **Tema:** Inactividad
- **Requerimiento:** La alerta debe usar un movimiento real y un umbral definido por FIS.
- **Fuente:** F01; F07; F08 §12
- **Definición cliente:** Período a definir por FIS
- **Definición documento FIS:** El DF propone más de 15 días sin cerrar calendario/eventos
- **Diferencia:** Regla operativa incompleta.
- **Impacto:** Alertas falsas o manipulables.
- **Recomendación:** Definir evento válido, días, estados excluidos y destinatarios.
- **Estado:** ABIERTO

### QA-FUNC-007

- **Severidad:** P2 — ALTO
- **Tema:** Traspaso
- **Requerimiento:** Deben definirse guardas de cierre hacia FIS y Lawgistic.
- **Fuente:** F07; F08 §14
- **Definición cliente:** Cierre local y bloqueo del cálculo
- **Definición documento FIS:** El DF propone condiciones no aprobadas
- **Diferencia:** No existe checklist de completitud vinculante.
- **Impacto:** Casos incompletos pueden avanzar o quedar bloqueados.
- **Recomendación:** Aprobar checklist por destino.
- **Estado:** ABIERTO

### QA-FUNC-008

- **Severidad:** P2 — ALTO
- **Tema:** Histórico 1.000 versus 4.240
- **Requerimiento:** El volumen contractual es ~4.240/39; ~1.000 corresponde a activos masivos futuros.
- **Fuente:** F06; F07; F08 §11
- **Definición cliente:** Universos distintos
- **Definición documento FIS:** El DF los presenta como una discrepancia
- **Diferencia:** Conflación conceptual.
- **Impacto:** Plan de carga equivocado.
- **Recomendación:** Corregir el DF y separar histórico de activos excluidos.
- **Estado:** ABIERTO

### QA-FUNC-009

- **Severidad:** P3 — MEDIO
- **Tema:** Inspector y JSI
- **Requerimiento:** Inspector está fuera del baseline firmado.
- **Fuente:** F06 §5; F07 §3.1; F08 §13
- **Definición cliente:** Perfil Inspector solo como evolución
- **Definición documento FIS:** El DF agrega flujo y carta JSI no aprobados
- **Diferencia:** Contaminación de alcance.
- **Impacto:** Puede convertirse en compromiso implícito.
- **Recomendación:** Mover todo el detalle a evolución/Change Request.
- **Estado:** ABIERTO

### QA-FUNC-010

- **Severidad:** P3 — MEDIO
- **Tema:** Fuente de entrada
- **Requerimiento:** Fase 1 recibe una carpeta descargada.
- **Fuente:** F03; F07
- **Definición cliente:** Decisión cerrada
- **Definición documento FIS:** El DF vuelve a preguntar la fuente productiva
- **Diferencia:** Pregunta obsoleta.
- **Impacto:** Reapertura innecesaria de alcance.
- **Recomendación:** Fijar carpeta como baseline y mover integraciones a evolución.
- **Estado:** ABIERTO

### QA-FUNC-011

- **Severidad:** P3 — MEDIO
- **Tema:** Errores de lote
- **Requerimiento:** Aislar un archivo incompatible es una decisión técnica útil pero no acordada.
- **Fuente:** Solo F08 §8.3
- **Definición cliente:** Sin fuente contractual
- **Definición documento FIS:** Se presenta como criterio de aceptación
- **Diferencia:** Diseño no trazado.
- **Impacto:** Discusión en UAT.
- **Recomendación:** Validarlo o etiquetarlo como decisión técnica interna.
- **Estado:** REQUIERE VALIDACIÓN

### QA-FUNC-012

- **Severidad:** P4 — BAJO
- **Tema:** Nomenclatura
- **Requerimiento:** Los nombres deben ser únicos y consistentes.
- **Fuente:** F01-F10
- **Definición cliente:** Lawgistic y claim notice como nombres de referencia
- **Definición documento FIS:** El DF usa variantes
- **Diferencia:** Inconsistencia editorial.
- **Impacto:** Errores de búsqueda o interpretación.
- **Recomendación:** Aprobar glosario único.
- **Estado:** ABIERTO

## Observaciones editoriales y de verificabilidad

- Mantener como fuente principal el contrato v6.0 firmado y explicitar su prelación sobre la propuesta 167.
- Separar claramente requisitos contratados, decisiones internas de diseño y evoluciones.
- No usar 1.000 casos como volumen histórico: esa cifra corresponde a activos futuros excluidos.
- Eliminar del baseline la actualización/detección de duplicados de reimportaciones o tramitar una Solicitud de Cambio.
- Aclarar que SUBRO puede ser un documento de entrada clasificable aunque su generación esté excluida.
- Unificar Lawgistic/Lawgistics y Claim Notice/claim notice.
- Convertir la tabla de cálculo en fórmulas y ejemplos, no solo prosa.
- Eliminar o mover a evolución la pregunta de fuente productiva ya resuelta para Fase 1.
