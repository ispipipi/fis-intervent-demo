# ROLES Y PERMISOS FIS

| Acción | Rol | Permitido | Restricción | Fuente |
|---|---|---|---|---|
| Crear caso | Handler | Sí | Referencia y mínimos | F07 |
| Cargar carpeta/documentos | Handler | Sí | Caso autorizado | F07 |
| Corregir clasificación/datos | Handler | Sí | Con trazabilidad | F07/F08 |
| Confirmar causa/mérito | Handler | Sí | Decisión humana | F07 |
| Calcular/seleccionar método | Handler | Sí | Justificación obligatoria | F07 |
| Generar/aprobar cartas | Handler | Sí | Datos confirmados | F07 |
| Traspasar | Handler | Sí | Checklist por definir | F07/F08 |
| Revertir traspaso | Handler | No | Solo Gerente | F07 |
| Revertir traspaso | Gerente | Sí | Motivo obligatorio | F07 |
| Ver cartera completa/benchmark | Gerente | Sí | Ámbito exacto por validar | F07 |
| Editar operación | CEO/Dirección | No | Solo lectura | F07 |
| Consultar indicadores/reportes | CEO/Dirección | Sí | Solo lectura | F07 |
| Buscar casos asignados | Inspector | No en Fase 1 | Solo si se aprueba evolución | F07/F08 |
| Modificar reglas globales | Handler | No | Rol administrativo no definido | F08 |
| Administrar templates | Rol no definido | Pendiente | Publicación/versiones | F08 |
| Ingresar FX manual | Usuario autorizado no definido | Pendiente | Debe auditarse | F08 |
| Importar histórico | Rol no definido | Pendiente | Misma estructura | F07 |

## Ambigüedades

- No existe rol administrativo definido para templates, parámetros, FX, checklists e importación histórica.
- No se ha definido si el Handler ve solo su cartera o todos los casos.
- El perfil Inspector está expresamente fuera de Fase 1; el detalle de carta JSI del DF no está respaldado por el contrato firmado.
