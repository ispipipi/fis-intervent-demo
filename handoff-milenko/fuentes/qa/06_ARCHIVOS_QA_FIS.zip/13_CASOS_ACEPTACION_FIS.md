# CASOS DE ACEPTACIÓN FIS

Los casos marcados con una fuente pendiente no deben ejecutarse como criterio contractual hasta resolver la regla indicada.

## AC-001

- **Requerimiento relacionado:** REQ-001/002
- **Dado que:** Existe una carpeta de caso descargada
- **Cuando:** el Handler carga la carpeta completa
- **Entonces:** todos los archivos se incorporan en un solo lote sin acceso a la plataforma externa
- **Fuente:** F03; F07

## AC-002

- **Requerimiento relacionado:** REQ-003
- **Dado que:** el Handler dispone de datos mínimos
- **Cuando:** crea un caso manual
- **Entonces:** el sistema guarda el caso y permite continuar con documentos
- **Fuente:** F07

## AC-003

- **Requerimiento relacionado:** REQ-015
- **Dado que:** ya existe una referencia
- **Cuando:** se intenta guardar otra igual
- **Entonces:** el sistema advierte la duplicidad y no fusiona ni elimina automáticamente
- **Fuente:** F07; F08

## AC-004

- **Requerimiento relacionado:** REQ-014
- **Dado que:** una referencia contiene un error
- **Cuando:** el Handler la corrige
- **Entonces:** se registra valor anterior, nuevo, usuario y fecha
- **Fuente:** F08

## AC-005

- **Requerimiento relacionado:** REQ-005/012
- **Dado que:** hay documentos sin clasificar
- **Cuando:** termina el procesamiento
- **Entonces:** cada documento recibe categoría propuesta y puede corregirse manualmente
- **Fuente:** F07

## AC-006

- **Requerimiento relacionado:** REQ-006/007
- **Dado que:** un documento fue clasificado
- **Cuando:** el sistema lo renombra
- **Entonces:** se conserva el original y el vínculo con el nombre normalizado
- **Fuente:** F07

## AC-007

- **Requerimiento relacionado:** REQ-008
- **Dado que:** un PDF es una imagen escaneada
- **Cuando:** se procesa
- **Entonces:** se aplica OCR o queda marcado para revisión
- **Fuente:** F07; F08

## AC-008

- **Requerimiento relacionado:** REQ-009
- **Dado que:** se cargan PDF, XLSX, XLS y CSV válidos
- **Cuando:** se procesa el lote
- **Entonces:** los cuatro formatos son aceptados
- **Fuente:** F07

## AC-009

- **Requerimiento relacionado:** REQ-018
- **Dado que:** un caso existe
- **Cuando:** un usuario autorizado abre su ficha
- **Entonces:** encuentra datos, documentos, análisis, cálculo, estado, handler e historial en un expediente único
- **Fuente:** F02; F07

## AC-010

- **Requerimiento relacionado:** REQ-019/020
- **Dado que:** el expediente tiene documentos parciales
- **Cuando:** se ejecuta el checklist
- **Entonces:** se muestran disponibles y faltantes por separado
- **Fuente:** F01; F07

## AC-011

- **Requerimiento relacionado:** REQ-024
- **Dado que:** existe checklist aplicable
- **Cuando:** cambia la cobertura
- **Entonces:** el porcentaje se recalcula sobre los ítems aplicables
- **Fuente:** F07

## AC-012

- **Requerimiento relacionado:** REQ-025/026
- **Dado que:** existen faltantes confirmados
- **Cuando:** el Handler genera la solicitud
- **Entonces:** obtiene texto/listado descargable sin envío automático
- **Fuente:** F07

## AC-013

- **Requerimiento relacionado:** REQ-027
- **Dado que:** hay un BL legible
- **Cuando:** se procesa
- **Entonces:** los campos previstos se proponen con su fuente y quedan pendientes de confirmación
- **Fuente:** F07

## AC-014

- **Requerimiento relacionado:** REQ-028
- **Dado que:** hay una factura legible
- **Cuando:** se procesa
- **Entonces:** sus valores se proponen para ficha/cálculo y no son definitivos sin Handler
- **Fuente:** F07

## AC-015

- **Requerimiento relacionado:** REQ-029
- **Dado que:** hay una liquidación legible
- **Cuando:** se procesa
- **Entonces:** sus valores se proponen para los métodos comparativos
- **Fuente:** F07

## AC-016

- **Requerimiento relacionado:** REQ-031/032
- **Dado que:** un dato fue extraído
- **Cuando:** el Handler lo revisa
- **Entonces:** puede ver fuente, confirmar, editar o descartar
- **Fuente:** F06; F07

## AC-017

- **Requerimiento relacionado:** REQ-040
- **Dado que:** el caso tiene ETA y luego fecha real
- **Cuando:** se confirma la fecha real
- **Entonces:** ambas se distinguen y el cambio queda trazado
- **Fuente:** F02; F08

## AC-018

- **Requerimiento relacionado:** REQ-042
- **Dado que:** hay antecedentes suficientes
- **Cuando:** se genera resumen
- **Entonces:** el Handler puede editarlo antes de aprobarlo
- **Fuente:** F03; F07

## AC-019

- **Requerimiento relacionado:** REQ-043/044
- **Dado que:** hay documentos suficientes
- **Cuando:** el sistema analiza el caso
- **Entonces:** propone tipo y causa potencial sin presentarlos como decisión definitiva
- **Fuente:** F03; F07

## AC-020

- **Requerimiento relacionado:** REQ-045
- **Dado que:** se propone una causa
- **Cuando:** el Handler abre el sustento
- **Entonces:** ve documentos/datos usados
- **Fuente:** F07

## AC-021

- **Requerimiento relacionado:** REQ-046/047
- **Dado que:** se propone mérito preliminar
- **Cuando:** el Handler discrepa
- **Entonces:** puede modificar la conclusión y su decisión prevalece
- **Fuente:** F01; F07

## AC-022

- **Requerimiento relacionado:** REQ-048
- **Dado que:** el mérito automático es bajo
- **Cuando:** el Handler justifica continuidad comercial
- **Entonces:** el sistema no bloquea el caso
- **Fuente:** F01

## AC-023

- **Requerimiento relacionado:** REQ-049
- **Dado que:** los datos de los tres métodos están disponibles
- **Cuando:** se calcula pérdida
- **Entonces:** se muestran los tres resultados comparables
- **Fuente:** F01; F07

## AC-024

- **Requerimiento relacionado:** REQ-050
- **Dado que:** se selecciona un embarque comparable
- **Cuando:** se valida
- **Entonces:** cumple variedad, calibre, destino y fecha similar o queda rechazado
- **Fuente:** F01

## AC-025

- **Requerimiento relacionado:** REQ-052
- **Dado que:** no hay comparable pero existe reporte de mercado
- **Cuando:** se ejecuta método 2
- **Entonces:** se conserva reporte, fecha, plaza, unidad y moneda
- **Fuente:** F01; F08

## AC-026

- **Requerimiento relacionado:** REQ-054
- **Dado que:** aplica método 3
- **Cuando:** se calcula
- **Entonces:** compara factura con venta bruta conforme a fórmula aprobada
- **Fuente:** F01

## AC-027

- **Requerimiento relacionado:** REQ-055/056
- **Dado que:** existe venta firme o nota de crédito
- **Cuando:** se aplica la regla
- **Entonces:** el resultado conserva documento, motivo, signo y monto
- **Fuente:** F01; F07

## AC-028

- **Requerimiento relacionado:** REQ-057
- **Dado que:** el Handler agrega un ítem adicional
- **Cuando:** guarda el cálculo
- **Entonces:** el ítem exige concepto, monto, moneda, respaldo y justificación
- **Fuente:** F07; F08

## AC-029

- **Requerimiento relacionado:** REQ-058/060
- **Dado que:** hay varios resultados
- **Cuando:** el Handler elige uno
- **Entonces:** debe ingresar justificación antes de completar el cálculo
- **Fuente:** F07

## AC-030

- **Requerimiento relacionado:** REQ-061/062
- **Dado que:** el caso usa USD o CLP
- **Cuando:** se calcula
- **Entonces:** entradas y resultado conservan moneda
- **Fuente:** F07

## AC-031

- **Requerimiento relacionado:** REQ-063
- **Dado que:** las entradas usan monedas distintas
- **Cuando:** falta FX
- **Entonces:** el cálculo queda impedido o incompleto hasta registrar fecha y tipo de cambio
- **Fuente:** F08; requiere aprobación

## AC-032

- **Requerimiento relacionado:** REQ-065
- **Dado que:** se guarda un cálculo
- **Cuando:** se consulta su versión
- **Entonces:** muestra entradas, fuentes, moneda, fecha, resultado y usuario
- **Fuente:** F07; F08

## AC-033

- **Requerimiento relacionado:** REQ-067
- **Dado que:** un caso fue traspasado
- **Cuando:** un Handler intenta editar cálculo
- **Entonces:** la operación se rechaza
- **Fuente:** F07

## AC-034

- **Requerimiento relacionado:** REQ-069
- **Dado que:** existe template AoR activo
- **Cuando:** se genera AoR
- **Entonces:** usa solo datos confirmados y queda para aprobación
- **Fuente:** F07; F10

## AC-035

- **Requerimiento relacionado:** REQ-070
- **Dado que:** existe template Harvest activo
- **Cuando:** se genera Harvest
- **Entonces:** usa datos confirmados y marca faltantes
- **Fuente:** F07; F10

## AC-036

- **Requerimiento relacionado:** REQ-071
- **Dado que:** existe template LoA activo
- **Cuando:** se genera LoA
- **Entonces:** usa datos confirmados y queda versionada
- **Fuente:** F07; F10

## AC-037

- **Requerimiento relacionado:** REQ-072
- **Dado que:** existe template claim notice activo
- **Cuando:** se genera
- **Entonces:** usa datos confirmados y queda para aprobación
- **Fuente:** F07; F10

## AC-038

- **Requerimiento relacionado:** REQ-073
- **Dado que:** una carta fue generada
- **Cuando:** no ha sido aprobada por Handler
- **Entonces:** no se considera lista para utilización/emisión
- **Fuente:** F07

## AC-039

- **Requerimiento relacionado:** REQ-075/076
- **Dado que:** un usuario solicita SUBRO o destrucción
- **Cuando:** intenta generarlos
- **Entonces:** el sistema no los presenta como templates incluidos
- **Fuente:** F07; F10

## AC-040

- **Requerimiento relacionado:** REQ-080
- **Dado que:** se crea un caso
- **Cuando:** avanza por el flujo
- **Entonces:** solo usa el catálogo mínimo de seis estados
- **Fuente:** F07

## AC-041

- **Requerimiento relacionado:** REQ-082
- **Dado que:** un caso cumple requisitos de FIS
- **Cuando:** el Handler lo traspasa
- **Entonces:** queda en Traspasado a FIS y se bloquea el cálculo
- **Fuente:** F07

## AC-042

- **Requerimiento relacionado:** REQ-083
- **Dado que:** un caso cumple requisitos judiciales
- **Cuando:** el Handler lo traspasa
- **Entonces:** queda en Traspasado a Lawgistic y se bloquea el cálculo
- **Fuente:** F07

## AC-043

- **Requerimiento relacionado:** REQ-084
- **Dado que:** un caso se traspasa
- **Cuando:** se completa la acción
- **Entonces:** no se envía automáticamente a un sistema externo
- **Fuente:** F07

## AC-044

- **Requerimiento relacionado:** REQ-086
- **Dado que:** un caso está traspasado
- **Cuando:** un Gerente lo revierte
- **Entonces:** el sistema exige motivo y registra usuario/fecha
- **Fuente:** F07

## AC-045

- **Requerimiento relacionado:** REQ-088
- **Dado que:** se cambia estado/documento/cálculo/análisis/carta
- **Cuando:** se guarda
- **Entonces:** se crea evento con usuario y fecha/hora
- **Fuente:** F07

## AC-046

- **Requerimiento relacionado:** REQ-090/091
- **Dado que:** hay fecha real, modo y jurisdicción confirmados
- **Cuando:** se calcula prescripción
- **Entonces:** se aplica la matriz aprobada y se muestra fecha base/plazo
- **Fuente:** F01; F02; pendiente de matriz

## AC-047

- **Requerimiento relacionado:** REQ-092
- **Dado que:** existe fecha de prescripción
- **Cuando:** se consulta el caso
- **Entonces:** muestra días restantes, vencimiento y nivel de riesgo
- **Fuente:** F07

## AC-048

- **Requerimiento relacionado:** REQ-093
- **Dado que:** un caso supera el umbral sin evento válido
- **Cuando:** se actualiza dashboard
- **Entonces:** aparece alerta con último movimiento y responsable
- **Fuente:** F01; F07

## AC-049

- **Requerimiento relacionado:** REQ-096
- **Dado que:** hay cartera activa
- **Cuando:** Gerente abre dashboard
- **Entonces:** ve estados, pendientes, pérdidas, prescripción y distribución por handler
- **Fuente:** F07

## AC-050

- **Requerimiento relacionado:** REQ-097
- **Dado que:** hay varios handlers
- **Cuando:** Gerente abre benchmark
- **Entonces:** compara métricas aprobadas para el periodo seleccionado
- **Fuente:** F07; periodo pendiente

## AC-051

- **Requerimiento relacionado:** REQ-098
- **Dado que:** un caso está listo para cierre
- **Cuando:** se genera informe
- **Entonces:** incluye documentos, causa, mérito, método y monto
- **Fuente:** F07

## AC-052

- **Requerimiento relacionado:** REQ-100
- **Dado que:** se inicia puesta en marcha
- **Cuando:** se carga la fuente histórica definitiva
- **Entonces:** quedan disponibles aproximadamente 4.240 registros/39 hojas o el volumen aprobado
- **Fuente:** F07

## AC-053

- **Requerimiento relacionado:** REQ-101
- **Dado que:** el histórico está cargado
- **Cuando:** el usuario busca una referencia
- **Entonces:** recupera los registros coincidentes
- **Fuente:** F07

## AC-054

- **Requerimiento relacionado:** REQ-102
- **Dado que:** existen históricos y activos
- **Cuando:** se calculan indicadores operativos
- **Entonces:** los históricos no alteran estados/tareas de activos
- **Fuente:** F06; F08

## AC-055

- **Requerimiento relacionado:** REQ-104
- **Dado que:** un Excel nuevo respeta la misma estructura
- **Cuando:** se importa
- **Entonces:** sus registros se incorporan al histórico conforme al límite contractual
- **Fuente:** F07

## AC-056

- **Requerimiento relacionado:** REQ-108
- **Dado que:** un usuario intenta importar masivamente casos activos
- **Cuando:** usa la función histórica
- **Entonces:** el sistema no lo trata como funcionalidad incluida
- **Fuente:** F07

## AC-057

- **Requerimiento relacionado:** REQ-111
- **Dado que:** un Handler inicia sesión
- **Cuando:** usa la plataforma
- **Entonces:** solo ve acciones operativas autorizadas
- **Fuente:** F07

## AC-058

- **Requerimiento relacionado:** REQ-112
- **Dado que:** un Gerente inicia sesión
- **Cuando:** consulta cartera y revierte
- **Entonces:** puede supervisar y la reversión exige motivo
- **Fuente:** F07

## AC-059

- **Requerimiento relacionado:** REQ-113
- **Dado que:** CEO/Dirección inicia sesión
- **Cuando:** abre expediente o indicador
- **Entonces:** puede leer pero no editar
- **Fuente:** F07

## AC-060

- **Requerimiento relacionado:** REQ-115/116
- **Dado que:** un usuario no autenticado o sin permiso intenta operar
- **Cuando:** realiza la acción
- **Entonces:** el servidor la rechaza
- **Fuente:** F07

## AC-061

- **Requerimiento relacionado:** REQ-118
- **Dado que:** ocurre una pérdida o incidente recuperable
- **Cuando:** se ejecuta recuperación
- **Entonces:** los datos pueden restaurarse conforme a estrategia aprobada
- **Fuente:** F07

## AC-062

- **Requerimiento relacionado:** REQ-119
- **Dado que:** el proveedor procesa datos FIS
- **Cuando:** se revisa su uso
- **Entonces:** solo se usan para el servicio y no entrenan modelos generales
- **Fuente:** F07

## AC-063

- **Requerimiento relacionado:** REQ-120
- **Dado que:** termina el contrato
- **Cuando:** FIS instruye devolver o eliminar
- **Entonces:** se ejecuta y deja evidencia salvo conservación legal
- **Fuente:** F07

## AC-064

- **Requerimiento relacionado:** REQ-122
- **Dado que:** un usuario necesita ayuda
- **Cuando:** abre Manual
- **Entonces:** encuentra roles, estados, carga, revisión, cálculo, cartas, alertas y traspaso
- **Fuente:** F07
